Downmix Renderer webview build

This version fixes the common blank-white-window startup issue by opening a native loading page first, waiting for the local HTTP control server to become reachable, and only then loading the main UI.

Build steps on macOS:

1. Open Terminal
2. cd into this folder
3. Run:
   chmod +x build_downmix_renderer_webview_app.sh
   ./build_downmix_renderer_webview_app.sh

When the build finishes, open:

  dist/Downmix Renderer.app

Share this file with another Apple Silicon Mac user:

  Downmix Renderer.zip

If the app still shows a startup error page, delete the launcher preferences file and relaunch:

  ~/.bed_renderer_web_launcher.json


Stability update in v3:
This build adds a short grace period before shutting the launcher down when the page reloads or briefly disconnects during startup. That prevents the first-launch 'Launcher disconnected' race seen in earlier webview builds.


v4 updates:
- Replaces the native <select> device pickers with a custom styled device list so the input/output chooser looks the same inside the embedded webview.
- Disables page-close shutdown in embedded mode and relies on the native app-window close event instead, which avoids the startup race behind the lingering 'Launcher disconnected' issue.
- Makes disconnect detection less trigger-happy by requiring several failed status polls before declaring the launcher gone.

Butterworth LFE update:
- All tap-file based LFE processing has been removed.
- The LFE path now uses a hard-coded 4th-order Butterworth low-pass at 125 Hz, equivalent to 24 dB/octave.
- The filtered LFE is still applied through the existing ADC2 direct coefficient of 2.26464431 to both stereo outputs, so the passband gain structure remains the ADC2 direct one.
- The dry/non-LFE stereo path delay is fixed at 172 samples at 48 kHz before summing.
- The build script compiles the renderer from source before packaging, so run the script on macOS before using the app.


Changes in this build:
- Stereo output meters now use a 90 ms peak hold and smooth dB-domain release to prevent flicker while preserving instant attack on louder peaks.
- Active bed input badges now use a 180 ms visual hold so channels do not flicker when a status frame briefly reports no activity.
- Added a styled LFE filter toggle. On = Butterworth 125 Hz, 4th-order, 24 dB/octave low-pass. Off = dry ADC2 direct LFE with the same 2.26464431 coefficient.

UI cleanup update:
- Removed the Phase-fit band selector from the launcher. The Butterworth LFE mode now uses the fixed 172-sample dry delay.
- Removed long explanatory text from the LFE filter area so the main controls stay compact.

Input latency configurability update:
- Adds an Input safety latency ms field in the launcher UI.
- The launcher passes this value to the renderer with --input-latency-ms.
- Default UI value is 10 ms. Try 15 ms or 20 ms if inputUnderflows/inputOverflows keep increasing.
- 0 uses the device low-latency default.
- The renderer logs configured/requested input latency, device low/high latency, and actual stream latency at startup.

Output routing and PEQ update:
- Adds a Left/right channel swap toggle to the launcher UI. The renderer already supported --swap-outputs, and this build exposes it in the web UI.
- Adds User/global PEQ and stereo Speaker EQ text boxes in the launcher.
- Adds file upload inputs for each PEQ box. Uploaded file contents are saved in the text boxes, not the source file path.
- Adds saved profiles for the Output routing and channel PEQ section. Each profile stores L/R swap, User/global PEQ text, and stereo Speaker EQ text.
- PEQ file/manual text supports Equalizer APO-style and CH:0/CH:1 lines such as:
  Preamp: -3.0 dB
  Filter 1: ON PK Fc 56 Hz Gain -2.6 dB Q 0.355
- Supported filter types are PK, LS, and HS. OFF filters and Xfeed lines are ignored.
- For stereo Speaker EQ files with CH: 0 and CH: 1 sections, the launcher maps CH:0 to left and CH:1 to right when L/R swap is off, and maps CH:1 to left and CH:0 to right when L/R swap is on.
- DSP order is matrix plus master preamp, User/global PEQ, optional L/R swap, then stereo Speaker EQ.

Cutout diagnostics update:
- The renderer no longer logs only inputUnderflows during runtime. It now logs any PortAudio audio-status event that changes: inputUnderflows, inputOverflows, outputUnderflows, outputOverflows, and null-input callbacks.
- The launcher now exposes Output safety latency ms and passes it through with --output-latency-ms.
- If cutouts occur while only outputUnderflows increases, raise Output safety latency ms first. If inputOverflows/inputUnderflows increases, raise Input safety latency ms or frames/buffer.

Output keep-alive update:
- The renderer executable now supports --keep-output-alive, which opens only the selected stereo output device and writes digital silence until stopped.
- The web app exposes a Keep output awake toggle, enabled by default.
- When enabled, the launcher starts a silent output-only stream for the selected DAC/output device without opening the input device or requiring audio content.
- The regular downmix renderer still opens the 16-channel input and stereo output for live rendering. The keep-alive stream is separate and keeps the DAC awake before/after renderer starts and stops.
- Sum meter clip LEDs no longer use a 1.2 second visual latch. They now follow the current renderer clip status and turn off on the next non-clipping status update.
