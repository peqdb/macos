#include <portaudio.h>
#ifdef __APPLE__
#include <pa_mac_core.h>
#endif

#include <algorithm>
#include <array>
#include <atomic>
#include <cmath>
#include <chrono>
#include <cctype>
#include <csignal>
#include <cstdint>
#include <ctime>
#include <cstdlib>
#include <cstring>
#include <exception>
#include <fstream>
#include <iomanip>
#include <iostream>
#include <limits>
#include <sstream>
#include <stdexcept>
#include <string>
#include <string_view>
#include <vector>
#include <thread>
#if defined(__APPLE__) || defined(__unix__)
#include <unistd.h>
#endif

namespace {

constexpr double kSampleRate = 48000.0;
constexpr double kPi = 3.14159265358979323846264338327950288;
constexpr int kStereoOutChannels = 2;
constexpr int kBedChannels916 = 16;
constexpr const char* kBedOrder916 = "L,R,C,LFE,Ls,Rs,Lrs,Rrs,Lw,Rw,Ltf,Rtf,Ltm,Rtm,Ltr,Rtr";
constexpr double kLfeAdc2Coefficient = 2.26464431;
constexpr int kLfeButterworthOrder = 4;  // 24 dB/octave Butterworth low-pass.
constexpr double kLfeButterworthCutoffHz = 125.0;
constexpr size_t kLfeButterworthBiquadCount = 2;
constexpr size_t kLfeDryDelaySamples = 172;
constexpr double kLfePhaseFitBandLowHz = 20.0;
constexpr double kLfePhaseFitBandHighHz = 100.0;
constexpr std::array<std::array<double, 5>, kLfeButterworthBiquadCount> kLfeButterworthSos = {{
    {{ 4.3855960647001719e-09,  8.7711921294003438e-09,  4.3855960647001719e-09, -1.9699539165524493e+00,  9.7021765960312188e-01 }},
    {{ 1.0000000000000000e+00,  2.0000000000000000e+00,  1.0000000000000000e+00, -1.9872891393809169e+00,  9.8755519395384062e-01 }}
}};
constexpr int kDefaultStatusUpdateIntervalMs = 50;
constexpr int kDefaultXrunLogIntervalMs = 100;
constexpr int kStreamHealthCheckIntervalMs = 100;
constexpr int kRendererCallbackStallTimeoutMs = 750;
constexpr int kKeepAliveCallbackStallTimeoutMs = 1500;
constexpr double kDefaultActiveThresholdDb = -160.0;
constexpr double kDefaultActiveThresholdLinear = 1.0e-8;  // -160 dBFS.
constexpr std::array<const char*, kBedChannels916> kBedLabels916 = {
    "L", "R", "C", "LFE", "Ls", "Rs", "Lrs", "Rrs",
    "Lw", "Rw", "Ltf", "Rtf", "Ltm", "Rtm", "Ltr", "Rtr"
};

std::atomic<bool> g_shouldStop{false};

struct StereoFrame {
    double left = 0.0;
    double right = 0.0;
};

struct BiquadState {
    double z1 = 0.0;
    double z2 = 0.0;
};

struct BiquadCoeffs {
    double b0 = 1.0;
    double b1 = 0.0;
    double b2 = 0.0;
    double a1 = 0.0;
    double a2 = 0.0;
};

struct PeqBand {
    std::string type = "PK";
    double fc = 1000.0;
    double gainDb = 0.0;
    double q = 1.0;
};

struct PeqConfig {
    double preampGain = 1.0;
    std::vector<PeqBand> bands;
};

struct PeqRuntime {
    double preampGain = 1.0;
    std::vector<BiquadCoeffs> coeffs;
    std::vector<BiquadState> state;
};

struct Config {
    PaDeviceIndex inputDevice = paNoDevice;
    PaDeviceIndex outputDevice = paNoDevice;
    std::string expectedInputDeviceName;
    std::string expectedOutputDeviceName;
    double sampleRate = kSampleRate;
    unsigned long framesPerBuffer = 64;
    double inputLatencyMs = -1.0;   // Negative or zero means use device defaultLowInputLatency.
    double outputLatencyMs = -1.0;  // Negative or zero means use device defaultLowOutputLatency.
    int inputChannels = kBedChannels916;
    std::array<int, kBedChannels916> inputMap{};
    double masterGain = 1.0;
    double lfeGain = 1.0;
    bool useLfeLowpass = true;
    int dryDelayOverrideSamples = -1;
    bool swapOutputs = false;
    PeqConfig globalPeq;
    PeqConfig speakerOutputPeqLeft;
    PeqConfig speakerOutputPeqRight;
    bool clipOutput = false;
    bool listDevices = false;
    bool listOutputDevices = false;
    bool keepOutputAlive = false;
    bool showActiveInputs = false;
    bool showOutputMeter = false;
    double activeThresholdLinear = kDefaultActiveThresholdLinear;
    int statusUpdateIntervalMs = kDefaultStatusUpdateIntervalMs;
    int xrunLogIntervalMs = kDefaultXrunLogIntervalMs;
#ifdef __APPLE__
    bool macProMode = true;
    bool macAllowDeviceParameterChanges = true;
#endif
};

struct CallbackState {
    std::array<int, kBedChannels916> map{};
    double masterGain = 1.0;
    double lfeGain = 1.0;
    bool useLfeLowpass = true;
    bool swapOutputs = false;
    PeqRuntime globalPeqLeft;
    PeqRuntime globalPeqRight;
    PeqRuntime speakerOutputPeqLeft;
    PeqRuntime speakerOutputPeqRight;
    bool clipOutput = false;
    std::array<BiquadState, kLfeButterworthBiquadCount> lfeFilterState{};
    std::vector<StereoFrame> dryDelayBuffer;
    size_t dryDelayPos = 0;
    size_t dryDelaySamples = 0;
    std::atomic<uint32_t> recentActiveMask{0};
    std::array<std::atomic<double>, kBedChannels916> recentInputPeaks{};
    std::array<std::atomic<double>, kBedChannels916> recentInputTransients{};
    std::array<double, kBedChannels916> transientFastEnv{};
    std::array<double, kBedChannels916> transientSlowEnv{};
    std::atomic<double> recentOutputPeakLeft{0.0};
    std::atomic<double> recentOutputPeakRight{0.0};
    std::atomic<uint32_t> recentClipFlags{0};
    double activeThresholdLinear = kDefaultActiveThresholdLinear;
    std::atomic<uint64_t> callbackCount{0};
    std::atomic<uint64_t> inputUnderflows{0};
    std::atomic<uint64_t> inputOverflows{0};
    std::atomic<uint64_t> outputUnderflows{0};
    std::atomic<uint64_t> outputOverflows{0};
    std::atomic<uint64_t> nullInputCallbacks{0};
    std::atomic<double> lastInputUnderflowPaTime{0.0};
    std::atomic<double> lastInputOverflowPaTime{0.0};
    std::atomic<double> lastOutputUnderflowPaTime{0.0};
    std::atomic<double> lastOutputOverflowPaTime{0.0};
    std::atomic<double> lastNullInputPaTime{0.0};
};

[[noreturn]] void die(const std::string& msg) {
    throw std::runtime_error(msg);
}

bool isIntegerString(const std::string& s) {
    if (s.empty()) return false;
    size_t i = 0;
    if (s[0] == '+' || s[0] == '-') i = 1;
    if (i >= s.size()) return false;
    for (; i < s.size(); ++i) {
        if (!std::isdigit(static_cast<unsigned char>(s[i]))) return false;
    }
    return true;
}

std::string toLower(std::string s) {
    std::transform(s.begin(), s.end(), s.begin(), [](unsigned char c) {
        return static_cast<char>(std::tolower(c));
    });
    return s;
}

double dbToGain(double db) {
    return std::pow(10.0, db / 20.0);
}

bool belowSilenceGate(double value, double threshold) {
    return std::abs(value) < threshold;
}

std::vector<std::string> split(const std::string& s, char delim) {
    std::vector<std::string> out;
    std::stringstream ss(s);
    std::string item;
    while (std::getline(ss, item, delim)) {
        size_t start = 0;
        while (start < item.size() && std::isspace(static_cast<unsigned char>(item[start]))) ++start;
        size_t end = item.size();
        while (end > start && std::isspace(static_cast<unsigned char>(item[end - 1]))) --end;
        if (end > start) out.emplace_back(item.substr(start, end - start));
    }
    return out;
}

std::string activeInputsToString(uint32_t mask, const std::array<int, kBedChannels916>& inputMap) {
    std::ostringstream oss;
    bool first = true;
    for (int i = 0; i < kBedChannels916; ++i) {
        if ((mask & (uint32_t(1) << i)) == 0) continue;
        if (!first) oss << ", ";
        first = false;
        if (inputMap[i] < 0) oss << '0';
        else oss << (inputMap[i] + 1);
        oss << "(" << kBedLabels916[i] << ")";
    }
    if (first) oss << "(none)";
    return oss.str();
}

void atomicMax(std::atomic<double>& target, double value) {
    double current = target.load(std::memory_order_relaxed);
    while (value > current &&
           !target.compare_exchange_weak(current, value,
                                         std::memory_order_relaxed,
                                         std::memory_order_relaxed)) {
    }
}

std::string dbfsString(double linear) {
    if (linear <= 0.0) return "-inf";
    std::ostringstream oss;
    oss << std::fixed << std::setprecision(1) << (20.0 * std::log10(linear));
    return oss.str();
}

std::string inputLevelsToString(const std::array<double, kBedChannels916>& peaks) {
    std::ostringstream oss;
    for (int i = 0; i < kBedChannels916; ++i) {
        if (i) oss << ',';
        oss << kBedLabels916[i] << ':' << dbfsString(peaks[i]);
    }
    return oss.str();
}

std::string localTimestampNow() {
    using namespace std::chrono;
    const auto now = system_clock::now();
    const auto ms = duration_cast<milliseconds>(now.time_since_epoch()) % 1000;
    const std::time_t t = system_clock::to_time_t(now);
    std::tm tm{};
#ifdef _WIN32
    localtime_s(&tm, &t);
#else
    localtime_r(&t, &tm);
#endif
    std::ostringstream oss;
    oss << std::put_time(&tm, "%Y-%m-%d %H:%M:%S")
        << '.' << std::setw(3) << std::setfill('0') << ms.count();
    return oss.str();
}

struct XrunCountersSnapshot {
    uint64_t callbacks = 0;
    uint64_t inputUnderflows = 0;
    uint64_t inputOverflows = 0;
    uint64_t outputUnderflows = 0;
    uint64_t outputOverflows = 0;
    uint64_t nullInputCallbacks = 0;
};

XrunCountersSnapshot readXrunCounters(const CallbackState& st) {
    XrunCountersSnapshot x;
    x.callbacks = st.callbackCount.load(std::memory_order_relaxed);
    x.inputUnderflows = st.inputUnderflows.load(std::memory_order_relaxed);
    x.inputOverflows = st.inputOverflows.load(std::memory_order_relaxed);
    x.outputUnderflows = st.outputUnderflows.load(std::memory_order_relaxed);
    x.outputOverflows = st.outputOverflows.load(std::memory_order_relaxed);
    x.nullInputCallbacks = st.nullInputCallbacks.load(std::memory_order_relaxed);
    return x;
}


std::string inputMapToString(const std::array<int, kBedChannels916>& inputMap) {
    std::ostringstream oss;
    for (int i = 0; i < kBedChannels916; ++i) {
        if (i) oss << ',';
        if (inputMap[i] < 0) oss << '0';
        else oss << (inputMap[i] + 1);
    }
    return oss.str();
}

std::string trim(std::string s) {
    size_t start = 0;
    while (start < s.size() && std::isspace(static_cast<unsigned char>(s[start]))) ++start;
    size_t end = s.size();
    while (end > start && std::isspace(static_cast<unsigned char>(s[end - 1]))) --end;
    return s.substr(start, end - start);
}

bool startsWithLower(const std::string& lowerText, const std::string& lowerPrefix) {
    return lowerText.rfind(lowerPrefix, 0) == 0;
}

bool parseFirstNumberAfterColon(const std::string& line, double& value) {
    const size_t colon = line.find(':');
    const std::string tail = (colon == std::string::npos) ? line : line.substr(colon + 1);
    std::stringstream ss(tail);
    ss >> value;
    return !ss.fail();
}

bool parseIntegerAfterColon(const std::string& line, int& value) {
    double v = 0.0;
    if (!parseFirstNumberAfterColon(line, v)) return false;
    value = static_cast<int>(std::llround(v));
    return true;
}

std::vector<std::string> tokensForPeqLine(std::string line) {
    for (char& c : line) {
        if (c == ':' || c == ',' || c == ';' || c == '=') c = ' ';
    }
    std::stringstream ss(line);
    std::vector<std::string> out;
    std::string token;
    while (ss >> token) out.push_back(token);
    return out;
}

bool parsePeqFilterLine(const std::string& line, PeqBand& band) {
    const auto toks = tokensForPeqLine(line);
    if (toks.empty()) return false;
    std::vector<std::string> low;
    low.reserve(toks.size());
    for (const auto& t : toks) low.push_back(toLower(t));

    auto contains = [&](const std::string& needle) {
        return std::find(low.begin(), low.end(), needle) != low.end();
    };
    if (!contains("on")) return false;
    if (contains("off")) return false;

    std::string type;
    for (const auto& t : low) {
        if (t == "pk" || t == "peq" || t == "peak" || t == "peaking" ||
            t == "ls" || t == "lsc" || t == "lowshelf" || t == "low-shelf" ||
            t == "hs" || t == "hsc" || t == "highshelf" || t == "high-shelf") {
            type = t;
            break;
        }
    }
    if (type.empty()) return false;

    auto numberAfter = [&](const std::string& key, double& value) {
        for (size_t i = 0; i + 1 < low.size(); ++i) {
            if (low[i] == key) {
                try {
                    value = std::stod(toks[i + 1]);
                    return true;
                } catch (...) {
                    return false;
                }
            }
        }
        return false;
    };

    double fc = 0.0;
    double gain = 0.0;
    double q = 0.0;
    if (!numberAfter("fc", fc)) return false;
    if (!numberAfter("gain", gain)) return false;
    const bool hasQ = numberAfter("q", q);
    if (!hasQ) q = 0.70710678;
    if (!(fc > 0.0) || !(q > 0.0)) return false;

    if (type == "ls" || type == "lsc" || type == "lowshelf" || type == "low-shelf") band.type = "LS";
    else if (type == "hs" || type == "hsc" || type == "highshelf" || type == "high-shelf") band.type = "HS";
    else band.type = "PK";
    band.fc = fc;
    band.gainDb = gain;
    band.q = q;
    return true;
}

PeqConfig parsePeqText(const std::string& text, int preferredChannel, const std::string& sourceName) {
    struct Section {
        double preampGain = 1.0;
        bool hasPreamp = false;
        std::vector<PeqBand> bands;
    };

    std::vector<std::pair<int, Section>> channelSections;
    Section noChannel;
    int currentChannel = std::numeric_limits<int>::min();
    bool sawChannel = false;

    auto sectionForCurrent = [&]() -> Section& {
        if (!sawChannel) return noChannel;
        for (auto& item : channelSections) {
            if (item.first == currentChannel) return item.second;
        }
        channelSections.push_back({currentChannel, {}});
        return channelSections.back().second;
    };

    std::stringstream ss(text);
    std::string rawLine;
    while (std::getline(ss, rawLine)) {
        const std::string line = trim(rawLine);
        if (line.empty()) continue;
        const std::string low = toLower(line);
        if (startsWithLower(low, "#") || startsWithLower(low, "//")) continue;

        if (startsWithLower(low, "ch:") || startsWithLower(low, "channel:")) {
            int ch = 0;
            bool ok = parseIntegerAfterColon(line, ch);
            if (!ok && startsWithLower(low, "channel:")) {
                if (low.find(" l") != std::string::npos || low.find(":l") != std::string::npos) { ch = 0; ok = true; }
                else if (low.find(" r") != std::string::npos || low.find(":r") != std::string::npos) { ch = 1; ok = true; }
            }
            if (ok) {
                sawChannel = true;
                currentChannel = ch;
                sectionForCurrent();
            }
            continue;
        }

        if (startsWithLower(low, "preamp:")) {
            double db = 0.0;
            if (parseFirstNumberAfterColon(line, db)) {
                Section& section = sectionForCurrent();
                section.preampGain = dbToGain(db);
                section.hasPreamp = true;
            }
            continue;
        }

        if (startsWithLower(low, "filter")) {
            PeqBand band;
            if (parsePeqFilterLine(line, band)) {
                sectionForCurrent().bands.push_back(band);
            }
            continue;
        }
    }

    const Section* chosen = nullptr;
    if (!sawChannel) {
        chosen = &noChannel;
    } else if (preferredChannel >= 0) {
        for (const auto& item : channelSections) {
            if (item.first == preferredChannel) {
                chosen = &item.second;
                break;
            }
        }
        if (!chosen && channelSections.size() == 1) chosen = &channelSections.front().second;
    }
    if (!chosen && !channelSections.empty()) chosen = &channelSections.front().second;
    if (!chosen) chosen = &noChannel;

    PeqConfig cfg;
    cfg.preampGain = chosen->preampGain;
    cfg.bands = chosen->bands;
    if (cfg.bands.empty() && !chosen->hasPreamp && !sourceName.empty()) {
        std::cerr << "Warning: PEQ file parsed no active filters or preamp: " << sourceName << '\n';
    }
    return cfg;
}

PeqConfig parsePeqFile(const std::string& path, int preferredChannel, const std::string& label) {
    std::ifstream f(path);
    if (!f) die("Could not open " + label + " PEQ file: " + path);
    std::stringstream buffer;
    buffer << f.rdbuf();
    return parsePeqText(buffer.str(), preferredChannel, path);
}

BiquadCoeffs makePeqBiquad(const PeqBand& band, double sampleRate) {
    const double minHz = 1.0;
    const double maxHz = (sampleRate * 0.5) * 0.999;
    const double fc = std::max(minHz, std::min(maxHz, band.fc));
    const double q = std::max(0.000001, band.q);
    const double A = std::pow(10.0, band.gainDb / 40.0);
    const double w0 = 2.0 * kPi * fc / sampleRate;
    const double cs = std::cos(w0);
    const double sn = std::sin(w0);
    const double alpha = sn / (2.0 * q);
    const std::string type = toLower(band.type);

    double b0 = 1.0, b1 = 0.0, b2 = 0.0, a0 = 1.0, a1 = 0.0, a2 = 0.0;
    if (type == "ls") {
        const double twoSqrtAAlpha = 2.0 * std::sqrt(A) * alpha;
        b0 = A * ((A + 1.0) - (A - 1.0) * cs + twoSqrtAAlpha);
        b1 = 2.0 * A * ((A - 1.0) - (A + 1.0) * cs);
        b2 = A * ((A + 1.0) - (A - 1.0) * cs - twoSqrtAAlpha);
        a0 = (A + 1.0) + (A - 1.0) * cs + twoSqrtAAlpha;
        a1 = -2.0 * ((A - 1.0) + (A + 1.0) * cs);
        a2 = (A + 1.0) + (A - 1.0) * cs - twoSqrtAAlpha;
    } else if (type == "hs") {
        const double twoSqrtAAlpha = 2.0 * std::sqrt(A) * alpha;
        b0 = A * ((A + 1.0) + (A - 1.0) * cs + twoSqrtAAlpha);
        b1 = -2.0 * A * ((A - 1.0) + (A + 1.0) * cs);
        b2 = A * ((A + 1.0) + (A - 1.0) * cs - twoSqrtAAlpha);
        a0 = (A + 1.0) - (A - 1.0) * cs + twoSqrtAAlpha;
        a1 = 2.0 * ((A - 1.0) - (A + 1.0) * cs);
        a2 = (A + 1.0) - (A - 1.0) * cs - twoSqrtAAlpha;
    } else {
        b0 = 1.0 + alpha * A;
        b1 = -2.0 * cs;
        b2 = 1.0 - alpha * A;
        a0 = 1.0 + alpha / A;
        a1 = -2.0 * cs;
        a2 = 1.0 - alpha / A;
    }

    if (std::abs(a0) < 1e-30) die("Invalid PEQ biquad normalization for Fc " + std::to_string(band.fc));
    return {b0 / a0, b1 / a0, b2 / a0, a1 / a0, a2 / a0};
}

PeqRuntime makePeqRuntime(const PeqConfig& cfg, double sampleRate) {
    PeqRuntime rt;
    rt.preampGain = cfg.preampGain;
    rt.coeffs.reserve(cfg.bands.size());
    for (const PeqBand& band : cfg.bands) {
        rt.coeffs.push_back(makePeqBiquad(band, sampleRate));
    }
    rt.state.assign(rt.coeffs.size(), {});
    return rt;
}

double processPeqSample(PeqRuntime& peq, double x) {
    double y = x * peq.preampGain;
    for (size_t i = 0; i < peq.coeffs.size(); ++i) {
        const BiquadCoeffs& c = peq.coeffs[i];
        BiquadState& q = peq.state[i];
        const double sectionOut = c.b0 * y + q.z1;
        q.z1 = c.b1 * y - c.a1 * sectionOut + q.z2;
        q.z2 = c.b2 * y - c.a2 * sectionOut;
        y = sectionOut;
    }
    return y;
}

std::string peqSummary(const PeqConfig& cfg) {
    std::ostringstream oss;
    oss << cfg.bands.size() << " filters, preamp "
        << std::fixed << std::setprecision(1)
        << (20.0 * std::log10(std::max(cfg.preampGain, 1e-20))) << " dB";
    return oss.str();
}


double processLfeLowpassSample(CallbackState& st, double x) {
    double y = x;
    for (size_t i = 0; i < kLfeButterworthBiquadCount; ++i) {
        const auto& c = kLfeButterworthSos[i];
        BiquadState& q = st.lfeFilterState[i];

        // Direct Form II Transposed:
        // y[n] = b0*x[n] + z1
        // z1   = b1*x[n] - a1*y[n] + z2
        // z2   = b2*x[n] - a2*y[n]
        const double sectionOut = c[0] * y + q.z1;
        q.z1 = c[1] * y - c[3] * sectionOut + q.z2;
        q.z2 = c[2] * y - c[4] * sectionOut;
        y = sectionOut;
    }
    return y;
}

StereoFrame processDryDelaySample(CallbackState& st, double left, double right) {
    if (st.dryDelaySamples == 0 || st.dryDelayBuffer.empty()) return {left, right};
    StereoFrame delayed = st.dryDelayBuffer[st.dryDelayPos];
    st.dryDelayBuffer[st.dryDelayPos] = {left, right};
    st.dryDelayPos = (st.dryDelayPos + 1) % st.dryDelayBuffer.size();
    return delayed;
}

void resetPeqState(PeqRuntime& peq) {
    for (BiquadState& q : peq.state) q = {};
}

void clearSubThresholdProcessingState(CallbackState& st) {
    for (BiquadState& q : st.lfeFilterState) q = {};
    resetPeqState(st.globalPeqLeft);
    resetPeqState(st.globalPeqRight);
    resetPeqState(st.speakerOutputPeqLeft);
    resetPeqState(st.speakerOutputPeqRight);
    if (!st.dryDelayBuffer.empty()) {
        std::fill(st.dryDelayBuffer.begin(), st.dryDelayBuffer.end(), StereoFrame{});
        st.dryDelayPos = 0;
    }
    st.transientFastEnv.fill(0.0);
    st.transientSlowEnv.fill(0.0);
}

PaDeviceIndex resolveDevice(const std::string& token, bool forInput) {
    if (token.empty()) {
        return forInput ? Pa_GetDefaultInputDevice() : Pa_GetDefaultOutputDevice();
    }
    if (isIntegerString(token)) {
        int idx = std::stoi(token);
        if (idx < 0 || idx >= Pa_GetDeviceCount()) {
            die("Device index out of range: " + token);
        }
        const PaDeviceInfo* d = Pa_GetDeviceInfo(idx);
        if (!d) die("Could not resolve device index: " + token);
        if (forInput && d->maxInputChannels <= 0) die("Selected input device has no input channels");
        if (!forInput && d->maxOutputChannels <= 0) die("Selected output device has no output channels");
        return idx;
    }

    const std::string needle = toLower(token);
    const int count = Pa_GetDeviceCount();
    PaDeviceIndex best = paNoDevice;
    for (int i = 0; i < count; ++i) {
        const PaDeviceInfo* d = Pa_GetDeviceInfo(i);
        if (!d || !d->name) continue;
        if (forInput && d->maxInputChannels <= 0) continue;
        if (!forInput && d->maxOutputChannels <= 0) continue;
        if (toLower(d->name).find(needle) != std::string::npos) {
            best = i;
            break;
        }
    }
    if (best == paNoDevice) {
        die(std::string("Could not find ") + (forInput ? "input" : "output") + " device matching: " + token);
    }
    return best;
}


void verifyExpectedDeviceName(PaDeviceIndex device, const std::string& expectedName, bool forInput) {
    if (expectedName.empty()) return;
    const PaDeviceInfo* d = Pa_GetDeviceInfo(device);
    if (!d || !d->name) {
        die(std::string("Could not query selected ") + (forInput ? "input" : "output") + " device info.");
    }
    const std::string actualName(d->name);
    if (actualName != expectedName) {
        if (forInput) {
            die("Selected input device is unavailable or changed before startup.");
        } else {
            die("Selected output device is unavailable.");
        }
    }
}

std::array<int, kBedChannels916> parseInputMap(const std::string& text, int inputChannels) {
    auto parts = split(text, ',');
    if (parts.size() != kBedChannels916) {
        die("--input-map must contain exactly 16 comma-separated channel numbers for 9.1.6");
    }
    std::array<int, kBedChannels916> map{};
    for (size_t i = 0; i < parts.size(); ++i) {
        const std::string token = toLower(parts[i]);
        if (token == "0" || token == "x" || token == "mute" || token == "none") {
            map[i] = -1;
            continue;
        }
        if (!isIntegerString(parts[i])) {
            die("Invalid channel number in --input-map: " + parts[i]);
        }
        int oneBased = std::stoi(parts[i]);
        if (oneBased < 1 || oneBased > inputChannels) {
            die("--input-map entry out of range for --input-channels: " + std::to_string(oneBased));
        }
        map[i] = oneBased - 1;
    }
    return map;
}

void listDevices(bool outputsOnly = false) {
    const int count = Pa_GetDeviceCount();
    if (count < 0) {
        die(std::string("Pa_GetDeviceCount failed: ") + Pa_GetErrorText(count));
    }
    std::cout << (outputsOnly ? "PortAudio output devices:\n" : "PortAudio devices:\n");
    const PaDeviceIndex defaultOutput = Pa_GetDefaultOutputDevice();
    const PaDeviceIndex defaultInput = outputsOnly ? paNoDevice : Pa_GetDefaultInputDevice();
    for (int i = 0; i < count; ++i) {
        const PaDeviceInfo* d = Pa_GetDeviceInfo(i);
        if (!d) continue;
        if (outputsOnly && d->maxOutputChannels <= 0) continue;
        std::cout << '[' << i << ']';
        if (!outputsOnly && i == defaultInput) std::cout << " [default-in]";
        if (i == defaultOutput) std::cout << " [default-out]";
        std::cout << ' ' << (d->name ? d->name : "(unnamed)")
                  << " | in: " << (outputsOnly ? 0 : d->maxInputChannels)
                  << " | out: " << d->maxOutputChannels
                  << " | default SR: " << d->defaultSampleRate;
        if (!outputsOnly) {
            std::cout << " | low in lat: " << std::fixed << std::setprecision(4) << d->defaultLowInputLatency
                      << " | high in lat: " << std::fixed << std::setprecision(4) << d->defaultHighInputLatency;
        }
        std::cout << " | low out lat: " << std::fixed << std::setprecision(4) << d->defaultLowOutputLatency
                  << " | high out lat: " << std::fixed << std::setprecision(4) << d->defaultHighOutputLatency
                  << "\n";
    }
}

void printUsage(const char* exe) {
    std::cout
        << "Usage:\n"
        << "  " << exe << " --list-devices\n"
        << "  " << exe << " --list-output-devices\n"
        << "  " << exe << " --input-device 3 --output-device 2 [options]\n\n"
        << "Fixed renderer: 9.1.6 bed -> stereo with Butterworth LFE low-pass\n"
        << "Bed order: " << kBedOrder916 << "\n\n"
        << "Options:\n"
        << "  --list-devices                 Print input and output devices and exit\n"
        << "  --list-output-devices          Print output devices only and exit\n"
        << "  --input-device <name|index>   Input device name substring or index\n"
        << "  --output-device <name|index>  Output device name substring or index\n"
        << "  --expected-input-device-name <name>   Refuse startup if the resolved input index no longer has this exact name\n"
        << "  --expected-output-device-name <name>  Refuse startup if the resolved output index no longer has this exact name\n"
        << "  --keep-output-alive          Open the selected output only and play digital silence until stopped\n"
        << "  --samplerate 48000            Sample rate. This renderer is intended for 48 kHz\n"
        << "  --frames-per-buffer <n>       Callback size in frames. Default 64\n"
        << "  --input-latency-ms <ms>       Input-side safety latency. Use 0 or omit for device low latency. Suggested test values: 10, 15, 20 ms\n"
        << "  --output-latency-ms <ms>      Output-side safety latency. Use 0 or omit for device low latency\n"
        << "  --input-channels <n>          Channels to open on input device. Default 16\n"
        << "  --input-map a,b,c,...         1-based map for L,R,C,LFE,Ls,Rs,Lrs,Rrs,Lw,Rw,Ltf,Rtf,Ltm,Rtm,Ltr,Rtr. Use 0/x/mute for unmapped bed channels\n"
        << "  --master-gain-db <dB>         Master gain in dB\n"
        << "  --lfe-gain-db <dB>            Optional LFE gain before the fixed ADC2 coefficient\n"
        << "  --lfe-filter-mode <mode>      butterworth or dry. Default butterworth\n"
        << "  --dry-lfe                     Bypass Butterworth low-pass and use dry ADC2 direct LFE\n"
        << "  --stereo-matrix-mode <mode>   Compatibility alias: adc2-direct=dry, standard=butterworth\n"
        << "  --delay-search-max-samples <n> Compatibility no-op\n"
        << "  --delay-override-samples <n>  Override Butterworth dry-path delay in samples\n"
        << "  --swap-outputs                Swap final left and right outputs\n"
        << "  --global-output-peq-file <p>   User/global PEQ applied to both outputs before swap\n"
        << "  --speaker-output-peq-file <p>  Speaker EQ stereo file. Launcher flips CH 0/1 assignment when --swap-outputs is used.\n"
        << "  --global-output-peq-channel <n|first>   Channel to use from global PEQ file. Default first\n"
        << "  --speaker-left-peq-channel <n|first>    Channel to use for physical-left speaker EQ. Default 0\n"
        << "  --speaker-right-peq-channel <n|first>   Channel to use for physical-right speaker EQ. Default 1\n"
        << "  --clip-output                 Hard clip output to [-1, 1]\n"
        << "  --show-active-inputs          Print active input channels while running\n"
        << "  --show-output-meter           Print output peak meter status while running\n"
        << "  --active-threshold-db <dB>    Activity threshold in dBFS, default " << kDefaultActiveThresholdDb << "\n"
        << "  --status-interval-ms <n>      Status publish interval for launcher/UI telemetry. Default 50 ms\n"
        << "  --xrun-log-interval-ms <n>   Check for input underflow events every n ms. Use 0 to disable. Default " << kDefaultXrunLogIntervalMs << " ms\n"
#ifdef __APPLE__
        << "  --no-mac-pro-mode             Disable paMacCorePro stream tuning\n"
        << "  --no-mac-device-changes       Do not allow Core Audio device parameter changes\n"
#endif
        << "\nExample:\n"
        << "  " << exe << " --input-device \"BlackHole 16ch\" --output-device \"BlackHole 2ch\" --frames-per-buffer 64\n";
}

Config parseArgs(int argc, char** argv) {
    Config cfg;
    for (int i = 0; i < kBedChannels916; ++i) cfg.inputMap[i] = i;

    auto requireValue = [&](int& idx, const char* flag) -> std::string {
        if (idx + 1 >= argc) die(std::string("Missing value for ") + flag);
        return argv[++idx];
    };

    std::string inputDeviceToken;
    std::string outputDeviceToken;
    std::string inputMapText;
    bool inputMapProvided = false;
    std::string globalPeqPath;
    std::string speakerPeqPath;
    int globalPeqChannel = -1;
    int speakerLeftPeqChannel = 0;
    int speakerRightPeqChannel = 1;

    auto parsePeqChannelArg = [&](const std::string& text, const char* flag) -> int {
        const std::string low = toLower(trim(text));
        if (low.empty() || low == "first" || low == "any" || low == "auto") return -1;
        if (!isIntegerString(low)) die(std::string("Invalid ") + flag + ": " + text);
        return std::stoi(low);
    };

    for (int i = 1; i < argc; ++i) {
        std::string arg = argv[i];
        if (arg == "--help" || arg == "-h") {
            printUsage(argv[0]);
            std::exit(0);
        } else if (arg == "--list-devices") {
            cfg.listDevices = true;
        } else if (arg == "--list-output-devices" || arg == "--list-outputs") {
            cfg.listOutputDevices = true;
        } else if (arg == "--keep-output-alive") {
            cfg.keepOutputAlive = true;
        } else if (arg == "--input-device") {
            inputDeviceToken = requireValue(i, "--input-device");
        } else if (arg == "--output-device") {
            outputDeviceToken = requireValue(i, "--output-device");
        } else if (arg == "--expected-input-device-name") {
            cfg.expectedInputDeviceName = requireValue(i, "--expected-input-device-name");
        } else if (arg == "--expected-output-device-name") {
            cfg.expectedOutputDeviceName = requireValue(i, "--expected-output-device-name");
        } else if (arg == "--samplerate") {
            cfg.sampleRate = std::stod(requireValue(i, "--samplerate"));
        } else if (arg == "--frames-per-buffer") {
            cfg.framesPerBuffer = static_cast<unsigned long>(std::stoul(requireValue(i, "--frames-per-buffer")));
        } else if (arg == "--input-latency-ms") {
            cfg.inputLatencyMs = std::stod(requireValue(i, "--input-latency-ms"));
        } else if (arg == "--output-latency-ms") {
            cfg.outputLatencyMs = std::stod(requireValue(i, "--output-latency-ms"));
        } else if (arg == "--input-channels") {
            cfg.inputChannels = std::stoi(requireValue(i, "--input-channels"));
        } else if (arg == "--input-map") {
            inputMapText = requireValue(i, "--input-map");
            inputMapProvided = true;
        } else if (arg == "--master-gain-db") {
            cfg.masterGain = dbToGain(std::stod(requireValue(i, "--master-gain-db")));
        } else if (arg == "--lfe-gain-db") {
            cfg.lfeGain = dbToGain(std::stod(requireValue(i, "--lfe-gain-db")));
        } else if (arg == "--lfe-filter-mode") {
            std::string mode = requireValue(i, "--lfe-filter-mode");
            std::transform(mode.begin(), mode.end(), mode.begin(), [](unsigned char c){ return static_cast<char>(std::tolower(c)); });
            if (mode == "butterworth" || mode == "butter" || mode == "butter125" || mode == "lowpass" || mode == "low-pass" || mode == "cheby2" || mode == "cheby") {
                cfg.useLfeLowpass = true;
            } else if (mode == "dry" || mode == "bypass" || mode == "adc2-direct" || mode == "adc2_direct") {
                cfg.useLfeLowpass = false;
            } else {
                die("Unknown --lfe-filter-mode: " + mode);
            }
        } else if (arg == "--dry-lfe") {
            cfg.useLfeLowpass = false;
        } else if (arg == "--stereo-matrix-mode") {
            std::string mode = requireValue(i, "--stereo-matrix-mode");
            std::transform(mode.begin(), mode.end(), mode.begin(), [](unsigned char c){ return static_cast<char>(std::tolower(c)); });
            if (mode == "adc2-direct" || mode == "adc2_direct" || mode == "dry") {
                cfg.useLfeLowpass = false;
            } else if (mode == "standard" || mode == "butterworth" || mode == "butter" || mode == "butter125" || mode == "lowpass" || mode == "low-pass" || mode == "cheby2" || mode == "cheby") {
                cfg.useLfeLowpass = true;
            } else {
                die("Unsupported --stereo-matrix-mode: " + mode);
            }
        } else if (arg == "--delay-search-max-samples") {
            (void)std::stoi(requireValue(i, "--delay-search-max-samples"));
        } else if (arg == "--delay-override-samples") {
            cfg.dryDelayOverrideSamples = std::stoi(requireValue(i, "--delay-override-samples"));
        } else if (arg == "--swap-outputs") {
            cfg.swapOutputs = true;
        } else if (arg == "--global-output-peq-file") {
            globalPeqPath = requireValue(i, "--global-output-peq-file");
        } else if (arg == "--speaker-output-peq-file") {
            speakerPeqPath = requireValue(i, "--speaker-output-peq-file");
        } else if (arg == "--global-output-peq-channel") {
            globalPeqChannel = parsePeqChannelArg(requireValue(i, "--global-output-peq-channel"), "--global-output-peq-channel");
        } else if (arg == "--speaker-left-peq-channel") {
            speakerLeftPeqChannel = parsePeqChannelArg(requireValue(i, "--speaker-left-peq-channel"), "--speaker-left-peq-channel");
        } else if (arg == "--speaker-right-peq-channel") {
            speakerRightPeqChannel = parsePeqChannelArg(requireValue(i, "--speaker-right-peq-channel"), "--speaker-right-peq-channel");
        } else if (arg == "--clip-output") {
            cfg.clipOutput = true;
        } else if (arg == "--show-active-inputs") {
            cfg.showActiveInputs = true;
        } else if (arg == "--no-show-active-inputs") {
            cfg.showActiveInputs = false;
        } else if (arg == "--show-output-meter") {
            cfg.showOutputMeter = true;
        } else if (arg == "--active-threshold-db") {
            cfg.activeThresholdLinear = dbToGain(std::stod(requireValue(i, "--active-threshold-db")));
        } else if (arg == "--status-interval-ms") {
            cfg.statusUpdateIntervalMs = std::stoi(requireValue(i, "--status-interval-ms"));
            if (cfg.statusUpdateIntervalMs < 1) cfg.statusUpdateIntervalMs = 1;
        } else if (arg == "--xrun-log-interval-ms") {
            cfg.xrunLogIntervalMs = std::stoi(requireValue(i, "--xrun-log-interval-ms"));
            if (cfg.xrunLogIntervalMs < 0) cfg.xrunLogIntervalMs = 0;
#ifdef __APPLE__
        } else if (arg == "--no-mac-pro-mode") {
            cfg.macProMode = false;
        } else if (arg == "--no-mac-device-changes") {
            cfg.macAllowDeviceParameterChanges = false;
#endif
        } else {
            die("Unknown argument: " + arg);
        }
    }

    if (cfg.listDevices || cfg.listOutputDevices) return cfg;
    if (cfg.sampleRate != kSampleRate) die("This renderer is defined for 48 kHz only. Use --samplerate 48000.");
    if (cfg.inputLatencyMs < -1.0) die("--input-latency-ms must be -1 or greater.");
    if (cfg.outputLatencyMs < -1.0) die("--output-latency-ms must be -1 or greater.");
    if (cfg.keepOutputAlive) {
        cfg.outputDevice = resolveDevice(outputDeviceToken, false);
        verifyExpectedDeviceName(cfg.outputDevice, cfg.expectedOutputDeviceName, false);
        const PaDeviceInfo* outInfo = Pa_GetDeviceInfo(cfg.outputDevice);
        if (!outInfo) die("Could not query selected output device info.");
        if (outInfo->maxOutputChannels < kStereoOutChannels) die("Selected output device does not expose at least 2 output channels.");
        return cfg;
    }
    if (cfg.inputChannels < kBedChannels916) die("--input-channels must be at least 16 for 9.1.6.");
    if (inputMapProvided) cfg.inputMap = parseInputMap(inputMapText, cfg.inputChannels);
    if (!globalPeqPath.empty()) cfg.globalPeq = parsePeqFile(globalPeqPath, globalPeqChannel, "global-output");
    if (!speakerPeqPath.empty()) {
        cfg.speakerOutputPeqLeft = parsePeqFile(speakerPeqPath, speakerLeftPeqChannel, "speaker-output-left");
        cfg.speakerOutputPeqRight = parsePeqFile(speakerPeqPath, speakerRightPeqChannel, "speaker-output-right");
    }
    cfg.inputDevice = resolveDevice(inputDeviceToken, true);
    cfg.outputDevice = resolveDevice(outputDeviceToken, false);
    verifyExpectedDeviceName(cfg.inputDevice, cfg.expectedInputDeviceName, true);
    verifyExpectedDeviceName(cfg.outputDevice, cfg.expectedOutputDeviceName, false);

    const PaDeviceInfo* inInfo = Pa_GetDeviceInfo(cfg.inputDevice);
    const PaDeviceInfo* outInfo = Pa_GetDeviceInfo(cfg.outputDevice);
    if (!inInfo || !outInfo) die("Could not query selected device info.");
    if (inInfo->maxInputChannels < cfg.inputChannels) die("Selected input device does not expose enough input channels.");
    if (outInfo->maxOutputChannels < kStereoOutChannels) die("Selected output device does not expose at least 2 output channels.");
    return cfg;
}

struct CallbackBundle {
    CallbackState state;
    int inputStride = kBedChannels916;
};

struct KeepAliveState {
    std::atomic<uint64_t> callbackCount{0};
    std::atomic<uint64_t> outputUnderflows{0};
    std::atomic<uint64_t> outputOverflows{0};
};

int outputKeepAliveCallback(const void* input,
                            void* output,
                            unsigned long frameCount,
                            const PaStreamCallbackTimeInfo* timeInfo,
                            PaStreamCallbackFlags statusFlags,
                            void* userData) {
    (void)input;
    (void)timeInfo;
    auto* st = static_cast<KeepAliveState*>(userData);
    if (st) {
        st->callbackCount.fetch_add(1, std::memory_order_relaxed);
        if (statusFlags & paOutputUnderflow) st->outputUnderflows.fetch_add(1, std::memory_order_relaxed);
        if (statusFlags & paOutputOverflow) st->outputOverflows.fetch_add(1, std::memory_order_relaxed);
    }
    float* out = static_cast<float*>(output);
    if (out) std::fill(out, out + frameCount * kStereoOutChannels, 0.0f);
    return paContinue;
}

int audioCallbackStride(const void* input,
                        void* output,
                        unsigned long frameCount,
                        const PaStreamCallbackTimeInfo* timeInfo,
                        PaStreamCallbackFlags statusFlags,
                        void* userData) {
    auto* bundle = static_cast<CallbackBundle*>(userData);
    auto& st = bundle->state;
    st.callbackCount.fetch_add(1, std::memory_order_relaxed);

    if (statusFlags & paInputUnderflow) {
        st.inputUnderflows.fetch_add(1, std::memory_order_relaxed);
        if (timeInfo) st.lastInputUnderflowPaTime.store(timeInfo->currentTime, std::memory_order_relaxed);
    }
    if (statusFlags & paInputOverflow) {
        st.inputOverflows.fetch_add(1, std::memory_order_relaxed);
        if (timeInfo) st.lastInputOverflowPaTime.store(timeInfo->currentTime, std::memory_order_relaxed);
    }
    if (statusFlags & paOutputUnderflow) {
        st.outputUnderflows.fetch_add(1, std::memory_order_relaxed);
        if (timeInfo) st.lastOutputUnderflowPaTime.store(timeInfo->currentTime, std::memory_order_relaxed);
    }
    if (statusFlags & paOutputOverflow) {
        st.outputOverflows.fetch_add(1, std::memory_order_relaxed);
        if (timeInfo) st.lastOutputOverflowPaTime.store(timeInfo->currentTime, std::memory_order_relaxed);
    }

    const float* in = static_cast<const float*>(input);
    float* out = static_cast<float*>(output);
    if (!out) return paContinue;
    if (!in) {
        st.nullInputCallbacks.fetch_add(1, std::memory_order_relaxed);
        if (timeInfo) st.lastNullInputPaTime.store(timeInfo->currentTime, std::memory_order_relaxed);
        std::fill(out, out + frameCount * kStereoOutChannels, 0.0f);
        return paContinue;
    }

    const int stride = bundle->inputStride;
    const auto& m = st.map;
    const double master = st.masterGain;
    const double lfeGain = st.lfeGain;
    const bool useLfeLowpass = st.useLfeLowpass;
    const bool swap = st.swapOutputs;
    const bool clip = st.clipOutput;
    const double activeThreshold = st.activeThresholdLinear;
    uint32_t localActiveMask = 0;
    std::array<double, kBedChannels916> localInputPeaks{};
    std::array<double, kBedChannels916> localInputTransients{};
    double localPeakLeft = 0.0;
    double localPeakRight = 0.0;
    uint32_t localClipFlags = 0;
    bool shouldClearSubThresholdState = false;

    for (unsigned long n = 0; n < frameCount; ++n) {
        const float* s = in + static_cast<size_t>(n) * stride;

        const auto sampleForBed = [&](int bedIndex) -> double {
            const int sourceIndex = m[bedIndex];
            if (sourceIndex < 0 || sourceIndex >= stride) return 0.0;
            return static_cast<double>(s[sourceIndex]);
        };

        const double L   = sampleForBed(0);
        const double R   = sampleForBed(1);
        const double C   = sampleForBed(2);
        const double LFE = sampleForBed(3) * lfeGain;
        const double Ls  = sampleForBed(4);
        const double Rs  = sampleForBed(5);
        const double Lrs = sampleForBed(6);
        const double Rrs = sampleForBed(7);
        const double Lw  = sampleForBed(8);
        const double Rw  = sampleForBed(9);
        const double Ltf = sampleForBed(10);
        const double Rtf = sampleForBed(11);
        const double Ltm = sampleForBed(12);
        const double Rtm = sampleForBed(13);
        const double Ltr = sampleForBed(14);
        const double Rtr = sampleForBed(15);

        bool frameHadAboveThresholdInput = false;
        for (int ch = 0; ch < kBedChannels916; ++ch) {
            const int sourceIndex = m[ch];
            if (sourceIndex < 0 || sourceIndex >= stride) continue;
            const double absSample = std::fabs(static_cast<double>(s[sourceIndex]));
            if (absSample > localInputPeaks[ch]) localInputPeaks[ch] = absSample;

            // Lightweight onset telemetry for the UI wave-equation visualization.
            // This is not in the audio path. It follows each source channel with a
            // fast envelope and a slow envelope; their difference estimates the
            // current transient/impulse strength for visual source injection.
            double fast = st.transientFastEnv[ch];
            double slow = st.transientSlowEnv[ch];
            const double fastCoeff = (absSample > fast) ? 0.55 : 0.12;
            fast += (absSample - fast) * fastCoeff;
            slow += (absSample - slow) * 0.0025;
            st.transientFastEnv[ch] = fast;
            st.transientSlowEnv[ch] = slow;
            const double onset = std::max(0.0, fast - slow);
            if (onset > localInputTransients[ch]) localInputTransients[ch] = onset;

            if (absSample >= activeThreshold) {
                localActiveMask |= (uint32_t(1) << ch);
                frameHadAboveThresholdInput = true;
            }
        }

        double left = 0.0;
        double right = 0.0;

        const double dryLeft =
            (1.00000000 * L) +
            (0.70710678 * C) +
            (1.00000000 * Ls) +
            (1.00000000 * Lrs) +
            (1.00000000 * Lw) +
            (1.00000000 * Ltf) +
            (1.00000000 * Ltm) +
            (1.00000000 * Ltr);

        const double dryRight =
            (1.00000000 * R) +
            (0.70710678 * C) +
            (1.00000000 * Rs) +
            (1.00000000 * Rrs) +
            (1.00000000 * Rw) +
            (1.00000000 * Rtf) +
            (1.00000000 * Rtm) +
            (1.00000000 * Rtr);

        const StereoFrame alignedDry = useLfeLowpass ? processDryDelaySample(st, dryLeft, dryRight) : StereoFrame{dryLeft, dryRight};
        const double filteredLFE = useLfeLowpass ? processLfeLowpassSample(st, LFE) : LFE;

        left = (alignedDry.left + (kLfeAdc2Coefficient * filteredLFE)) * master;
        right = (alignedDry.right + (kLfeAdc2Coefficient * filteredLFE)) * master;

        // Global output PEQ is shared in coefficient settings, with separate L/R filter state.
        left = processPeqSample(st.globalPeqLeft, left);
        right = processPeqSample(st.globalPeqRight, right);

        // L/R swap is a routing operation. Do it before per-output PEQ so the
        // individual Left/Right PEQ blocks always mean physical output channels.
        if (swap) std::swap(left, right);

        // Per-output Speaker EQ stage. The web launcher flips the selected
        // CH:0/CH:1 correction channels when output swap is enabled so
        // channel-specific correction follows the swapped outputs.
        left = processPeqSample(st.speakerOutputPeqLeft, left);
        right = processPeqSample(st.speakerOutputPeqRight, right);

        // Hard-zero sub-threshold output. This prevents the renderer, delay line,
        // and IIR/PEQ state from leaking denormal or residual tail energy into the
        // DAC when the output is below the same threshold used by the UI meters.
        // With the current app default, anything below -160 dBFS is digital zero.
        const bool outputBelowGate = belowSilenceGate(left, activeThreshold) && belowSilenceGate(right, activeThreshold);
        if (outputBelowGate) {
            left = 0.0;
            right = 0.0;
            if (!frameHadAboveThresholdInput) shouldClearSubThresholdState = true;
        }

        localPeakLeft = std::max(localPeakLeft, std::abs(left));
        localPeakRight = std::max(localPeakRight, std::abs(right));
        if (std::abs(left) > 1.0) localClipFlags |= 0x1u;
        if (std::abs(right) > 1.0) localClipFlags |= 0x2u;

        if (clip) {
            left = std::max(-1.0, std::min(1.0, left));
            right = std::max(-1.0, std::min(1.0, right));
        }

        out[2 * n + 0] = static_cast<float>(left);
        out[2 * n + 1] = static_cast<float>(right);
    }
    if (localActiveMask != 0) {
        st.recentActiveMask.fetch_or(localActiveMask, std::memory_order_relaxed);
    }
    for (int ch = 0; ch < kBedChannels916; ++ch) {
        if (localInputPeaks[ch] > 0.0) atomicMax(st.recentInputPeaks[ch], localInputPeaks[ch]);
        if (localInputTransients[ch] > 0.0) atomicMax(st.recentInputTransients[ch], localInputTransients[ch]);
    }
    if (localPeakLeft > 0.0) atomicMax(st.recentOutputPeakLeft, localPeakLeft);
    if (localPeakRight > 0.0) atomicMax(st.recentOutputPeakRight, localPeakRight);
    if (localClipFlags != 0) st.recentClipFlags.fetch_or(localClipFlags, std::memory_order_relaxed);
    if (shouldClearSubThresholdState) {
        clearSubThresholdProcessingState(st);
    }
    return paContinue;
}

void handleSignal(int) {
    g_shouldStop.store(true, std::memory_order_relaxed);
}

void startParentDeathWatchdog() {
#if defined(__APPLE__) || defined(__unix__)
    const pid_t parentPid = getppid();
    if (parentPid <= 1) return;
    std::thread([parentPid]() {
        while (!g_shouldStop.load(std::memory_order_relaxed)) {
            if (getppid() != parentPid) {
                std::cerr << "\nParent launcher exited; stopping renderer.\n";
                g_shouldStop.store(true, std::memory_order_relaxed);
                return;
            }
            std::this_thread::sleep_for(std::chrono::milliseconds(250));
        }
    }).detach();
#endif
}

}  // namespace

int main(int argc, char** argv) {
    try {
        PaError err = Pa_Initialize();
        if (err != paNoError) {
            std::cerr << "Pa_Initialize failed: " << Pa_GetErrorText(err) << '\n';
            return 1;
        }

        try {
            Config cfg = parseArgs(argc, argv);
            if (cfg.listDevices || cfg.listOutputDevices) {
                listDevices(cfg.listOutputDevices);
                Pa_Terminate();
                return 0;
            }

            startParentDeathWatchdog();

            const PaDeviceInfo* inInfo = cfg.keepOutputAlive ? nullptr : Pa_GetDeviceInfo(cfg.inputDevice);
            const PaDeviceInfo* outInfo = Pa_GetDeviceInfo(cfg.outputDevice);
            if (!outInfo || (!cfg.keepOutputAlive && !inInfo)) die("Could not query device info after argument parsing.");

            if (cfg.keepOutputAlive) {
                const double requestedOutputLatency = (cfg.outputLatencyMs > 0.0)
                    ? std::max(cfg.outputLatencyMs / 1000.0, outInfo->defaultLowOutputLatency)
                    : outInfo->defaultLowOutputLatency;

                PaStreamParameters outParams{};
                outParams.device = cfg.outputDevice;
                outParams.channelCount = kStereoOutChannels;
                outParams.sampleFormat = paFloat32;
                outParams.suggestedLatency = requestedOutputLatency;
                outParams.hostApiSpecificStreamInfo = nullptr;

#ifdef __APPLE__
                PaMacCoreStreamInfo macStreamInfo{};
                unsigned long macFlags = 0;
                if (cfg.macProMode) macFlags |= paMacCorePro;
                if (cfg.macAllowDeviceParameterChanges) macFlags |= paMacCoreChangeDeviceParameters;
                PaMacCore_SetupStreamInfo(&macStreamInfo, macFlags);
                outParams.hostApiSpecificStreamInfo = &macStreamInfo;
#endif

                err = Pa_IsFormatSupported(nullptr, &outParams, cfg.sampleRate);
                if (err != paFormatIsSupported) {
                    die(std::string("Requested output keep-alive format is not supported: ") + Pa_GetErrorText(err));
                }

                KeepAliveState keepAlive;
                PaStream* stream = nullptr;
                const PaStreamFlags flags = paClipOff | paDitherOff | paPrimeOutputBuffersUsingStreamCallback;
                err = Pa_OpenStream(&stream,
                                    nullptr,
                                    &outParams,
                                    cfg.sampleRate,
                                    cfg.framesPerBuffer,
                                    flags,
                                    outputKeepAliveCallback,
                                    &keepAlive);
                if (err != paNoError) {
                    die(std::string("Pa_OpenStream output keep-alive failed: ") + Pa_GetErrorText(err));
                }

                err = Pa_StartStream(stream);
                if (err != paNoError) {
                    Pa_CloseStream(stream);
                    die(std::string("Pa_StartStream output keep-alive failed: ") + Pa_GetErrorText(err));
                }

                std::cout << "Output keep-alive stream started." << std::endl;

                const PaStreamInfo* streamInfo = Pa_GetStreamInfo(stream);
                std::signal(SIGINT, handleSignal);
                std::signal(SIGTERM, handleSignal);

                std::cout << "Starting output keep-alive silent stream\n";
                std::cout << "Output device: [" << cfg.outputDevice << "] " << outInfo->name << '\n';
                std::cout << "Sample rate:   " << cfg.sampleRate << '\n';
                std::cout << "Frames/buffer: " << cfg.framesPerBuffer << '\n';
                std::cout << "Requested output latency: " << (requestedOutputLatency * 1000.0) << " ms"
                          << " (configured " << cfg.outputLatencyMs << " ms, device low "
                          << (outInfo->defaultLowOutputLatency * 1000.0) << " ms, high "
                          << (outInfo->defaultHighOutputLatency * 1000.0) << " ms)\n";
                if (streamInfo) {
                    std::cout << "Actual stream output latency: " << (streamInfo->outputLatency * 1000.0) << " ms\n";
                }
#ifdef __APPLE__
                std::cout << "macOS pro mode: " << (cfg.macProMode ? "true" : "false") << '\n';
                std::cout << "Allow device parameter changes: " << (cfg.macAllowDeviceParameterChanges ? "true" : "false") << '\n';
#endif
                std::cout << "Keep-alive mode: writing digital silence to keep the selected output device open.\n";

                int keepAliveExitCode = 0;
                uint64_t lastKeepAliveCallbacks = keepAlive.callbackCount.load(std::memory_order_relaxed);
                auto lastKeepAliveCallbackAdvance = std::chrono::steady_clock::now();
                auto nextKeepAliveHealthTick = std::chrono::steady_clock::now() + std::chrono::milliseconds(kStreamHealthCheckIntervalMs);

                while (!g_shouldStop.load(std::memory_order_relaxed)) {
                    const auto now = std::chrono::steady_clock::now();
                    if (now >= nextKeepAliveHealthTick) {
                        const PaError active = Pa_IsStreamActive(stream);
                        if (active < 0) {
                            std::cerr << "\n[" << localTimestampNow() << "] Pa_IsStreamActive failed for output keep-alive: "
                                      << Pa_GetErrorText(active)
                                      << ". Core Audio service may have restarted; exiting so launcher can reopen the stream.\n";
                            keepAliveExitCode = 1;
                            break;
                        }
                        if (active == 0) {
                            std::cerr << "\n[" << localTimestampNow() << "] Output keep-alive stream became inactive. "
                                      << "Core Audio service may have restarted; exiting so launcher can reopen the stream.\n";
                            keepAliveExitCode = 1;
                            break;
                        }

                        const uint64_t callbacksNow = keepAlive.callbackCount.load(std::memory_order_relaxed);
                        if (callbacksNow != lastKeepAliveCallbacks) {
                            lastKeepAliveCallbacks = callbacksNow;
                            lastKeepAliveCallbackAdvance = now;
                        } else {
                            const auto stalledFor = std::chrono::duration_cast<std::chrono::milliseconds>(now - lastKeepAliveCallbackAdvance).count();
                            if (stalledFor >= kKeepAliveCallbackStallTimeoutMs) {
                                std::cerr << "\n[" << localTimestampNow() << "] Output keep-alive callback stalled for "
                                          << stalledFor << " ms. Core Audio service may have restarted; "
                                          << "exiting so launcher can reopen the stream.\n";
                                keepAliveExitCode = 1;
                                break;
                            }
                        }

                        nextKeepAliveHealthTick += std::chrono::milliseconds(kStreamHealthCheckIntervalMs);
                        if (nextKeepAliveHealthTick < now) {
                            nextKeepAliveHealthTick = now + std::chrono::milliseconds(kStreamHealthCheckIntervalMs);
                        }
                    }
                    std::this_thread::sleep_for(std::chrono::milliseconds(50));
                }

                if (keepAliveExitCode == 0) {
                    err = Pa_StopStream(stream);
                    if (err != paNoError) std::cerr << "Pa_StopStream output keep-alive warning: " << Pa_GetErrorText(err) << '\n';
                } else {
                    err = Pa_AbortStream(stream);
                    if (err != paNoError) std::cerr << "Pa_AbortStream output keep-alive warning: " << Pa_GetErrorText(err) << '\n';
                }
                err = Pa_CloseStream(stream);
                if (err != paNoError) std::cerr << "Pa_CloseStream output keep-alive warning: " << Pa_GetErrorText(err) << '\n';

                std::cout << "\nKeep-alive callbacks: " << keepAlive.callbackCount.load() << '\n';
                std::cout << "Keep-alive output underflows: " << keepAlive.outputUnderflows.load() << '\n';
                std::cout << "Keep-alive output overflows: " << keepAlive.outputOverflows.load() << '\n';

                Pa_Terminate();
                return keepAliveExitCode;
            }

            const double requestedInputLatency = (cfg.inputLatencyMs > 0.0)
                ? std::max(cfg.inputLatencyMs / 1000.0, inInfo->defaultLowInputLatency)
                : inInfo->defaultLowInputLatency;
            const double requestedOutputLatency = (cfg.outputLatencyMs > 0.0)
                ? std::max(cfg.outputLatencyMs / 1000.0, outInfo->defaultLowOutputLatency)
                : outInfo->defaultLowOutputLatency;

            PaStreamParameters inParams{};
            inParams.device = cfg.inputDevice;
            inParams.channelCount = cfg.inputChannels;
            inParams.sampleFormat = paFloat32;
            inParams.suggestedLatency = requestedInputLatency;
            inParams.hostApiSpecificStreamInfo = nullptr;

            PaStreamParameters outParams{};
            outParams.device = cfg.outputDevice;
            outParams.channelCount = kStereoOutChannels;
            outParams.sampleFormat = paFloat32;
            outParams.suggestedLatency = requestedOutputLatency;
            outParams.hostApiSpecificStreamInfo = nullptr;

#ifdef __APPLE__
            PaMacCoreStreamInfo macStreamInfo{};
            unsigned long macFlags = 0;
            if (cfg.macProMode) macFlags |= paMacCorePro;
            if (cfg.macAllowDeviceParameterChanges) macFlags |= paMacCoreChangeDeviceParameters;
            PaMacCore_SetupStreamInfo(&macStreamInfo, macFlags);
            inParams.hostApiSpecificStreamInfo = &macStreamInfo;
            outParams.hostApiSpecificStreamInfo = &macStreamInfo;
#endif

            err = Pa_IsFormatSupported(&inParams, &outParams, cfg.sampleRate);
            if (err != paFormatIsSupported) {
                die(std::string("Requested stream format is not supported: ") + Pa_GetErrorText(err));
            }

            CallbackBundle bundle;
            bundle.inputStride = cfg.inputChannels;
            bundle.state.map = cfg.inputMap;
            bundle.state.masterGain = cfg.masterGain;
            bundle.state.lfeGain = cfg.lfeGain;
            bundle.state.useLfeLowpass = cfg.useLfeLowpass;
            bundle.state.swapOutputs = cfg.swapOutputs;
            bundle.state.globalPeqLeft = makePeqRuntime(cfg.globalPeq, cfg.sampleRate);
            bundle.state.globalPeqRight = makePeqRuntime(cfg.globalPeq, cfg.sampleRate);
            bundle.state.speakerOutputPeqLeft = makePeqRuntime(cfg.speakerOutputPeqLeft, cfg.sampleRate);
            bundle.state.speakerOutputPeqRight = makePeqRuntime(cfg.speakerOutputPeqRight, cfg.sampleRate);
            bundle.state.clipOutput = cfg.clipOutput;
            bundle.state.activeThresholdLinear = cfg.activeThresholdLinear;
            for (auto& sectionState : bundle.state.lfeFilterState) {
                sectionState = {};
            }
            const size_t dryDelaySamples = cfg.useLfeLowpass
                ? static_cast<size_t>(std::max(0, cfg.dryDelayOverrideSamples >= 0
                    ? cfg.dryDelayOverrideSamples
                    : static_cast<int>(kLfeDryDelaySamples)))
                : 0;
            bundle.state.dryDelaySamples = dryDelaySamples;
            bundle.state.dryDelayBuffer.assign(dryDelaySamples, {});
            bundle.state.dryDelayPos = 0;

            PaStream* stream = nullptr;
            const PaStreamFlags flags = paClipOff | paDitherOff | paPrimeOutputBuffersUsingStreamCallback;

            err = Pa_OpenStream(&stream,
                                &inParams,
                                &outParams,
                                cfg.sampleRate,
                                cfg.framesPerBuffer,
                                flags,
                                audioCallbackStride,
                                &bundle);
            if (err != paNoError) {
                die(std::string("Pa_OpenStream failed: ") + Pa_GetErrorText(err));
            }

            err = Pa_StartStream(stream);
            if (err != paNoError) {
                Pa_CloseStream(stream);
                die(std::string("Pa_StartStream failed: ") + Pa_GetErrorText(err));
            }

            std::cout << "Renderer stream started." << std::endl;

            const PaStreamInfo* streamInfo = Pa_GetStreamInfo(stream);
            std::signal(SIGINT, handleSignal);
            std::signal(SIGTERM, handleSignal);

            std::cout << "Starting low-latency 9.1.6 renderer\n";
            std::cout << "Input device:  [" << cfg.inputDevice << "] " << inInfo->name << '\n';
            std::cout << "Output device: [" << cfg.outputDevice << "] " << outInfo->name << '\n';
            std::cout << "Bed order:     " << kBedOrder916 << '\n';
            std::cout << "Sample rate:   " << cfg.sampleRate << '\n';
            std::cout << "Frames/buffer: " << cfg.framesPerBuffer << '\n';
            std::cout << "Requested input latency: " << (requestedInputLatency * 1000.0) << " ms"
                      << " (configured " << cfg.inputLatencyMs << " ms, device low "
                      << (inInfo->defaultLowInputLatency * 1000.0) << " ms, high "
                      << (inInfo->defaultHighInputLatency * 1000.0) << " ms)\n";
            std::cout << "Requested output latency: " << (requestedOutputLatency * 1000.0) << " ms"
                      << " (configured " << cfg.outputLatencyMs << " ms, device low "
                      << (outInfo->defaultLowOutputLatency * 1000.0) << " ms, high "
                      << (outInfo->defaultHighOutputLatency * 1000.0) << " ms)\n";
            if (streamInfo) {
                std::cout << "Actual stream input latency: " << (streamInfo->inputLatency * 1000.0) << " ms\n";
                std::cout << "Actual stream output latency: " << (streamInfo->outputLatency * 1000.0) << " ms\n";
            }
            std::cout << "Input channels opened: " << cfg.inputChannels << '\n';
            std::cout << "Input map (1-based): " << inputMapToString(cfg.inputMap) << '\n';
            std::cout << "Master gain:   " << 20.0 * std::log10(std::max(cfg.masterGain, 1e-20)) << " dB\n";
            std::cout << "LFE gain:      " << 20.0 * std::log10(std::max(cfg.lfeGain, 1e-20)) << " dB\n";
            if (cfg.useLfeLowpass) {
                std::cout << "LFE filter:    Butterworth order " << kLfeButterworthOrder
                          << " low-pass, cutoff=" << kLfeButterworthCutoffHz
                          << " Hz, 24 dB/octave\n";
                std::cout << "Phase fit band: " << kLfePhaseFitBandLowHz
                          << "-" << kLfePhaseFitBandHighHz << " Hz\n";
                std::cout << "Dry delay:     " << dryDelaySamples << " samples ("
                          << (static_cast<double>(dryDelaySamples) / cfg.sampleRate * 1000.0)
                          << " ms)"
                          << (cfg.dryDelayOverrideSamples >= 0 ? " (manual override)" : "") << "\n";
            } else {
                std::cout << "LFE filter:    Dry ADC2 direct LFE, no low-pass\n";
            }
            std::cout << "Swap outputs:  " << (cfg.swapOutputs ? "true" : "false") << '\n';
            std::cout << "User/global PEQ:       " << peqSummary(cfg.globalPeq) << " (pre-swap, both channels)" << '\n';
            std::cout << "Speaker PEQ left:      " << peqSummary(cfg.speakerOutputPeqLeft) << " (post-swap left; launcher flips CH selection when swap is on)" << '\n';
            std::cout << "Speaker PEQ right:     " << peqSummary(cfg.speakerOutputPeqRight) << " (post-swap right; launcher flips CH selection when swap is on)" << '\n';
            std::cout << "Clip output:   " << (cfg.clipOutput ? "true" : "false") << '\n';
            if (cfg.showActiveInputs) {
                std::cout << "Active threshold: "
                          << 20.0 * std::log10(std::max(cfg.activeThresholdLinear, 1e-20)) << " dBFS\n";
            }
            std::cout << "Show output meter: " << (cfg.showOutputMeter ? "true" : "false") << '\n';
            if (cfg.showActiveInputs || cfg.showOutputMeter) {
                std::cout << "Status update interval: " << cfg.statusUpdateIntervalMs << " ms\n";
            }
            if (cfg.xrunLogIntervalMs > 0) {
                std::cout << "Audio-status event check interval: " << cfg.xrunLogIntervalMs << " ms\n";
                std::cout << "Audio-status event logging: prints input underflows, input overflows, output underflows, output overflows, and null-input callbacks\n";
            } else {
                std::cout << "Audio-status event logging: disabled\n";
            }
            if (streamInfo) {
                std::cout << "Reported input latency:  " << streamInfo->inputLatency * 1000.0 << " ms\n";
                std::cout << "Reported output latency: " << streamInfo->outputLatency * 1000.0 << " ms\n";
            }
#ifdef __APPLE__
            std::cout << "macOS pro mode: " << (cfg.macProMode ? "true" : "false") << '\n';
            std::cout << "Allow device parameter changes: " << (cfg.macAllowDeviceParameterChanges ? "true" : "false") << '\n';
#endif
            std::cout << "ADC2 direct matrix with selected LFE path:\n";
            std::cout << "  FL  -> [1.00000000, 0.00000000]\n";
            std::cout << "  FR  -> [0.00000000, 1.00000000]\n";
            std::cout << "  FC  -> [0.70710678, 0.70710678]\n";
            std::cout << "  LFE -> [" << kLfeAdc2Coefficient << ", " << kLfeAdc2Coefficient << "] "
                      << (cfg.useLfeLowpass ? "after Butterworth low-pass" : "dry, no low-pass") << "\n";
            std::cout << "  BL/BLC/SL/TFL/TSL/TBL -> [1.00000000, 0.00000000]\n";
            std::cout << "  BR/BRC/SR/TFR/TSR/TBR -> [0.00000000, 1.00000000]\n";
            std::cout << "LFE path: "
                      << (cfg.useLfeLowpass
                          ? "Butterworth 4th-order 125 Hz low-pass, with dry/non-LFE path delayed before summing"
                          : "Dry ADC2 direct LFE")
                      << ", then existing ADC2 direct coefficient\n";

            const bool emitStatus = cfg.showActiveInputs || cfg.showOutputMeter;
            const bool monitorAudioStatus = cfg.xrunLogIntervalMs > 0;
            auto nextStatusTick = std::chrono::steady_clock::now();
            auto nextAudioStatusTick = std::chrono::steady_clock::now();
            XrunCountersSnapshot lastLoggedXrunCounters = readXrunCounters(bundle.state);
            int rendererExitCode = 0;
            uint64_t lastRendererCallbacks = bundle.state.callbackCount.load(std::memory_order_relaxed);
            auto lastRendererCallbackAdvance = std::chrono::steady_clock::now();
            auto nextStreamHealthTick = std::chrono::steady_clock::now() + std::chrono::milliseconds(kStreamHealthCheckIntervalMs);
            if (monitorAudioStatus) {
                nextAudioStatusTick += std::chrono::milliseconds(cfg.xrunLogIntervalMs);
            }
            while (!g_shouldStop.load(std::memory_order_relaxed)) {
                const auto now = std::chrono::steady_clock::now();

                if (emitStatus && now >= nextStatusTick) {
                    const uint32_t mask = bundle.state.recentActiveMask.exchange(0, std::memory_order_relaxed);
                    std::array<double, kBedChannels916> inputPeaks{};
                    std::array<double, kBedChannels916> inputTransients{};
                    for (int ch = 0; ch < kBedChannels916; ++ch) {
                        inputPeaks[ch] = bundle.state.recentInputPeaks[ch].exchange(0.0, std::memory_order_relaxed);
                        inputTransients[ch] = bundle.state.recentInputTransients[ch].exchange(0.0, std::memory_order_relaxed);
                    }
                    const double peakLeft = bundle.state.recentOutputPeakLeft.exchange(0.0, std::memory_order_relaxed);
                    const double peakRight = bundle.state.recentOutputPeakRight.exchange(0.0, std::memory_order_relaxed);
                    const uint32_t clipFlags = bundle.state.recentClipFlags.exchange(0, std::memory_order_relaxed);

                    std::ostringstream status;
                    status << "\rStatus: active=" << activeInputsToString(mask, cfg.inputMap);
                    status << " | levels=" << inputLevelsToString(inputPeaks);
                    if (cfg.showOutputMeter) {
                        status << " | meterL=" << dbfsString(peakLeft) << " dBFS";
                        status << " | meterR=" << dbfsString(peakRight) << " dBFS";
                        status << " | clipL=" << (((clipFlags & 0x1u) != 0) ? 1 : 0);
                        status << " | clipR=" << (((clipFlags & 0x2u) != 0) ? 1 : 0);
                    }
                    status << " | transients=" << inputLevelsToString(inputTransients);
                    status << "          ";
                    std::cout << status.str() << std::flush;
                    nextStatusTick += std::chrono::milliseconds(cfg.statusUpdateIntervalMs);
                    if (nextStatusTick < now) nextStatusTick = now + std::chrono::milliseconds(cfg.statusUpdateIntervalMs);
                }

                if (monitorAudioStatus && now >= nextAudioStatusTick) {
                    const XrunCountersSnapshot current = readXrunCounters(bundle.state);
                    bool changed = false;
                    std::ostringstream event;
                    event << "\n[" << localTimestampNow() << "] Audio status event";

                    const auto addDelta = [&](const char* name, uint64_t nowValue, uint64_t oldValue) {
                        if (nowValue > oldValue) {
                            changed = true;
                            event << ' ' << name << '=' << nowValue << " (+" << (nowValue - oldValue) << ')';
                        }
                    };

                    addDelta("inputUnderflows", current.inputUnderflows, lastLoggedXrunCounters.inputUnderflows);
                    addDelta("inputOverflows", current.inputOverflows, lastLoggedXrunCounters.inputOverflows);
                    addDelta("outputUnderflows", current.outputUnderflows, lastLoggedXrunCounters.outputUnderflows);
                    addDelta("outputOverflows", current.outputOverflows, lastLoggedXrunCounters.outputOverflows);
                    addDelta("nullInputCallbacks", current.nullInputCallbacks, lastLoggedXrunCounters.nullInputCallbacks);

                    if (changed) {
                        event << " callbacks=" << current.callbacks
                              << " totals={iu:" << current.inputUnderflows
                              << ", io:" << current.inputOverflows
                              << ", ou:" << current.outputUnderflows
                              << ", oo:" << current.outputOverflows
                              << ", nullIn:" << current.nullInputCallbacks << '}';

                        event << std::fixed << std::setprecision(6)
                              << " paTimes={iu:" << bundle.state.lastInputUnderflowPaTime.load(std::memory_order_relaxed)
                              << ", io:" << bundle.state.lastInputOverflowPaTime.load(std::memory_order_relaxed)
                              << ", ou:" << bundle.state.lastOutputUnderflowPaTime.load(std::memory_order_relaxed)
                              << ", oo:" << bundle.state.lastOutputOverflowPaTime.load(std::memory_order_relaxed)
                              << ", nullIn:" << bundle.state.lastNullInputPaTime.load(std::memory_order_relaxed)
                              << "} s";
                        std::cout << event.str() << std::endl;
                    }
                    lastLoggedXrunCounters = current;
                    nextAudioStatusTick += std::chrono::milliseconds(cfg.xrunLogIntervalMs);
                    if (nextAudioStatusTick < now) nextAudioStatusTick = now + std::chrono::milliseconds(cfg.xrunLogIntervalMs);
                }

                if (now >= nextStreamHealthTick) {
                    const PaError active = Pa_IsStreamActive(stream);
                    if (active < 0) {
                        std::cerr << "\n[" << localTimestampNow() << "] Pa_IsStreamActive failed: "
                                  << Pa_GetErrorText(active)
                                  << ". Core Audio service may have restarted; exiting so launcher can reopen the stream.\n";
                        rendererExitCode = 1;
                        break;
                    }
                    if (active == 0) {
                        std::cerr << "\n[" << localTimestampNow() << "] Audio stream became inactive. "
                                  << "Core Audio service may have restarted; exiting so launcher can reopen the stream.\n";
                        rendererExitCode = 1;
                        break;
                    }

                    const uint64_t callbacksNow = bundle.state.callbackCount.load(std::memory_order_relaxed);
                    if (callbacksNow != lastRendererCallbacks) {
                        lastRendererCallbacks = callbacksNow;
                        lastRendererCallbackAdvance = now;
                    } else {
                        const auto stalledFor = std::chrono::duration_cast<std::chrono::milliseconds>(now - lastRendererCallbackAdvance).count();
                        if (stalledFor >= kRendererCallbackStallTimeoutMs) {
                            std::cerr << "\n[" << localTimestampNow() << "] Audio stream callback stalled for "
                                      << stalledFor << " ms. Core Audio service may have restarted; "
                                      << "exiting so launcher can reopen the stream.\n";
                            rendererExitCode = 1;
                            break;
                        }
                    }

                    nextStreamHealthTick += std::chrono::milliseconds(kStreamHealthCheckIntervalMs);
                    if (nextStreamHealthTick < now) {
                        nextStreamHealthTick = now + std::chrono::milliseconds(kStreamHealthCheckIntervalMs);
                    }
                }

                auto nextWake = std::chrono::steady_clock::now() + std::chrono::milliseconds(20);
                if (emitStatus) nextWake = std::min(nextWake, nextStatusTick);
                if (monitorAudioStatus) nextWake = std::min(nextWake, nextAudioStatusTick);
                nextWake = std::min(nextWake, nextStreamHealthTick);
                std::this_thread::sleep_until(nextWake);
            }
            if (cfg.showActiveInputs || cfg.showOutputMeter) std::cout << "\n";

            if (rendererExitCode == 0) {
                err = Pa_StopStream(stream);
                if (err != paNoError) std::cerr << "Pa_StopStream warning: " << Pa_GetErrorText(err) << '\n';
            } else {
                err = Pa_AbortStream(stream);
                if (err != paNoError) std::cerr << "Pa_AbortStream warning: " << Pa_GetErrorText(err) << '\n';
            }
            err = Pa_CloseStream(stream);
            if (err != paNoError) std::cerr << "Pa_CloseStream warning: " << Pa_GetErrorText(err) << '\n';

            std::cout << "\nCallbacks:         " << bundle.state.callbackCount.load() << '\n';
            std::cout << "Input underflows:  " << bundle.state.inputUnderflows.load() << '\n';
            std::cout << "Input overflows:   " << bundle.state.inputOverflows.load() << '\n';
            std::cout << "Output underflows: " << bundle.state.outputUnderflows.load() << '\n';
            std::cout << "Output overflows:  " << bundle.state.outputOverflows.load() << '\n';
            std::cout << "Null-input callbacks: " << bundle.state.nullInputCallbacks.load() << '\n';

            Pa_Terminate();
            return rendererExitCode;
        } catch (...) {
            Pa_Terminate();
            throw;
        }
    } catch (const std::exception& e) {
        std::cerr << "Error: " << e.what() << '\n';
        return 1;
    }
}
