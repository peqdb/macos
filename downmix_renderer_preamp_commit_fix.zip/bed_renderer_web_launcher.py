#!/usr/bin/env python3
import atexit
import json
import os
import re
import sys
import signal
import socket
import subprocess
import tempfile
import threading
import time
import uuid
import webbrowser
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from urllib.parse import parse_qs, urlparse

BED_LABELS = [
    "L", "R", "C", "LFE", "Ls", "Rs", "Lrs", "Rrs",
    "Lw", "Rw", "Ltf", "Rtf", "Ltm", "Rtm", "Ltr", "Rtr"
]

LAYOUT_PRESETS = {
    "9.1.6 bed (1:1)": [1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16],
    "7.1.4":           [1, 2, 3, 4, 5, 6, 7, 8, 0, 0, 9, 10, 11, 12, 0, 0],
    "7.1.2":           [1, 2, 3, 4, 5, 6, 7, 8, 0, 0, 9, 10, 0, 0, 0, 0],
    "7.1":             [1, 2, 3, 4, 5, 6, 7, 8, 0, 0, 0, 0, 0, 0, 0, 0],
    "5.1.4":           [1, 2, 3, 4, 5, 6, 0, 0, 0, 0, 7, 8, 9, 10, 0, 0],
    "5.1.2":           [1, 2, 3, 4, 5, 6, 0, 0, 0, 0, 7, 8, 0, 0, 0, 0],
    "5.1":             [1, 2, 3, 4, 5, 6, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0],
    "3.1":             [1, 2, 3, 4, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0],
    "3.0":             [1, 2, 3, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0],
    "2.1":             [1, 2, 0, 3, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0],
    "2.0 stereo":      [1, 2, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0],
}

DEVICE_RE = re.compile(r"^\[(\d+)\]\s*(?:\[default-in\]\s*)?(?:\[default-out\]\s*)?(.*?)\s*\|\s*in:\s*(\d+)\s*\|\s*out:\s*(\d+)")
STATUS_RE = re.compile(
    r"Status:\s*active=(.*?)\s*(?:\|\s*levels=([^|]*))?\|\s*meterL=([^\s]+)\s+dBFS\s*\|\s*meterR=([^\s]+)\s+dBFS\s*\|\s*clipL=(\d+)\s*\|\s*clipR=(\d+)(?:\s*\|\s*transients=([^|]*))?"
)
ACTIVE_ITEM_RE = re.compile(r"\d+\(([^)]+)\)")
CLIP_INDICATOR_LATCH_SECONDS = 0.200
DEVICE_ENUMERATION_TIMEOUT_SECONDS = 2.5
RENDERER_STARTUP_TIMEOUT_SECONDS = 5.0
COREAUDIO_RECOVERY_TOTAL_TIMEOUT_SECONDS = 10.0
START_DEVICE_STABLE_SECONDS = 0.0
START_DEVICE_SCAN_MAX_AGE_SECONDS = 60.0


class TransientAudioDeviceError(RuntimeError):
    pass


def default_input_levels_db():
    return {label: "-inf" for label in BED_LABELS}


def parse_input_levels_db(levels_text):
    levels = default_input_levels_db()
    if not levels_text:
        return levels
    for item in levels_text.split(','):
        if ':' not in item:
            continue
        label, value = item.split(':', 1)
        label = label.strip()
        value = value.strip()
        if label in levels and value:
            levels[label] = value
    return levels


PREFS_PATH = Path.home() / ".bed_renderer_web_launcher.json"
NATIVE_BRIDGE = None

MIC_PERMISSION_HELP = "Microphone access is required to open the selected input device. Enable it in System Settings > Privacy & Security > Microphone for Downmix Renderer, then reopen the app and try again."


def request_microphone_access_for_launch():
    result = {
        "supported": False,
        "granted": True,
        "state": "deferred",
        "api": None,
        "error": None,
    }
    if sys.platform != "darwin":
        result["supported"] = True
        result["state"] = "not_applicable"
        result["api"] = "non-macOS"
        return result

    # Important: do not call requestAccessForMediaType here. The macOS TCC
    # prompt must only be caused by an intentional renderer start that opens
    # the selected input stream. Calling the prompt API from launcher/device
    # management paths made stale processes capable of re-triggering
    # "Downmix Renderer requires microphone access" in a loop after an output
    # hot-unplug. This function is now a non-prompting status check only.
    try:
        from AVFoundation import AVCaptureDevice, AVMediaTypeAudio
        result["supported"] = True
        result["api"] = "AVCaptureDevice.authorizationStatus"
        status = int(AVCaptureDevice.authorizationStatusForMediaType_(AVMediaTypeAudio))
        if status == 3:
            result["state"] = "authorized"
            result["granted"] = True
        elif status == 2:
            result["state"] = "denied"
            result["granted"] = False
        elif status == 1:
            result["state"] = "restricted"
            result["granted"] = False
        elif status == 0:
            # Let CoreAudio/PortAudio trigger the one real system prompt only
            # when the user intentionally starts the renderer.
            result["state"] = "not_determined_deferred"
            result["granted"] = True
        else:
            result["state"] = f"unknown_deferred({status})"
            result["granted"] = True
        return result
    except Exception as exc:
        # Failing to query permission should not create another probing path.
        # The real input stream open will report the actual CoreAudio failure.
        result["error"] = f"AVCaptureDevice authorizationStatus unavailable: {exc}"
        result["state"] = "query_failed_deferred"
        result["granted"] = True
        return result

def ensure_microphone_access_for_launch():
    permission = request_microphone_access_for_launch()
    detail = permission.get("error")
    state = permission.get("state") or "unknown"
    api = permission.get("api") or "macOS"
    if permission.get("supported") and permission.get("granted"):
        STATE.append_log(f"Microphone permission authorized via {api}.")
        return permission

    if permission.get("supported"):
        if state == "restricted":
            message = (
                "Microphone access is restricted by macOS and cannot be enabled from the app. "
                "Open System Settings > Privacy & Security > Microphone for Downmix Renderer, then reopen the app."
            )
        elif state == "timed_out":
            message = (
                "Downmix Renderer is waiting for microphone access. Check for the macOS permission prompt, "
                "or enable microphone access in System Settings > Privacy & Security > Microphone, then reopen the app."
            )
        else:
            message = (
                "Microphone access is required to use the selected input device. Enable it in "
                "System Settings > Privacy & Security > Microphone for Downmix Renderer, then reopen the app."
            )
    else:
        message = (
            "Downmix Renderer could not confirm microphone access on macOS. Enable microphone access in "
            "System Settings > Privacy & Security > Microphone, then reopen the app."
        )

    if detail:
        STATE.append_log(f"Microphone permission detail: {detail}")
    with STATE.cond:
        STATE.phase = "error"
        STATE.status_text = message
        STATE.bump_status()
        status_payload = STATE.status_unlocked()
    push_native_status(status_payload)
    raise ValueError(message)

RENDERER_BINARY_NAME = "bed_renderer_916_low_latency"

def bundled_path(name: str) -> str:
    candidates = []

    meipass = getattr(sys, "_MEIPASS", None)
    if meipass:
        candidates.append(Path(meipass) / name)

    script_dir = Path(__file__).resolve().parent
    exe_dir = Path(sys.executable).resolve().parent

    candidates.extend([
        script_dir / name,
        exe_dir / name,
        exe_dir.parent / "Frameworks" / name,
        exe_dir.parent / "Resources" / name,
        Path.cwd() / name,
    ])

    for candidate in candidates:
        if candidate.exists():
            return str(candidate)

    return str(script_dir / name)

def current_renderer_exe() -> str:
    return bundled_path(RENDERER_BINARY_NAME)

def normalize_renderer_exe(saved_exe=None) -> str:
    """Return the renderer that belongs to this copy of the app when available.

    Older builds saved the absolute renderer executable path in
    ~/.bed_renderer_web_launcher.json. If the old app folder still exists, that
    stale path also still exists, so a newer downloaded app can silently keep
    launching the older renderer. The bundled renderer for the currently running
    app should win whenever it is present.
    """
    current = str(current_renderer_exe()).strip()
    saved = str(saved_exe or "").strip()
    if current and os.path.exists(current):
        if not saved:
            return current
        try:
            if Path(saved).name == RENDERER_BINARY_NAME and Path(saved).resolve() != Path(current).resolve():
                return current
        except Exception:
            if Path(saved).name == RENDERER_BINARY_NAME and saved != current:
                return current
        if not os.path.exists(saved):
            return current
    return saved or current

DEFAULT_PREFS = {
    "exe": current_renderer_exe(),
    "preset": "9.1.6 bed (1:1)",
    "frames": "64",
    "input_latency_ms": "10",
    "output_latency_ms": "10",
    "keep_output_alive": True,
    "input_channels": "16",
    "threshold": "-160",
    "preamp_db": "-9.5",
    "lfe_lowpass": True,
    "swap_outputs": False,
    "global_output_peq_text": "",
    "speaker_output_peq_text": "",
    "routing_peq_profiles": {},
    "active_routing_peq_profile": "",
    "input_device": "",
    "output_device": "",
    "input_device_name": "",
    "output_device_name": "",
    "input_collapsed": False,
    "output_collapsed": False,
    "settings_collapsed": False,
    "routing_peq_collapsed": False,
    "visualizer_collapsed": False,
    "log_collapsed": False,
    "map": [str(x) for x in LAYOUT_PRESETS["9.1.6 bed (1:1)"]],
}

HTML = r'''<!doctype html>
<html>
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>Downmix Renderer</title>
<style>
:root{
  --bg:#000000; --panel:#000000; --panel2:#000000; --line:#343842; --text:#f5f7fb; --muted:#aeb5c1;
  --accent:#62a8ff; --good:#58d26d; --warn:#ffd166; --bad:#ff5d73; --stop:#7f8794;
}
*{box-sizing:border-box;-webkit-user-select:none;user-select:none}
html,body{margin:0;background:#000000;color:var(--text);font:16px -apple-system,BlinkMacSystemFont,Segoe UI,Roboto,sans-serif;min-height:100vh;height:100%;width:100%;max-width:100%;overflow-x:hidden;}
body{background:#000000;overscroll-behavior-x:none;}
input,textarea,select{ -webkit-user-select:text; user-select:text; }
.wrap{position:relative;width:100vw;max-width:none;min-height:100vh;margin:0;padding:12px 12px 14px;box-sizing:border-box;background:#000000;overflow-x:hidden}
.card{background:transparent;border:1px solid rgba(52,56,66,.72);border-radius:16px;padding:16px 18px;margin-bottom:14px;box-shadow:none;backdrop-filter:none}
details.card.sectioncollapse{padding:0;overflow:hidden}
.sectioncollapse > summary{list-style:none;display:grid;grid-template-columns:minmax(0,1fr) auto auto;align-items:center;gap:12px;padding:16px 18px;cursor:pointer;font-weight:850;font-size:20px;user-select:none}
.sectioncollapse > summary::-webkit-details-marker{display:none}
.sectioncollapse > summary .summaryvalue{min-width:0;max-width:100%;font-size:14px;font-weight:650;color:var(--muted);white-space:nowrap;overflow:hidden;text-overflow:ellipsis;justify-self:end}
.sectioncollapse > summary::after{content:'▾';font-size:18px;color:var(--muted);transition:transform .14s ease,color .14s ease}
.sectioncollapse[open] > summary{border-bottom:1px solid rgba(255,255,255,.06)}
.sectioncollapse[open] > summary::after{transform:rotate(0deg);color:var(--text)}
.sectioncollapse:not([open]) > summary::after{transform:rotate(-90deg)}
.sectionbody{padding:16px 18px 18px 18px}
.row{display:grid;gap:12px}
.r2{grid-template-columns:1fr 1fr}
.visualmeterrow{grid-template-columns:1fr;align-items:start}
.visualmeterrow .badges{height:min(calc(100vh - 210px),860px);min-height:560px;max-height:860px;width:100%;aspect-ratio:auto}
.r3{grid-template-columns:repeat(3,1fr)}
.r4{grid-template-columns:repeat(4,1fr)}
.r5{grid-template-columns:2fr 1fr 1fr 1fr 1fr}
label{display:block;font-weight:700;margin-bottom:6px}
.checkrow{display:flex;align-items:center;gap:10px;font-weight:600;margin:0;padding:12px 14px;border:1px solid rgba(52,56,66,.72);border-radius:12px;background:transparent;color:var(--text);min-height:48px;backdrop-filter:none}
.checkrow input{width:18px;height:18px;margin:0;accent-color:var(--accent)}
.togglecard{display:flex;align-items:center;justify-content:space-between;gap:14px;margin:0;padding:12px 14px;border:1px solid rgba(52,56,66,.72);border-radius:12px;background:transparent;color:var(--text);min-height:48px;cursor:pointer;transition:border-color .12s ease,box-shadow .12s ease,background .12s ease;backdrop-filter:none}
.togglecard:hover{border-color:rgba(98,168,255,.72);box-shadow:0 0 0 3px rgba(98,168,255,.10)}
.toggletext{font-weight:650;line-height:1.25}
.togglehint{display:block;margin-top:3px;font-size:13px;font-weight:600;color:var(--muted)}
.togglecard input{position:absolute;opacity:0;pointer-events:none}
.switch{position:relative;flex:0 0 46px;width:46px;height:26px;border-radius:999px;background:#2a2d35;border:1px solid #454955;transition:background .12s ease,border-color .12s ease}
.switch::after{content:"";position:absolute;width:20px;height:20px;left:2px;top:2px;border-radius:999px;background:#cfd5df;box-shadow:0 2px 5px rgba(0,0,0,.35);transition:transform .12s ease,background .12s ease}
.togglecard input:checked + .switch{background:rgba(98,168,255,.42);border-color:rgba(98,168,255,.75)}
.togglecard input:checked + .switch::after{transform:translateX(20px);background:#ffffff}
.togglecard:focus-within{border-color:var(--accent);box-shadow:0 0 0 3px rgba(98,168,255,.16)}
input,select,button{width:100%;font:inherit;-webkit-appearance:none;appearance:none}
input,select{background:transparent;color:var(--text);border:1px solid rgba(52,56,66,.78);border-radius:12px;padding:12px 14px;backdrop-filter:none}
input:focus,select:focus,textarea:focus{outline:none;border-color:var(--accent);box-shadow:0 0 0 3px rgba(98,168,255,.16)}
textarea{width:100%;min-height:170px;resize:vertical;background:transparent;color:var(--text);border:1px solid rgba(52,56,66,.78);border-radius:12px;padding:12px 14px;font:13px ui-monospace,SFMono-Regular,Menlo,Consolas,monospace;line-height:1.35;backdrop-filter:none}
#log{width:100%;max-width:100%;min-height:220px;max-height:360px;overflow-y:auto;overflow-x:hidden;white-space:pre-wrap;word-break:break-word;background:transparent;color:var(--text);border:1px solid rgba(52,56,66,.78);border-radius:12px;padding:12px 14px;font:12px ui-monospace,SFMono-Regular,Menlo,Consolas,monospace;line-height:1.35;backdrop-filter:none}
input[type=file]{padding:10px;background:#000000;color:var(--muted)}
.peqgrid{display:grid;grid-template-columns:repeat(2,1fr);gap:12px;margin-top:12px}
.peqbox{border:1px solid rgba(48,52,61,.78);border-radius:14px;background:transparent;padding:12px;backdrop-filter:none}
.peqbox label{margin-top:0}
.fileline{display:grid;grid-template-columns:minmax(0,1fr) auto;gap:8px;align-items:center;margin-bottom:8px}
.fileline button{width:auto;min-width:72px;padding:11px 13px;border-radius:12px}
.profilebar{display:grid;grid-template-columns:minmax(170px,1.2fr) minmax(180px,1.2fr) auto auto auto;gap:8px;align-items:end;margin:4px 0 12px 0;padding:12px;border:1px solid #30343d;border-radius:14px;background:#000000}
.profilebar button{width:auto;min-width:86px;padding:12px 13px;border-radius:12px}
.profilebar label{font-size:14px;color:var(--muted);margin-bottom:5px}
.profilehint{grid-column:1 / -1;color:var(--muted);font-size:13px;line-height:1.35}
@media (max-width:1000px){.peqgrid{grid-template-columns:1fr}.profilebar{grid-template-columns:1fr 1fr}.profilehint{grid-column:1 / -1}}
button{display:flex;align-items:center;justify-content:center;background:#f4f6fa;background-image:none;color:#0d1016;border:0;border-radius:14px;padding:14px 16px;font-weight:800;cursor:pointer;transition:.12s transform,.12s opacity,.12s background,.12s color,.12s border-color;overflow:hidden;-webkit-appearance:none;appearance:none}
button:hover{transform:translateY(-1px)} button:active{transform:translateY(0)}
button.secondary{background:#2a2d35;background-image:none;color:var(--text);border:1px solid #454955}
button.stop{background:#2b2b2e;background-image:none;color:#fff;border:1px solid #44484f}
button:disabled{opacity:1;cursor:not-allowed;transform:none;background:#6f7278;background-image:none;color:#0a0c10;border:1px solid rgba(255,255,255,.10);box-shadow:none}
button.secondary:disabled,button.stop:disabled{background:#17181c;background-image:none;color:#7f858f;border-color:#2b2f38}
.listwrap{display:grid;grid-template-columns:minmax(0,1fr) 16px;gap:10px;align-items:stretch}
.devicelist{
  height:230px; overflow:auto; padding:6px; border-radius:16px; border:1px solid rgba(52,56,66,.78);
  background:transparent; outline:none; scrollbar-width:none; -ms-overflow-style:none;
  transition:border-color .12s ease,box-shadow .12s ease; backdrop-filter:none;
}
.devicelist::-webkit-scrollbar{width:0;height:0;background:transparent}
.devicelist:hover,.devicelist:focus{border-color:var(--accent);box-shadow:0 0 0 3px rgba(98,168,255,.10)}
.devicerow{
  display:block; width:100%; padding:10px 12px; margin:0 0 2px 0; border-radius:12px;
  border:1px solid transparent; background:transparent; color:var(--text);
  cursor:pointer; font:inherit; text-align:left; white-space:nowrap; overflow:hidden; text-overflow:ellipsis;
  transition:background-color .08s ease,color .08s ease,border-color .08s ease,box-shadow .08s ease;
}
.devicerow:hover{background:rgba(98,168,255,.14);color:#f7fbff}
.devicerow.selected{background:rgba(98,168,255,.24);color:#ffffff;border-color:rgba(98,168,255,.55);box-shadow:inset 0 0 0 1px rgba(98,168,255,.22)}
.devicerow:focus-visible{outline:none;background:rgba(98,168,255,.18);border-color:rgba(98,168,255,.45)}
.devicehint{margin-top:10px;color:var(--muted)}
.devicehint.warn{color:var(--warn);font-weight:700}
.incompatpanel{margin-top:10px;border:1px solid rgba(45,49,57,.78);border-radius:12px;background:transparent;overflow:hidden;backdrop-filter:none}
.incompatpanel[hidden]{display:none}
.incompatpanel summary{list-style:none;cursor:pointer;padding:11px 14px;font-weight:700;color:#cfd5df;user-select:none}
.incompatpanel summary::-webkit-details-marker{display:none}
.incompatpanel summary::after{content:'▾';float:right;color:var(--muted);transition:transform .14s ease}
.incompatpanel:not([open]) summary::after{transform:rotate(-90deg)}
.incompatlist{padding:0 14px 12px 14px;display:grid;gap:8px}
.incompatitem{color:#9ea6b5;font-size:14px}
.scrollhint{position:relative;align-self:stretch;margin:8px 0;border-radius:999px;background:rgba(255,255,255,.08);border:1px solid rgba(255,255,255,.18);box-shadow:inset 0 0 0 1px rgba(0,0,0,.15);opacity:0;pointer-events:none;transition:opacity .12s ease,transform .12s ease;transform:translateX(2px)}
.scrollhintthumb{position:absolute;left:2px;right:2px;top:0;height:40px;border-radius:999px;background:linear-gradient(180deg, rgba(146,195,255,.98), rgba(91,156,255,.98));box-shadow:0 0 0 1px rgba(255,255,255,.22), 0 4px 10px rgba(0,0,0,.28)}
.listwrap:hover .scrollhint,.listwrap:focus-within .scrollhint,.listwrap.show-scrollbar .scrollhint{opacity:.98;transform:translateX(0)}
.listwrap.no-scroll .scrollhint{display:none}
.grid16{display:grid;grid-template-columns:repeat(4,1fr);gap:10px}
.pair{display:grid;grid-template-columns:56px 1fr;gap:8px;align-items:center}
.toolbar{display:flex;gap:10px;flex-wrap:wrap}
.toolbar button{width:auto;min-width:150px}
.collapsegrid{display:grid;grid-template-columns:1fr 1fr;gap:12px}
.collapse{background:transparent;border:0;margin:0;padding:0}
.collapse > summary{list-style:none;display:grid;grid-template-columns:minmax(0,1fr) auto auto;align-items:center;gap:12px;font-weight:800;font-size:22px;cursor:pointer;padding:6px 4px 12px 4px;user-select:none}
.collapse > summary::-webkit-details-marker{display:none}
.collapse > summary .summaryvalue{min-width:0;max-width:100%;font-size:15px;font-weight:650;color:var(--muted);white-space:nowrap;overflow:hidden;text-overflow:ellipsis;justify-self:end}
.collapse > summary::after{content:'▾';font-size:18px;color:var(--muted);transition:transform .14s ease,color .14s ease}
.collapse[open] > summary::after{transform:rotate(0deg);color:var(--text)}
.collapse:not([open]) > summary::after{transform:rotate(-90deg)}
.collapsebody{padding-top:0}
.statusline{display:flex;gap:14px;align-items:center;flex-wrap:wrap}
.pill{display:inline-flex;align-items:center;gap:10px;padding:12px 16px;border-radius:999px;font-weight:800;border:1px solid #434852;background:#262a33}
.pill .dot{width:10px;height:10px;border-radius:999px;background:#9096a3}
.pill.running{border-color:rgba(88,210,109,.55);background:rgba(88,210,109,.12);color:#e8fff0}
.pill.running .dot{background:var(--good)}
.pill.starting,.pill.stopping{border-color:rgba(255,209,102,.55);background:rgba(255,209,102,.12);color:#fff6d6}
.pill.starting .dot,.pill.stopping .dot{background:var(--warn)}
.pill.error,.pill.disconnected{border-color:rgba(255,93,115,.55);background:rgba(255,93,115,.12);color:#ffe9ed}
.pill.error .dot,.pill.disconnected .dot{background:var(--bad)}
.pill.stopped .dot{background:var(--stop)}
.hint{color:var(--muted)}
.badges{position:relative;--stage-width:min(calc(100% - 360px),calc(110vh - 220px),860px);--sum-meter-width:156px;--badge-size:44px;--badge-font-size:12px;--top-badge-size:38px;--top-badge-font-size:12px;--lfe-width:44px;--lfe-height:44px;--lfe-font-size:10px;height:min(calc(100vh - 180px),820px);min-height:660px;border:0;border-radius:0;background:#000000;overflow:hidden}
.badges::before{content:none}
.badges::after{content:none}
.layoutstage{position:absolute;z-index:1;left:50%;top:50%;width:var(--stage-width);height:auto;aspect-ratio:100/88;transform:translate(-50%,-50%);border:0;border-radius:0;background:transparent;box-shadow:none;overflow:visible}
.layoutstage::after{content:none}
.bedwire{display:none}
.bedwire path,.bedwire line{vector-effect:non-scaling-stroke;fill:none;stroke:rgba(216,223,236,.24);stroke-width:1.05;shape-rendering:geometricPrecision}
.bedwire .rail{stroke:rgba(216,223,236,.24)}
.bedwire .axis{stroke:rgba(216,223,236,.22)}
.roomguide{position:absolute;z-index:0;pointer-events:none}
.roomguide.ceiling{display:none}
.roomguide.axis{display:none}
.roomlabel{display:none}
.listenerdot{position:absolute;z-index:1;left:50%;top:50%;width:64px;height:64px;border-radius:999px;border:1px solid rgba(216,223,236,.22);background:#060606;display:flex;align-items:center;justify-content:center;transform:translate(-50%,-50%);pointer-events:none;user-select:none;box-shadow:none}
.listenerheadtop{position:relative;width:26px;height:32px;opacity:.96;filter:drop-shadow(0 1px 2px rgba(0,0,0,.32))}
.listenerheadtop .skull{position:absolute;left:50%;top:1px;width:18px;height:22px;border:2px solid rgba(216,223,236,.9);border-radius:50% 50% 46% 46% / 56% 56% 42% 42%;transform:translateX(-50%);background:radial-gradient(circle at 50% 38%,rgba(255,255,255,.10),rgba(255,255,255,0))}
.listenerheadtop .ear{position:absolute;top:10px;width:4px;height:8px;border-radius:999px;background:rgba(216,223,236,.72)}
.listenerheadtop .ear.left{left:1px}
.listenerheadtop .ear.right{right:1px}
.listenerheadtop .nose{position:absolute;left:50%;top:20px;width:0;height:0;border-left:4px solid transparent;border-right:4px solid transparent;border-top:8px solid rgba(216,223,236,.72);transform:translateX(-50%)}
.badge{position:absolute;z-index:2;width:var(--badge-size);height:var(--badge-size);padding:0;border-radius:999px;border:1px solid #666d79;background:#121316;text-align:center;font-weight:900;font-size:var(--badge-font-size);line-height:1;color:#f0f3f8;display:flex;align-items:center;justify-content:center;transform:translate(-50%,-50%);white-space:nowrap;letter-spacing:-.01em;transition:background-color .08s linear,border-color .08s linear,box-shadow .08s linear,color .08s linear,text-shadow .08s linear}
.badge.top{width:var(--top-badge-size);height:var(--top-badge-size);font-size:var(--top-badge-font-size);border-style:dashed;background:#0b0c0e;border-color:#767d8a}
.badge.lfe{width:var(--lfe-width);height:var(--lfe-height);border-radius:12px;font-size:var(--lfe-font-size);background:#111214;border-color:#646b76}
.badge.on{color:#ffffff;text-shadow:0 1px 2px rgba(0,0,0,.48)}

#visualizerdetails.card{background:transparent;backdrop-filter:none}
#visualizerdetails .sectionbody{background:transparent}
#badges{background:transparent}

.summeter{position:absolute;z-index:4;top:50%;width:var(--sum-meter-width);--meter-track-height:420px;transform:translateY(-50%);display:grid;grid-template-rows:auto auto;justify-items:center;gap:13px;padding:14px 11px 16px;border-radius:18px;background:transparent;border:0;box-shadow:none}
.summeter.left{left:calc(((100% - var(--stage-width)) / 4) - (var(--sum-meter-width) / 2))}
.summeter.right{right:calc(((100% - var(--stage-width)) / 4) - (var(--sum-meter-width) / 2))}
.sumheader{display:flex;align-items:center;justify-content:center;gap:8px;width:100%;min-height:22px}
.sumtitle{font-size:13px;font-weight:850;line-height:1;color:#eef2fb;letter-spacing:.01em}
.meterclip{position:relative;width:40px;height:14px;border:0;background:transparent;box-shadow:none;font-size:0;color:transparent;overflow:visible}
.meterclip::before{content:"";position:absolute;left:0;top:50%;width:7px;height:7px;border-radius:999px;border:1px solid rgba(216,223,236,.26);background:#15171b;box-shadow:inset 0 0 0 1px rgba(0,0,0,.45);transform:translateY(-50%);transition:background-color .10s ease,border-color .10s ease,box-shadow .10s ease}
.meterclip::after{content:'CLIP';position:absolute;left:13px;top:50%;transform:translateY(-50%);font-size:9px;font-weight:850;letter-spacing:.08em;color:#59616d;opacity:.75;white-space:nowrap;transition:color .10s ease,opacity .10s ease}
.meterclip.on::before{border-color:rgba(255,93,115,.8);background:#ff5d73;box-shadow:0 0 14px rgba(255,93,115,.55)}
.meterclip.on::after{color:#ffdbe1;opacity:1}
.meterbody{position:relative;height:var(--meter-track-height);width:108px;display:flex;align-items:stretch;justify-content:center}
.metertrack{position:absolute;left:12px;top:0;width:30px;height:100%;border-radius:8px;background:#000000;border:1px solid #323640;overflow:hidden;box-shadow:inset 0 0 0 1px rgba(255,255,255,.025), inset 0 0 18px rgba(0,0,0,.55);transition:border-color .08s linear,box-shadow .08s linear}
.metertrack::before{content:none}
.meterfill{position:absolute;left:0;right:0;bottom:0;height:100%;transform-origin:bottom;transform:scaleY(0);background-color:rgba(74,124,255,.44);background-image:linear-gradient(180deg,rgba(255,255,255,.10),rgba(0,0,0,.10));background-blend-mode:normal;border-top:0;box-shadow:none;will-change:transform;pointer-events:none;border-radius:0 0 7px 7px;transition:background-color .08s linear,opacity .08s linear,box-shadow .08s linear,border-color .08s linear}
.meterpeak{display:none}
.meterscale{position:absolute;left:54px;top:0;bottom:0;width:46px;font-size:9px;font-weight:760;color:#7f8794;letter-spacing:.02em;line-height:1;pointer-events:none;user-select:none}
.meterscale .scaletick{position:absolute;left:0;color:#8a929f;text-align:left;white-space:nowrap;transform:translateY(-50%)}
.meterscale .scaletick::before{content:"";position:absolute;left:-11px;top:50%;height:1px;background:rgba(216,223,236,.24)}
.meterscale .scaletick.major{color:#b8c0cc}
.meterscale .scaletick.major::before{width:10px;background:rgba(216,223,236,.46)}
.meterscale .scaletick.minor{font-size:0;color:transparent}
.meterscale .scaletick.minor::before{width:5px;background:rgba(216,223,236,.18)}
.meterscale .scaletick.top{transform:translateY(0);color:#d2d8e2}
.meterscale .scaletick.bottom{transform:translateY(-100%)}
.small{font-size:14px;color:var(--muted)}
.overlay{position:fixed;inset:0;background:rgba(10,10,10,.92);display:none;align-items:center;justify-content:center;z-index:1000;padding:24px}
.overlay.show{display:flex}
.overlay .box{max-width:560px;background:#1a1a1a;border:1px solid #444;border-radius:16px;padding:24px;text-align:center}
@media (max-width:1200px){.visualmeterrow{grid-template-columns:1fr}.visualmeterrow .badges{--stage-width:min(calc(100% - 300px),calc(108vh - 220px),780px);--sum-meter-width:142px;--badge-size:42px;--badge-font-size:12px;--top-badge-size:36px;--top-badge-font-size:11px;--lfe-width:42px;--lfe-height:40px;--lfe-font-size:10px;height:min(calc(100vh - 190px),760px);min-height:600px}.summeter{--meter-track-height:320px}}
@media (max-width:1000px){.r5,.r4,.r3,.r2,.grid16,.collapsegrid{grid-template-columns:1fr 1fr}.visualmeterrow{grid-template-columns:1fr}.badges{--stage-width:min(calc(100% - 250px),calc(106vh - 206px),640px);--sum-meter-width:126px;--badge-size:38px;--badge-font-size:11px;--top-badge-size:32px;--top-badge-font-size:10px;--lfe-width:38px;--lfe-height:36px;--lfe-font-size:9px;min-height:540px}.summeter{--meter-track-height:270px}.meterbody{width:92px}.metertrack{left:10px;width:28px}.meterscale{left:48px;width:38px;font-size:8px}.roomlabel{font-size:10px;letter-spacing:.18em}}
@media (max-width:720px){.r5,.r4,.r3,.r2,.grid16,.collapsegrid{grid-template-columns:1fr}.badges{--stage-width:min(calc(100% - 160px),calc(102vh - 190px),450px);--sum-meter-width:86px;--badge-size:32px;--badge-font-size:9px;--top-badge-size:28px;--top-badge-font-size:8px;--lfe-width:34px;--lfe-height:30px;--lfe-font-size:8px;height:min(calc(100vh - 185px),540px);min-height:410px}.listenerdot{width:50px;height:50px}.listenerheadtop{transform:scale(.78)}.summeter{--meter-track-height:210px;padding:10px 6px 10px;gap:8px}.sumtitle{font-size:11px}.meterclip{width:7px;height:7px}.meterclip::before{width:7px;height:7px}.meterclip::after{font-size:0;content:''}.meterbody{width:70px}.metertrack{left:6px;width:22px}.meterscale{left:36px;font-size:7px;width:30px}.meterscale .scaletick::before{left:-7px;width:4px}.meterscale .scaletick.major::before{width:6px}.meterscale .scaletick.minor::before{width:3px}}
</style>
</head>
<body>
<div id="overlay" class="overlay">
  <div class="box">
    <h2>Launcher disconnected</h2>
    <p id="overlaymsg">The launcher script stopped. This page will close or blank itself.</p>
  </div>
</div>
<div class="wrap">
  <details class="card sectioncollapse" id="renderersettingsdetails" open>
    <summary><span>Renderer settings</span><span class="summaryvalue">Preamp, latency, keep-alive, LFE</span></summary>
    <div class="sectionbody">
    <div class="row r3">
      <div><label>Renderer executable</label><input id="exe"></div>
      <div><label>Layout preset</label><input id="preset_display" value="9.1.6 bed (1:1)" readonly aria-readonly="true"></div>
      <div><label>Frames/buffer</label><input id="frames"></div>
    </div>
    <div class="small" style="margin-top:10px">Layout is fixed to 9.1.6 with at least 16 input channels.</div>
    <div class="row r5" style="margin-top:12px">
      <div><label>Preamp dB</label><input id="preamp" type="number" step="0.1"></div>
      <div><label>Input safety latency ms</label><input id="input_latency_ms" type="number" min="0" step="1" placeholder="10"></div>
      <div><label>Output safety latency ms</label><input id="output_latency_ms" type="number" min="0" step="1" placeholder="10"></div>
      <div>
        <label>Output keep-alive</label>
        <label class="togglecard" for="keep_output_alive">
          <span class="toggletext">
            <span>Keep output awake</span>
            <span class="togglehint">Silent stream to selected output</span>
          </span>
          <input id="keep_output_alive" type="checkbox" checked>
          <span class="switch" aria-hidden="true"></span>
        </label>
      </div>
      <div>
        <label>LFE filter</label>
        <label class="togglecard" for="lfe_lowpass">
          <span class="toggletext">
            <span id="lfe_mode_label">Butterworth 125 Hz low-pass</span>
            <span class="togglehint" id="lfe_mode_hint">24 dB/oct, fixed 172-sample dry delay</span>
          </span>
          <input id="lfe_lowpass" type="checkbox" checked>
          <span class="switch" aria-hidden="true"></span>
        </label>
      </div>
    </div>
    <div class="small" style="margin-top:10px">Default preamp is -9.5 dB. Input safety latency affects capture. Output safety latency affects playback and the silent keep-alive stream. Keep output awake holds the selected DAC open with digital silence to avoid idle/restart pops. 0 uses the device low-latency default.</div>
    </div>
  </details>

  <details class="card sectioncollapse" id="routingpeqdetails" open>
    <summary><span>Output routing and channel PEQ</span><span class="summaryvalue">L/R swap, profiles, User PEQ, Speaker EQ</span></summary>
    <div class="sectionbody">
    <div class="profilebar">
      <div>
        <label for="routing_peq_profile_select">Saved profile</label>
        <select id="routing_peq_profile_select"></select>
      </div>
      <div>
        <label for="routing_peq_profile_name">Profile name</label>
        <input id="routing_peq_profile_name" placeholder="e.g. EO500 swapped">
      </div>
      <button id="save_routing_peq_profile" type="button">Save</button>
      <button id="load_routing_peq_profile" class="secondary" type="button">Load</button>
      <button id="delete_routing_peq_profile" class="secondary" type="button">Delete</button>
      <div class="profilehint">Profiles save only this section: L/R swap, User/global PEQ text, and stereo Speaker EQ text. Uploaded file contents are saved, not the file path.</div>
    </div>
    <div class="row r2">
      <div>
        <label>Left/right channel swap</label>
        <label class="togglecard" for="swap_outputs">
          <span class="toggletext">
            <span>Swap physical L/R outputs</span>
            <span class="togglehint">Stereo correction channel assignment is flipped when swap is enabled</span>
          </span>
          <input id="swap_outputs" type="checkbox">
          <span class="switch" aria-hidden="true"></span>
        </label>
      </div>
      <div>
        <label>Speaker EQ channel mapping</label>
        <div class="small" style="margin-top:8px">Load the stereo Speaker EQ file in the Speaker EQ section below. With L/R swap off, CH:0→left and CH:1→right. With L/R swap on, CH:1→left and CH:0→right so the correction follows the swapped outputs.</div>
      </div>
    </div>
    <div class="peqgrid">
      <div class="peqbox">
        <label>User/global PEQ</label>
        <div class="fileline"><input id="global_peq_file" type="file" accept=".txt,.peace,.apo,.eq,.cfg,.peq,text/plain"><button id="clear_global_peq" class="secondary" type="button">Clear</button></div>
        <textarea id="global_output_peq_text" spellcheck="false" placeholder="Paste User/global PEQ or Equalizer APO PEQ text here. Applied equally to both stereo outputs before L/R swap."></textarea>
      </div>
      <div class="peqbox">
        <label>Stereo Speaker EQ, L/R correction</label>
        <div class="fileline"><input id="speaker_peq_file" type="file" accept=".txt,.peace,.apo,.eq,.cfg,.peq,text/plain"><button id="clear_speaker_peq" class="secondary" type="button">Clear</button></div>
        <textarea id="speaker_output_peq_text" spellcheck="false" placeholder="Load or paste one stereo Speaker EQ file here. Supports CH:0/CH:1 and Channel:L/R sections. Swap off: CH:0 left, CH:1 right. Swap on: CH:1 left, CH:0 right."></textarea>
      </div>
    </div>
    <div class="small" style="margin-top:10px">DSP order: matrix + master preamp → User/global PEQ → L/R swap → Speaker EQ. For stereo correction files, enabling L/R swap flips the imported correction channels so CH:1 feeds the left output and CH:0 feeds the right output. OFF filters and Xfeed lines are ignored. PK/PEQ, LS/LSC, and HS/HSC filters are supported.</div>
    </div>
  </details>

  <div class="card">
    <div class="collapsegrid">
      <details class="collapse" id="indevdetails" open>
        <summary><span>Input device</span><span id="indevsummary" class="summaryvalue">No input selected</span></summary>
        <div class="collapsebody">
          <div class="listwrap" id="indevwrap">
            <div id="indevlist" class="devicelist" role="listbox" tabindex="0" aria-label="Input device"></div>
            <div class="scrollhint" aria-hidden="true"><div class="scrollhintthumb" id="indevthumb"></div></div>
          </div>
          <input id="indev" type="hidden">
          <div id="indevhint" class="small devicehint">Requires an input device with at least 16 channels.</div>
          <button id="refresh_input_devices" class="secondary" type="button" style="margin-top:10px">Refresh devices</button>
          <details id="indevincompat" class="incompatpanel" hidden>
            <summary id="indevincompatsummary">Show incompatible devices</summary>
            <div id="indevincompatlist" class="incompatlist"></div>
          </details>
        </div>
      </details>
      <details class="collapse" id="outdevdetails" open>
        <summary><span>Output device</span><span id="outdevsummary" class="summaryvalue">No output selected</span></summary>
        <div class="collapsebody">
          <div class="listwrap" id="outdevwrap">
            <div id="outdevlist" class="devicelist" role="listbox" tabindex="0" aria-label="Output device"></div>
            <div class="scrollhint" aria-hidden="true"><div class="scrollhintthumb" id="outdevthumb"></div></div>
          </div>
          <input id="outdev" type="hidden">
        </div>
      </details>
    </div>
  </div>

  <div class="card">
    <div class="toolbar">
      <button id="start" disabled>Start</button>
      <button id="stop" class="stop" disabled>Stop</button>
    </div>
    <div class="statusline" style="margin-top:14px">
      <div id="runstate" class="pill stopped"><span class="dot"></span><span id="runtext">Stopped</span></div>
      <div id="statusmsg" class="hint">Stereo renderer is idle.</div>
    </div>
  </div>

  <details class="card sectioncollapse" id="visualizerdetails" open>
    <summary><span>Bed input visualizer and stereo meters</span><span class="summaryvalue">9.1.6 activity, stereo sum output</span></summary>
    <div class="sectionbody">    <div class="row visualmeterrow">
      <div>
        <label>Active bed inputs, overhead 9.1.6 layout</label>
        <div id="badges" class="badges" aria-label="Top-down 9.1.6 active bed input layout with side stereo sum meters"></div>
      </div>
    </div>
    </div>
  </details>

  <details class="card sectioncollapse" id="logdetails" open>
    <summary><span>Renderer log</span><span class="summaryvalue">Read-only diagnostics</span></summary>
    <div class="sectionbody">
    <label>Renderer log (read-only)</label>
    <pre id="log"></pre>
    </div>
  </details>
</div>
<script>
const BED_LABELS = %BED_LABELS%;
const LAYOUT_PRESETS = %LAYOUT_PRESETS%;
const CLIENT_ID = %CLIENT_ID%;
const EMBEDDED_MODE = %EMBEDDED_MODE%;
let disconnected = false;
let disconnectFailures = 0;
let heartbeatTimer = null;
let pollTimer = null;
let embeddedFallbackPollTimer = null;
let eventSource = null;
let eventRetryTimer = null;
let autoApplyTimer = null;
let pendingAutoApply = false;
let saveTimer = null;
let currentPhase = 'stopped';
let rendererRecoveryPending = false;
let appInitializing = true;
let missingDeviceStopInFlight = false;
let missingDeviceStopReason = '';
const CONTROLLED_STOP_MIN_VISIBLE_MS = 0;
let controlledStopHoldTimer = null;
let controlledStopHoldKey = '';
let lastAppliedControlledStopUnavailableKey = '';
let deviceSelectionRevision = 0;
let deviceRefreshRequestId = 0;
let startupInputRescanTimer = null;
let startupInputRescanAttempts = 0;
let startupInputRescanArmed = true;
const STARTUP_INPUT_RESCAN_DELAYS_MS = [500, 1200, 2500, 5000, 8000, 12000, 18000, 25000];
const START_READY_STABLE_MS = 0;
const START_READINESS_MAX_AGE_MS = 60000;
let startReadiness = { ready:true, reason:'', lastRefreshAt:Date.now(), inputEnumerated:false };
let startReadinessTimer = null;
let applyBusy = false;
let applyTransitionActive = false;
let applyTransitionIgnoreAllStatuses = false;
let applyTransitionMinRevision = null;
let logTimer = null;
let lastStatusRevision = -1;
let lastLogRevision = -1;
let meterAnimHandle = null;
let meterAnimLastTs = 0;
let lastInputDeviceSignature = '';
let lastOutputDeviceSignature = '';
let listInteractionUntil = { indev: 0, outdev: 0 };
  let missingSelectionClearedByUser = { indev: false, outdev: false };
let pendingNativeStatus = null;
let pendingNativeStatusFrame = 0;
let visualsWereSuspended = false;
window.__nativeBridgeReady = false;
const METER_FLOOR_DB = -160;
const SUM_METER_TICK_STEP_DB = 10;
const SUM_METER_LABEL_STEP_DB = 20;
const VISUAL_IDLE_SUPPRESS_DB = METER_FLOOR_DB;
const OUTPUT_READOUT_FLOOR_DB = METER_FLOOR_DB;
const METER_PEAK_HOLD_MS = 8;
const METER_RELEASE_DB_PER_SEC = 45;
// Sum meters now follow the renderer's actual stereo output meters.
// They are no longer suppressed or forced idle based on bed-input silence.
const INPUT_PEAK_HOLD_MS = METER_PEAK_HOLD_MS;
const INPUT_RELEASE_DB_PER_SEC = METER_RELEASE_DB_PER_SEC;
const INPUT_RENDER_BUCKET_DB = 0.5;
const READOUT_HYSTERESIS_DB = 0.35;
const READOUT_FAST_DELTA_DB = 0.9;
const READOUT_MIN_INTERVAL_MS = 45;
const INPUT_SILENCE_GRACE_MS = 0;
const INPUT_OFF_HOLD_MS = 95;
// Bed inputs and stereo sum meters share one silence gate so neither visual
// path can disappear earlier than the other when audio stops. The gate also
// bridges one status interval where only the input side or only the output side
// reports residual activity, so the two visual groups cannot clear separately.
const VISUAL_OFF_HOLD_MS = INPUT_OFF_HOLD_MS;
const READOUT_SILENCE_GRACE_MS = 0;
let sharedVisualSilenceSince = 0;
let sharedVisualsCleared = true;
let sharedVisualInputGroupActive = false;
let sharedVisualOutputGroupActive = false;
let holdInputBadgesWithOutput = false;
let holdSumMetersWithInputs = false;
// Bed badges are colored only by their own raw input-channel dBFS.
// Sum meters separately show the actual folded-down stereo output level.
const ACTIVE_BADGE_FALLBACK_DB = -18;
const activeBadgeState = {};
const speakerElementsByLabel = {};
const soundWaveElementsByLabel = {};
function roomPoint(label, x, y, className=''){
  return {label, x, y, className};
}
const SPEAKER_LAYOUT_916 = [
  // Clean concentric layout: the main bed channels read as a more even ring
  // around the listener, with height speakers on a balanced inner ring.
  roomPoint('C', 50, 16),
  roomPoint('L', 34, 20), roomPoint('R', 66, 20),
  roomPoint('Lw', 19, 35), roomPoint('Rw', 81, 35),
  roomPoint('Ls', 16, 50), roomPoint('Rs', 84, 50),
  roomPoint('Lrs', 28, 76), roomPoint('Rrs', 72, 76),

  // Ceiling layer, arranged as a balanced inner ring around the listener.
  roomPoint('Ltf', 40, 33, 'top'), roomPoint('Rtf', 60, 33, 'top'),
  roomPoint('Ltm', 31, 50, 'top'), roomPoint('Rtm', 69, 50, 'top'),
  roomPoint('Ltr', 40, 67, 'top'), roomPoint('Rtr', 60, 67, 'top'),

  // Non-localized LFE marker near the front center.
  roomPoint('LFE', 50, 31, 'lfe')
];
const METER_COLOR_STOPS = [
  {p:0, c:[74,124,255]},
  {p:38, c:[103,213,255]},
  {p:60, c:[111,226,108]},
  {p:72, c:[199,239,102]},
  {p:80, c:[255,209,102]},
  {p:88, c:[255,159,90]},
  {p:94, c:[255,107,99]},
  {p:100, c:[255,93,115]}
];
// The 200 ms clip latch is handled in the Python launcher state so short
// clipping events cannot be lost before the browser paints. Keep the JS latch
// at zero to avoid doubling the visible hold time.
const CLIP_LATCH_MS = 0;
const meterState = {
  L: {target: 0, current: 0, rawDb: -Infinity, latestRawDb: -Infinity, shownDb: -Infinity, displayDb: -Infinity, holdUntil: 0, lastReadoutAt: 0, silenceSince: 0, lastColorBucket: null, clipOn: false, clipUntil: 0},
  R: {target: 0, current: 0, rawDb: -Infinity, latestRawDb: -Infinity, shownDb: -Infinity, displayDb: -Infinity, holdUntil: 0, lastReadoutAt: 0, silenceSince: 0, lastColorBucket: null, clipOn: false, clipUntil: 0}
};

const $ = s => document.querySelector(s);

function installMacMinimizeShortcut(){
  document.addEventListener('keydown', (ev)=>{
    const key = String(ev.key || '').toLowerCase();
    if(!ev.metaKey || ev.shiftKey || ev.altKey || key !== 'm') return;
    ev.preventDefault();
    ev.stopPropagation();
    fetch('/api/minimize', {method:'POST', headers:{'Content-Type':'application/json'}, body:'{}'}).catch(()=>{});
  }, true);
}

function interpolateColor(percent){
  const p = Math.max(0, Math.min(100, percent));
  for(let i=1; i<METER_COLOR_STOPS.length; i++){
    const a = METER_COLOR_STOPS[i - 1];
    const b = METER_COLOR_STOPS[i];
    if(p <= b.p){
      const span = Math.max(0.0001, b.p - a.p);
      const t = (p - a.p) / span;
      return a.c.map((v, idx)=>Math.round(v + (b.c[idx] - v) * t));
    }
  }
  return METER_COLOR_STOPS[METER_COLOR_STOPS.length - 1].c.slice();
}
function colorForDb(db){
  if(!Number.isFinite(db) || db <= METER_FLOOR_DB) return null;
  return interpolateColor(meterWidthFromDb(db));
}
function maxDbText(a, b){
  const da = parseMeterDb(a);
  const db = parseMeterDb(b);
  if(!Number.isFinite(da)) return Number.isFinite(db) ? String(b) : '-inf';
  if(!Number.isFinite(db)) return String(a);
  return db > da ? String(b) : String(a);
}
function mergeLevelPeakMaps(a, b){
  const out = Object.assign({}, a || {});
  const next = b || {};
  Object.keys(next).forEach(k=>{
    out[k] = maxDbText(out[k], next[k]);
  });
  return out;
}
function mergeStatusPeakPayload(previous, next){
  if(!previous) return next || {};
  if(!next) return previous || {};
  const prevPhase = previous.phase || 'stopped';
  const nextPhase = next.phase || 'stopped';
  // For non-running transitions, latest state must win immediately so Stop,
  // errors, and disconnects are never hidden behind peak coalescing.
  if(prevPhase !== 'running' || nextPhase !== 'running') return next;

  const out = Object.assign({}, next);
  out.meter_left_db = maxDbText(previous.meter_left_db, next.meter_left_db);
  out.meter_right_db = maxDbText(previous.meter_right_db, next.meter_right_db);
  out.input_levels_db = mergeLevelPeakMaps(previous.input_levels_db, next.input_levels_db);
  out.input_transients_db = mergeLevelPeakMaps(previous.input_transients_db, next.input_transients_db);
  out.clip_left = !!previous.clip_left || !!next.clip_left;
  out.clip_right = !!previous.clip_right || !!next.clip_right;
  const labels = new Set([...(previous.active_labels || []), ...(next.active_labels || [])]);
  out.active_labels = Array.from(labels);
  return out;
}
function levelColorBucketDb(db){
  if(!Number.isFinite(db)) return -Infinity;
  return Math.round(db / INPUT_RENDER_BUCKET_DB) * INPUT_RENDER_BUCKET_DB;
}
function levelColorStyle(color){
  if(!color) return null;
  const [r,g,b] = color;
  const rgb = `${r},${g},${b}`;
  return {
    rgb,
    backgroundColor: `rgba(${rgb},0.44)`,
    // Flat fill by design: gradients scale differently on the circular bed badges
    // and the tall sum meters, which made a digital color meter read them as
    // different colors even when the base RGB was the same.
    backgroundImage: 'none',
    borderColor: `rgba(${rgb},0.88)`,
    softBorderColor: `rgba(${rgb},0.88)`,
    boxShadow: `0 0 0 1px rgba(${rgb},0.12) inset, 0 0 24px rgba(${rgb},0.26)`
  };
}


function clamp01(v){
  return Math.max(0, Math.min(1, v));
}
function sourceLevelStrength(db){
  if(!Number.isFinite(db) || db <= METER_FLOOR_DB) return 0;
  return clamp01((db - METER_FLOOR_DB) / (0 - METER_FLOOR_DB));
}
function resetSoundWaveStyle(_el){}
function applySoundWaveLevelStyle(_label, _db){}
function createSoundWaveOverlay(_stage){}
function setWaveTransientMap(_map){}
function resetWaveField(){}
function clearWaveCanvas(){}
function animateWaveEquation(_ts, _dt){}
function outputColorForDb(db){
  // Sum meters and bed badges intentionally share the same color lookup.
  // The rendered surfaces below also use the same RGBA + overlay styling, not
  // merely the same underlying RGB value.
  return colorForDb(db);
}
function finiteDbOrNegInf(v){
  return Number.isFinite(v) ? v : -Infinity;
}
function resetBadgeStyle(el){
  if(el.dataset.levelBucket === 'idle') return;
  el.dataset.levelBucket = 'idle';
  el.style.background = '';
  el.style.backgroundColor = '';
  el.style.backgroundImage = '';
  el.style.borderColor = '';
  el.style.boxShadow = '';
  el.style.color = '';
  el.style.textShadow = '';
}
function applyBadgeLevelStyle(el, db){
  const color = colorForDb(db);
  if(!color){
    resetBadgeStyle(el);
    return;
  }
  // Use the exact same 0.5 dB color bucket and rendered RGBA surface style
  // as the stereo sum meters, so equal displayed dBFS values are visually identical.
  const bucketValue = levelColorBucketDb(db);
  const bucket = bucketValue.toFixed(1);
  if(el.dataset.levelBucket === bucket) return;
  el.dataset.levelBucket = bucket;
  const style = levelColorStyle(colorForDb(bucketValue) || color);
  if(!style){
    resetBadgeStyle(el);
    return;
  }
  el.style.background = '';
  el.style.backgroundColor = style.backgroundColor;
  el.style.backgroundImage = style.backgroundImage;
  el.style.borderColor = style.borderColor;
  el.style.boxShadow = style.boxShadow;
  el.style.color = '#ffffff';
  el.style.textShadow = '0 1px 2px rgba(0,0,0,.55)';
}
function resetInputLevelState(){
  BED_LABELS.forEach(l=>{
    const st = activeBadgeState[l];
    if(st){
      st.rawDb = -Infinity;
      st.shownDb = -Infinity;
      st.holdUntil = 0;
      st.silenceSince = 0;
      st.lastFiniteDb = -Infinity;
      st.lastActiveAt = 0;
      st.lastRenderedBucket = null;
      st.lastRenderedLinkedKey = null;
      st.linkedSumSide = '';
    }
    applySoundWaveLevelStyle(l, -Infinity);
  });
}
function createSumMeter(side){
  const meter = document.createElement('div');
  meter.className = 'summeter ' + (side === 'L' ? 'left' : 'right');
  const header = document.createElement('div');
  header.className = 'sumheader';
  const title = document.createElement('div');
  title.className = 'sumtitle';
  title.textContent = side === 'L' ? 'L sum' : 'R sum';
  const clip = document.createElement('div');
  clip.className = 'meterclip';
  clip.id = 'clip' + side;
  clip.setAttribute('aria-label', side + ' sum clip indicator');
  clip.title = 'Clip indicator';
  header.appendChild(title);
  header.appendChild(clip);
  const track = document.createElement('div');
  track.className = 'metertrack';
  track.id = 'meter' + side + 'track';
  const fill = document.createElement('div');
  fill.className = 'meterfill';
  fill.id = 'meter' + side + 'fill';
  const peak = document.createElement('div');
  peak.className = 'meterpeak';
  peak.id = 'meter' + side + 'peak';
  track.appendChild(fill);
  track.appendChild(peak);
  const scale = document.createElement('div');
  scale.className = 'meterscale';
  scale.innerHTML = Array.from({length: Math.floor((0 - METER_FLOOR_DB) / SUM_METER_TICK_STEP_DB) + 1}, (_, i)=>{
    const db = -i * SUM_METER_TICK_STEP_DB;
    const pos = ((0 - db) / (0 - METER_FLOOR_DB)) * 100;
    const isLabel = (db === 0 || db === METER_FLOOR_DB || Math.abs(db) % SUM_METER_LABEL_STEP_DB === 0);
    const label = isLabel ? (db === 0 ? '0' : String(db).replace('-', '−')) : '';
    const classes = ['scaletick', isLabel ? 'major' : 'minor'];
    if(db === 0) classes.push('top');
    if(db === METER_FLOOR_DB) classes.push('bottom');
    return `<span class="${classes.join(' ')}" style="top:${pos.toFixed(4)}%">${label}</span>`;
  }).join('');
  const body = document.createElement('div');
  body.className = 'meterbody';
  body.appendChild(track);
  body.appendChild(scale);
  meter.appendChild(header);
  meter.appendChild(body);
  return meter;
}
function badges(){
  const g = $('#badges');
  if(!g) return;
  g.innerHTML = '';
  BED_LABELS.forEach(l=>{ speakerElementsByLabel[l] = []; });
  g.appendChild(createSumMeter('L'));
  g.appendChild(createSumMeter('R'));
  const stage = document.createElement('div');
  stage.className = 'layoutstage';
  g.appendChild(stage);
  // The reference-style spacing is kept, but the extra frame/rail/ceiling guide
  // lines are intentionally omitted so the bed visualizer reads as clean floating
  // channel badges rather than a boxed diagram.
  BED_LABELS.forEach(l=>{
    activeBadgeState[l] = {rawDb: -Infinity, shownDb: -Infinity, holdUntil: 0, silenceSince: 0, lastFiniteDb: -Infinity, lastActiveAt: 0, lastRenderedBucket: null, lastRenderedLinkedKey: null, linkedSumSide: ''};
  });
  const listener = document.createElement('div');
  listener.className = 'listenerdot';
  listener.title = 'Listener';
  listener.innerHTML = '<div class="listenerheadtop" aria-hidden="true"><div class="ear left"></div><div class="ear right"></div><div class="skull"></div><div class="nose"></div></div>';
  stage.appendChild(listener);
  SPEAKER_LAYOUT_916.forEach((sp, idx)=>{
    const d = document.createElement('div');
    d.className = 'badge' + (sp.className ? ' ' + sp.className : '');
    d.id = sp.label === 'LFE' ? ('b_LFE_' + idx) : ('b_' + sp.label);
    d.dataset.bed = sp.label;
    d.textContent = sp.display || sp.label;
    d.title = sp.label === 'LFE' ? 'LFE channel, shown separately because it is not a localized bed speaker' : sp.label;
    d.style.left = sp.x + '%';
    d.style.top = sp.y + '%';
    stage.appendChild(d);
    speakerElementsByLabel[sp.label] = speakerElementsByLabel[sp.label] || [];
    speakerElementsByLabel[sp.label].push(d);
  });
}
function setActiveInputs(labels, running=true){
  if(!running){
    setInputLevels({}, false);
    return;
  }
  const fallback = {};
  BED_LABELS.forEach(l=>{ fallback[l] = '-inf'; });
  (labels || []).forEach(l=>{ fallback[l] = String(ACTIVE_BADGE_FALLBACK_DB); });
  setInputLevels(fallback, true);
}
function inputLevelsHaveVisibleSignal(levelMap){
  if(!levelMap) return false;
  return BED_LABELS.some(l=>{
    const value = Object.prototype.hasOwnProperty.call(levelMap, l) ? levelMap[l] : '-inf';
    const db = parseMeterDb(value);
    return Number.isFinite(db) && db > VISUAL_IDLE_SUPPRESS_DB;
  });
}
function activeLabelsHaveVisibleSignal(labels){
  return Array.isArray(labels) && labels.some(l=>BED_LABELS.includes(l));
}
function outputMetersHaveVisibleSignal(j){
  if(!j) return false;
  const l = parseMeterDb(j.meter_left_db || '-inf');
  const r = parseMeterDb(j.meter_right_db || '-inf');
  return (Number.isFinite(l) && l > VISUAL_IDLE_SUPPRESS_DB) ||
         (Number.isFinite(r) && r > VISUAL_IDLE_SUPPRESS_DB);
}
function statusVisualSignalFlags(j){
  if(!j) return {inputActive:false, outputActive:false, anyActive:false};
  const inputLevels = j.input_levels_db || null;
  const inputActive = inputLevels
    ? inputLevelsHaveVisibleSignal(inputLevels)
    : activeLabelsHaveVisibleSignal(j.active_labels || []);
  const outputActive = outputMetersHaveVisibleSignal(j);
  return {
    inputActive,
    outputActive,
    anyActive: inputActive || outputActive
  };
}
function statusHasVisibleSignal(j){
  return statusVisualSignalFlags(j).anyActive;
}
function updateSharedVisualGate(flags){
  const now = Date.now();
  const state = (typeof flags === 'object' && flags)
    ? flags
    : {inputActive:!!flags, outputActive:!!flags, anyActive:!!flags};
  sharedVisualInputGroupActive = !!state.inputActive;
  sharedVisualOutputGroupActive = !!state.outputActive;
  // If only one visual group still reports activity, keep the other group
  // enrolled in the shared clear gate. Do not freeze its dB value here; the
  // animation loop must keep releasing it so transients never get stuck.
  holdInputBadgesWithOutput = sharedVisualOutputGroupActive && !sharedVisualInputGroupActive;
  holdSumMetersWithInputs = sharedVisualInputGroupActive && !sharedVisualOutputGroupActive;
  if(state.anyActive){
    sharedVisualSilenceSince = 0;
    sharedVisualsCleared = false;
    return true;
  }
  holdInputBadgesWithOutput = false;
  holdSumMetersWithInputs = false;
  if(!sharedVisualSilenceSince){
    sharedVisualSilenceSince = now;
  }
  return (now - sharedVisualSilenceSince) < VISUAL_OFF_HOLD_MS;
}
function sharedVisualHoldOn(now=Date.now()){
  return !sharedVisualSilenceSince || (now - sharedVisualSilenceSince) < VISUAL_OFF_HOLD_MS;
}
function clearSharedVisuals(now=Date.now()){
  if(sharedVisualsCleared) return;
  holdInputBadgesWithOutput = false;
  holdSumMetersWithInputs = false;
  sharedVisualInputGroupActive = false;
  sharedVisualOutputGroupActive = false;
  resetInputLevelState();
  renderActiveBadges(now, 0);
  ['L','R'].forEach(side=>{
    resetMeter(side);
    renderMeter(side, 0);
  });
  sharedVisualsCleared = true;
}
function setInputLevels(levelMap, running=true){
  const now = Date.now();
  if(!running){
    resetInputLevelState();
    renderActiveBadges(now, 0);
    return;
  }
  const parsedByLabel = {};
  BED_LABELS.forEach(l=>{
    const value = (levelMap && Object.prototype.hasOwnProperty.call(levelMap, l)) ? levelMap[l] : '-inf';
    const parsedInputDb = parseMeterDb(value);
    parsedByLabel[l] = Number.isFinite(parsedInputDb) ? parsedInputDb : -Infinity;
  });
  let anyActiveInput = false;
  BED_LABELS.forEach(l=>{
    const st = activeBadgeState[l];
    if(!st) return;
    const parsedInputDb = parsedByLabel[l];
    // Bed badges must always represent raw input-channel levels.
    // They intentionally do not borrow the rendered stereo-sum level or color,
    // even for direct L-only/R-only/stereo playback.
    const displayDb = parsedInputDb;
    const activeNow = Number.isFinite(parsedInputDb) && parsedInputDb > VISUAL_IDLE_SUPPRESS_DB;
    st.inputDb = finiteDbOrNegInf(parsedInputDb);
    st.linkedSumSide = '';
    st.rawDb = activeNow ? displayDb : -Infinity;
    if(activeNow){
      anyActiveInput = true;
      st.silenceSince = 0;
      st.lastActiveAt = now;
      // Do not overwrite a held transient with the next lower raw packet.
      // The bed badge must still be sourced from the raw input channel, but
      // it should use the same peak-hold/release envelope as the sum meters.
      if(!Number.isFinite(st.shownDb) || displayDb > st.shownDb){
        st.shownDb = displayDb;
        st.holdUntil = now + INPUT_PEAK_HOLD_MS;
        st.lastFiniteDb = displayDb;
      }
    }else if(Number.isFinite(st.shownDb) || Number.isFinite(st.lastFiniteDb)){
      // Preserve the current rendered value as the release start point only.
      // The animation loop will continue decaying it while the shared visual
      // gate decides when both the bed badges and sum meters clear together.
      if(!Number.isFinite(st.shownDb)) st.shownDb = st.lastFiniteDb;
      st.rawDb = -Infinity;
      if(!st.silenceSince) st.silenceSince = now;
    }else{
      st.shownDb = -Infinity;
      st.lastFiniteDb = -Infinity;
      st.lastActiveAt = 0;
      st.holdUntil = 0;
      st.silenceSince = 0;
    }
  });
  renderActiveBadges(now, 0);
}
function renderActiveBadges(now=Date.now(), dt=0.016){
  BED_LABELS.forEach(l=>{
    const st = activeBadgeState[l] || {rawDb:-Infinity, shownDb:-Infinity, holdUntil:0, linkedSumSide:''};
    if(Number.isFinite(st.rawDb) && (!Number.isFinite(st.shownDb) || st.rawDb > st.shownDb)){
      st.shownDb = st.rawDb;
      st.holdUntil = now + INPUT_PEAK_HOLD_MS;
      st.lastFiniteDb = st.shownDb;
      st.lastActiveAt = now;
    }else if(Number.isFinite(st.shownDb) && now >= (st.holdUntil || 0)){
      const releaseTarget = Number.isFinite(st.rawDb) ? Math.max(st.rawDb, METER_FLOOR_DB) : METER_FLOOR_DB;
      st.shownDb = Math.max(releaseTarget, st.shownDb - INPUT_RELEASE_DB_PER_SEC * Math.max(0, dt || 0));
      st.lastFiniteDb = st.shownDb;
      if(st.shownDb <= METER_FLOOR_DB + 0.05 && !Number.isFinite(st.rawDb) && !sharedVisualHoldOn(now) && !holdInputBadgesWithOutput){
        st.shownDb = -Infinity;
        st.lastFiniteDb = -Infinity;
        st.lastActiveAt = 0;
      }
    }
    const renderDb = st.shownDb;
    const on = Number.isFinite(renderDb) && renderDb > METER_FLOOR_DB;
    const bucket = on ? String(Math.round(renderDb / INPUT_RENDER_BUCKET_DB) * INPUT_RENDER_BUCKET_DB) : 'idle';
    if(st.lastRenderedBucket === bucket) return;
    st.lastRenderedBucket = bucket;
    applySoundWaveLevelStyle(l, on ? renderDb : -Infinity);
    const nodes = speakerElementsByLabel[l] || [];
    nodes.forEach(el=>{
      const base = 'badge' + (el.classList.contains('lfe') ? ' lfe' : '') + (el.classList.contains('top') ? ' top' : '');
      const nextClass = base + (on ? ' on' : '');
      if(el.className !== nextClass) el.className = nextClass;
      applyBadgeLevelStyle(el, renderDb);
      const levelText = on ? `${formatMeterDb(renderDb)} dBFS input` : '-inf dBFS';
      const title = el.dataset.bed === 'LFE'
        ? `LFE channel, shown separately because it is not a localized bed speaker
${levelText}`
        : `${el.dataset.bed}
${levelText}`;
      if(el.title !== title) el.title = title;
    });
  });
}
function updateLfeToggleCopy(){
  const lowpass = $('#lfe_lowpass');
  const label = $('#lfe_mode_label');
  const hint = $('#lfe_mode_hint');
  if(!lowpass || !label || !hint) return;
  if(lowpass.checked){
    label.textContent = 'Butterworth 125 Hz low-pass';
    hint.textContent = '24 dB/oct, fixed 172-sample dry delay';
  }else{
    label.textContent = 'Dry ADC2 direct LFE';
    hint.textContent = 'no low-pass';
  }
}
function fillPresets(){
  const p = $('#preset_display');
  if(p) p.value = '9.1.6 bed (1:1)';
}
function applyPreset(save=true){
  if(save) scheduleSavePrefs();
}
function parseMeterDb(dbText){
  if(dbText === undefined || dbText === null) return -Infinity;
  const text = String(dbText).trim().toLowerCase();
  if(text === '' || text === '-inf' || text === '-infinity') return -Infinity;
  const db = Number(text);
  return Number.isFinite(db) ? db : -Infinity;
}
function formatMeterDb(db){
  if(!Number.isFinite(db) || db <= METER_FLOOR_DB) return '-inf';
  return db.toFixed(1);
}
function formatOutputMeterDb(db){
  if(!Number.isFinite(db)) return '-inf';
  // Treat values below the display floor as silence. This avoids showing
  // "< -120" when the renderer is running but nothing is actually playing.
  if(db < OUTPUT_READOUT_FLOOR_DB) return '-inf';
  return db.toFixed(1);
}
function meterWidthFromDb(db){
  if(!Number.isFinite(db)) return 0;
  if(db >= 0) return 100;
  if(db <= METER_FLOOR_DB) return 0;
  // Linear dB mapping: the configured floor is the bottom and 0 dBFS is the top.
  return ((db - METER_FLOOR_DB) / (0 - METER_FLOOR_DB)) * 100;
}
function meterWidth(dbText){
  return meterWidthFromDb(parseMeterDb(dbText));
}
function updateMeterReadout(side, force=false){
  const clip = $('#clip' + side);
  const m = meterState[side];
  const now = Date.now();
  const on = !!(m && (m.clipOn || now < m.clipUntil));
  if(clip){
    const nextClass = 'meterclip' + (on ? ' on' : '');
    if(force || clip.className !== nextClass) clip.className = nextClass;
  }
}


function renderMeter(side, percent){
  const fill = $('#meter' + side + 'fill');
  const track = $('#meter' + side + 'track');
  const peak = $('#meter' + side + 'peak');
  const m = meterState[side];
  if(!fill || !track || !peak || !m) return;
  const shown = Math.max(0, Math.min(100, percent));
  fill.style.transform = `scaleY(${(shown / 100).toFixed(4)})`;
  fill.style.opacity = shown <= 0.1 ? '0' : '1';
  // Use the exact same color bucket and rendered RGBA surface style as the
  // bed input badges. This avoids the previous mismatch where the sum fill was
  // solid RGB but the badges were translucent RGBA with an overlay.
  const colorBucket = Number.isFinite(m.shownDb) ? levelColorBucketDb(m.shownDb) : -Infinity;
  const color = outputColorForDb(colorBucket);
  const style = levelColorStyle(color);
  const rgb = style ? style.rgb : 'idle';
  if(track.dataset.rgb !== rgb){
    track.dataset.rgb = rgb;
    if(style){
      // Use the same rendered surface treatment as the bed badges so the sum
      // meters look perceptually identical, not just numerically mapped to the
      // same RGB values.
      fill.style.backgroundColor = style.backgroundColor;
      fill.style.backgroundImage = style.backgroundImage;
      fill.style.backgroundBlendMode = 'normal';
      fill.style.boxShadow = style.boxShadow;
      track.style.borderColor = style.softBorderColor;
      track.style.boxShadow = `inset 0 0 0 1px rgba(255,255,255,.025), inset 0 0 18px rgba(0,0,0,.55), 0 0 20px rgba(${style.rgb},0.14)`;
    }else{
      fill.style.backgroundColor = 'transparent';
      fill.style.backgroundImage = '';
      fill.style.boxShadow = 'none';
      track.style.borderColor = '#323640';
      track.style.boxShadow = 'inset 0 0 0 1px rgba(255,255,255,.025), inset 0 0 18px rgba(0,0,0,.55)';
    }
  }
  updateMeterReadout(side);
}
function animateMeters(ts){
  if(document.hidden){
    meterAnimLastTs = 0;
    meterAnimHandle = requestAnimationFrame(animateMeters);
    return;
  }
  if(!meterAnimLastTs) meterAnimLastTs = ts;
  const dt = Math.min(0.05, Math.max(0.001, (ts - meterAnimLastTs) / 1000));
  meterAnimLastTs = ts;
  const now = Date.now();
  if(sharedVisualSilenceSince && !sharedVisualHoldOn(now)){
    clearSharedVisuals(now);
    meterAnimHandle = requestAnimationFrame(animateMeters);
    return;
  }
  renderActiveBadges(now, dt);
  animateWaveEquation(ts, dt);
  for(const side of ['L', 'R']){
    const m = meterState[side];
    const rawDb = m.rawDb;
    if(Number.isFinite(rawDb) && (!Number.isFinite(m.shownDb) || rawDb > m.shownDb)){
      m.shownDb = rawDb;
      m.holdUntil = now + METER_PEAK_HOLD_MS;
    }else if(now >= m.holdUntil){
      const releaseTarget = Number.isFinite(rawDb) ? Math.max(rawDb, METER_FLOOR_DB) : METER_FLOOR_DB;
      if(Number.isFinite(m.shownDb)){
        m.shownDb = Math.max(releaseTarget, m.shownDb - METER_RELEASE_DB_PER_SEC * dt);
        if(m.shownDb <= METER_FLOOR_DB + 0.05 && (!Number.isFinite(rawDb) || rawDb <= METER_FLOOR_DB)){
          m.shownDb = -Infinity;
        }
      }else if(Number.isFinite(rawDb)){
        m.shownDb = rawDb;
      }
    }
    m.target = meterWidthFromDb(m.shownDb);
    m.current = m.target;
    renderMeter(side, m.current);
  }
  meterAnimHandle = requestAnimationFrame(animateMeters);
}
function scheduleNextPoll(){
  if(disconnected) return;
  pollTimer = setTimeout(poll, 0);
}
function setMeter(side, dbText, clipped){
  const m = meterState[side];
  const now = Date.now();
  const parsedRawDb = parseMeterDb(dbText);
  const parsedDb = (Number.isFinite(parsedRawDb) && parsedRawDb > VISUAL_IDLE_SUPPRESS_DB) ? parsedRawDb : -Infinity;
  m.latestRawDb = parsedDb;
  let rawDb = parsedDb;
  if(Number.isFinite(parsedDb)){
    m.silenceSince = 0;
  }else{
    if(!m.silenceSince) m.silenceSince = now;
    // Keep rawDb at -Infinity during silent/shared-hold periods. The previous
    // implementation copied shownDb back into rawDb, which made the release
    // target equal the current value and caused transient fades to freeze.
    rawDb = -Infinity;
  }
  m.rawDb = rawDb;
  if(Number.isFinite(rawDb) && (!Number.isFinite(m.shownDb) || rawDb > m.shownDb)){
    m.shownDb = rawDb;
    m.holdUntil = now + METER_PEAK_HOLD_MS;
    m.target = meterWidthFromDb(m.shownDb);
    m.current = m.target;
  }
  if(document.hidden){
    // requestAnimationFrame can be paused while the renderer tab is hidden.
    // Still paint active status packets into the DOM so returning to the tab
    // shows the current meter state immediately instead of an empty meter that
    // fills only after the first foreground frame/status refresh.
    m.shownDb = (Number.isFinite(rawDb) && rawDb > METER_FLOOR_DB) ? rawDb : -Infinity;
    m.holdUntil = Number.isFinite(m.shownDb) ? now + METER_PEAK_HOLD_MS : 0;
    m.target = meterWidthFromDb(m.shownDb);
    m.current = m.target;
    renderMeter(side, m.current);
  }
  m.clipOn = !!clipped;
  if(clipped) m.clipUntil = now + CLIP_LATCH_MS;
  updateMeterReadout(side);
}
function resetMeter(side){
  const m = meterState[side];
  m.rawDb = -Infinity;
  m.latestRawDb = -Infinity;
  m.shownDb = -Infinity;
  m.displayDb = -Infinity;
  m.holdUntil = 0;
  m.target = 0;
  m.current = 0;
  m.lastReadoutAt = 0;
  m.silenceSince = 0;
  m.lastColorBucket = null;
  m.clipOn = false;
  m.clipUntil = 0;
  renderMeter(side, 0);
  updateMeterReadout(side, true);
  const clip = $('#clip' + side);
  if(clip){
    clip.className = 'meterclip';
  }
}
function snapVisualsToLatestRawState(){
  const now = Date.now();
  BED_LABELS.forEach(l=>{
    const st = activeBadgeState[l];
    if(!st) return;
    st.shownDb = Number.isFinite(st.rawDb) ? st.rawDb : -Infinity;
    st.holdUntil = 0;
    st.silenceSince = 0;
    st.lastFiniteDb = Number.isFinite(st.rawDb) ? st.rawDb : -Infinity;
    st.lastActiveAt = Number.isFinite(st.rawDb) ? now : 0;
    st.linkedSumSide = '';
    st.lastRenderedBucket = null;
    st.lastRenderedLinkedKey = null;
  });
  renderActiveBadges(now, 0);
  for(const side of ['L', 'R']){
    const m = meterState[side];
    if(!m) continue;
    const rawDb = m.rawDb;
    m.latestRawDb = rawDb;
    m.shownDb = (Number.isFinite(rawDb) && rawDb > METER_FLOOR_DB) ? rawDb : -Infinity;
    m.holdUntil = 0;
    m.silenceSince = 0;
    m.target = meterWidthFromDb(m.shownDb);
    m.current = m.target;
    renderMeter(side, m.current);
  }
  meterAnimLastTs = 0;
}
async function refreshStatusAndSnapVisuals(){
  try{
    const r = await fetch('/api/status', {cache:'no-store'});
    if(r.ok) applyStatusPayload(await r.json());
  }catch(e){}
  snapVisualsToLatestRawState();
}
function forceIdleVisualState(){
  sharedVisualSilenceSince = 0;
  sharedVisualsCleared = true;
  sharedVisualInputGroupActive = false;
  sharedVisualOutputGroupActive = false;
  holdInputBadgesWithOutput = false;
  holdSumMetersWithInputs = false;
  setWaveTransientMap({});
  setActiveInputs([], false);
  resetWaveField();
  resetMeter('L');
  resetMeter('R');
}
function isUnavailableDeviceMessage(msg){
  const text = String(msg || '').trim();
  return text === 'Selected output device is unavailable.' ||
         text === 'Selected input device is unavailable or does not expose at least 16 input channels.' ||
         text === 'Select both an input device and an output device.';
}
function normalizeRunPhase(phase, msg){
  const requested = String(phase || 'stopped').trim() || 'stopped';
  if(requested === 'error' && isUnavailableDeviceMessage(msg)) return 'stopped';
  return requested;
}
function setRunState(phase, msg){
  phase = normalizeRunPhase(phase, msg);
  currentPhase = phase || 'stopped';
  if(currentPhase === 'running' || currentPhase === 'error' || currentPhase === 'disconnected' || currentPhase === 'stopped'){
    applyTransitionActive = false;
    applyTransitionIgnoreAllStatuses = false;
    applyTransitionMinRevision = null;
  }
  if(currentPhase !== 'running'){
    forceIdleVisualState();
  }
  const pill = $('#runstate');
  const text = $('#runtext');
  pill.className = 'pill ' + currentPhase;
  const labels = {
    stopped: 'Stopped',
    starting: 'Starting…',
    running: 'Running',
    stopping: 'Stopping…',
    error: 'Error',
    disconnected: 'Disconnected'
  };
  text.textContent = labels[currentPhase] || currentPhase;
  $('#statusmsg').textContent = msg || '';
  // Keep the transport buttons derived from the single currentPhase state.
  // Previously some direct setRunState('stopped', ...) paths updated the pill
  // without recomputing disabled states, so Stop could remain visually enabled
  // after a hot-unplug stop.
  updateStartButtonState();
}
async function waitForPhases(phases, timeoutMs=4000, applyPayload=true){
  const wanted = new Set(phases);
  const start = Date.now();
  while(Date.now() - start < timeoutMs){
    try{
      const r = await fetch('/api/status', {cache:'no-store'});
      if(!r.ok) throw new Error('status fetch failed');
      const j = await r.json();
      if(wanted.has(j.phase)){
        if(applyPayload) applyStatusPayload(j);
        return j;
      }
    }catch(e){}
    await new Promise(resolve => setTimeout(resolve, 80));
  }
  throw new Error('Timed out waiting for renderer state change.');
}
async function applyPresetAndRestart(){
  if(applyBusy){
    pendingAutoApply = true;
    return;
  }
  applyBusy = true;
  try{
    applyPreset(false);
    const validationError = getSelectionValidationError();
    if(validationError){
      markUnavailableFromStatusText(validationError);
      setRunState('stopped', validationError);
      updateStartButtonState();
      return;
    }
    const payload = currentPayload();
    const shouldRestart = currentPhase === 'running' || currentPhase === 'starting' || currentPhase === 'stopping';
    applyTransitionActive = shouldRestart;
    applyTransitionIgnoreAllStatuses = shouldRestart;
    applyTransitionMinRevision = lastStatusRevision;
    setRunState('starting', shouldRestart ? 'Restarting renderer with updated settings…' : 'Starting renderer with applied settings…');
    $('#start').disabled = true;
    $('#stop').disabled = true;
    const r = await fetch('/api/apply', {
      method:'POST',
      headers:{'Content-Type':'application/json'},
      body: JSON.stringify(payload)
    });
    const j = await r.json();
    if(!j.ok){
      applyTransitionActive = false;
      applyTransitionIgnoreAllStatuses = false;
      const message = j.error || 'Could not apply renderer changes.';
      try{
        const statusResp = await fetch('/api/status', {cache:'no-store'});
        if(statusResp.ok){
          const latestStatus = await statusResp.json();
          if(latestStatus && latestStatus.status_text && ['error','stopped'].includes(latestStatus.phase || '')){
            applyStatusPayload(latestStatus);
          }else{
            setRunState(j.phase || 'error', message);
          }
        }else{
          setRunState('error', message);
        }
      }catch(_e){
        setRunState('error', message);
      }
      return;
    }
    await refreshLog();
    try{
      const statusResp = await fetch('/api/status', {cache:'no-store'});
      if(statusResp.ok){
        const finalStatus = await statusResp.json();
        applyTransitionActive = false;
        applyTransitionIgnoreAllStatuses = false;
        applyStatusPayload(finalStatus);
      }else{
        applyTransitionActive = false;
        applyTransitionIgnoreAllStatuses = false;
      }
    }catch(_e){
      applyTransitionActive = false;
      applyTransitionIgnoreAllStatuses = false;
    }
  }catch(e){
    applyTransitionActive = false;
    applyTransitionIgnoreAllStatuses = false;
    const message = e && e.message ? e.message : 'Could not apply preset.';
    setRunState(isUnavailableDeviceMessage(message) ? 'stopped' : 'error', message);
  }finally{
    applyBusy = false;
    if(pendingAutoApply){
      pendingAutoApply = false;
      setTimeout(()=>{ applyPresetAndRestart(); }, 0);
    }
  }
}
function shouldAutoApply(){
  return currentPhase === 'running' || currentPhase === 'starting';
}
function queueAutoApply(delayMs=60){
  if(!shouldAutoApply()) return;
  clearTimeout(autoApplyTimer);
  autoApplyTimer = setTimeout(()=>{
    autoApplyTimer = null;
    if(!shouldAutoApply()) return;
    applyPresetAndRestart();
  }, Math.max(0, delayMs|0));
}
function bindApplyOnCommit(inputEl, options={}){
  if(!inputEl) return;
  const normalizeBeforeCommit = typeof options.normalizeBeforeCommit === 'function' ? options.normalizeBeforeCommit : null;
  const onCommit = typeof options.onCommit === 'function' ? options.onCommit : null;
  const committedValueFor = ()=> inputEl.type === 'checkbox' ? String(!!inputEl.checked) : String(inputEl.value ?? '');
  const syncCommittedValue = ()=>{
    inputEl.__lastCommittedValue = committedValueFor();
  };
  const maybeApply = ()=>{
    if(normalizeBeforeCommit) normalizeBeforeCommit(inputEl);
    const currentValue = committedValueFor();
    const lastCommittedValue = String(inputEl.__lastCommittedValue ?? '');
    if(currentValue === lastCommittedValue) return;
    inputEl.__lastCommittedValue = currentValue;
    if(onCommit) onCommit(inputEl);
    queueAutoApply(0);
  };
  inputEl.__syncCommittedValue = syncCommittedValue;
  syncCommittedValue();
  inputEl.addEventListener('keydown', (ev)=>{
    if(ev.key !== 'Enter') return;
    if(String(inputEl.tagName || '').toLowerCase() === 'textarea') return;
    ev.preventDefault();
    maybeApply();
  });
  inputEl.addEventListener('blur', ()=>{
    maybeApply();
  });
  inputEl.addEventListener('change', ()=>{
    maybeApply();
  });
}
function syncApplyCommitValues(){
  [$('#frames'), $('#input_latency_ms'), $('#output_latency_ms'), $('#preamp'), $('#lfe_lowpass'), $('#swap_outputs'), $('#global_output_peq_text'), $('#speaker_output_peq_text')].forEach((inputEl)=>{
    if(inputEl && typeof inputEl.__syncCommittedValue === 'function'){
      inputEl.__syncCommittedValue();
    }
  });
}
function inputValueIsApplyable(inputEl){
  if(!inputEl) return false;
  const tag = String(inputEl.tagName || '').toLowerCase();
  if(tag === 'textarea') return true;
  if(inputEl.type === 'number'){
    const text = String(inputEl.value ?? '').trim();
    if(text === '') return false;
    if(inputEl.validity && !inputEl.validity.valid) return false;
    return Number.isFinite(Number(text));
  }
  return true;
}
function bindApplyWhileEditing(inputEl, delayMs=250){
  if(!inputEl) return;
  let timer = null;
  inputEl.addEventListener('input', ()=>{
    if(!shouldAutoApply()) return;
    clearTimeout(timer);
    timer = setTimeout(()=>{
      timer = null;
      if(!shouldAutoApply()) return;
      if(!inputValueIsApplyable(inputEl)) return;

      // Keep the commit tracker in sync so the later blur/change event does
      // not launch a duplicate restart for the same value. This also fixes a
      // race where an EQ textarea blur can start an apply, then a preamp edit
      // made during that restart is only saved to preferences and never queued
      // for the live renderer until the user manually stops and starts again.
      if(typeof inputEl.__syncCommittedValue === 'function'){
        inputEl.__syncCommittedValue();
      }
      queueAutoApply(0);
    }, Math.max(0, delayMs|0));
  });
}
function normalizeRoutingPeqProfiles(value){
  const clean = {};
  if(!value || typeof value !== 'object' || Array.isArray(value)) return clean;
  Object.keys(value).sort((a,b)=>a.localeCompare(b)).forEach((name)=>{
    const key = String(name || '').trim();
    const item = value[name];
    if(!key || !item || typeof item !== 'object' || Array.isArray(item)) return;
    clean[key] = {
      swap_outputs: item.swap_outputs === true || String(item.swap_outputs).toLowerCase() === 'true',
      global_output_peq_text: String(item.global_output_peq_text || ''),
      speaker_output_peq_text: String(item.speaker_output_peq_text || '')
    };
  });
  return clean;
}
function routingPeqSnapshot(){
  return {
    swap_outputs: !!$('#swap_outputs').checked,
    global_output_peq_text: $('#global_output_peq_text').value,
    speaker_output_peq_text: $('#speaker_output_peq_text').value
  };
}
function applyRoutingPeqSnapshot(profile){
  if(!profile || typeof profile !== 'object') return false;
  $('#swap_outputs').checked = profile.swap_outputs === true || String(profile.swap_outputs).toLowerCase() === 'true';
  $('#global_output_peq_text').value = String(profile.global_output_peq_text || '');
  $('#speaker_output_peq_text').value = String(profile.speaker_output_peq_text || '');
  syncApplyCommitValues();
  return true;
}
function selectedRoutingPeqProfileName(){
  const selected = ($('#routing_peq_profile_select') && $('#routing_peq_profile_select').value || '').trim();
  const typed = ($('#routing_peq_profile_name') && $('#routing_peq_profile_name').value || '').trim();
  return typed || selected;
}
function renderRoutingPeqProfiles(){
  const select = $('#routing_peq_profile_select');
  const nameInput = $('#routing_peq_profile_name');
  if(!select) return;
  const names = Object.keys(routingPeqProfiles).sort((a,b)=>a.localeCompare(b));
  select.innerHTML = '';
  const empty = document.createElement('option');
  empty.value = '';
  empty.textContent = names.length ? 'Choose a profile...' : 'No saved profiles';
  select.appendChild(empty);
  names.forEach((name)=>{
    const opt = document.createElement('option');
    opt.value = name;
    opt.textContent = name;
    select.appendChild(opt);
  });
  if(activeRoutingPeqProfile && routingPeqProfiles[activeRoutingPeqProfile]){
    select.value = activeRoutingPeqProfile;
  }else{
    activeRoutingPeqProfile = '';
    select.value = '';
  }
  if(nameInput && document.activeElement !== nameInput){
    nameInput.value = activeRoutingPeqProfile || '';
  }
  const hasSelection = !!select.value;
  const loadBtn = $('#load_routing_peq_profile');
  const delBtn = $('#delete_routing_peq_profile');
  if(loadBtn) loadBtn.disabled = !hasSelection;
  if(delBtn) delBtn.disabled = !hasSelection;
}
function saveRoutingPeqProfile(){
  const name = selectedRoutingPeqProfileName();
  if(!name){
    window.alert('Enter a profile name first.');
    return;
  }
  routingPeqProfiles[name] = routingPeqSnapshot();
  activeRoutingPeqProfile = name;
  renderRoutingPeqProfiles();
  savePrefsNow();
}
function loadRoutingPeqProfile(){
  const select = $('#routing_peq_profile_select');
  const name = select ? String(select.value || '').trim() : '';
  if(!name || !routingPeqProfiles[name]) return;
  activeRoutingPeqProfile = name;
  applyRoutingPeqSnapshot(routingPeqProfiles[name]);
  renderRoutingPeqProfiles();
  savePrefsNow();
  queueAutoApply(0);
}
function deleteRoutingPeqProfile(){
  const select = $('#routing_peq_profile_select');
  const name = select ? String(select.value || '').trim() : '';
  if(!name || !routingPeqProfiles[name]) return;
  if(!window.confirm(`Delete profile "${name}"?`)) return;
  delete routingPeqProfiles[name];
  if(activeRoutingPeqProfile === name) activeRoutingPeqProfile = '';
  renderRoutingPeqProfiles();
  savePrefsNow();
}
function markListInteracting(kind, holdMs=900){
  listInteractionUntil[kind] = Date.now() + Math.max(0, holdMs|0);
}
function isListInteracting(kind){
  return Date.now() < (listInteractionUntil[kind] || 0);
}

function preampPayloadValue(){
  const text = String($('#preamp').value ?? '').trim();
  return text === '' ? '0' : text;
}
function normalizePreampEmptyToZero(inputEl=$('#preamp')){
  if(!inputEl) return false;
  const text = String(inputEl.value ?? '').trim();
  if(text !== '') return false;
  inputEl.value = '0';
  return true;
}
function currentPayload(){
  return {
    exe: $('#exe').value.trim(),
    preset: '9.1.6 bed (1:1)',
    frames: $('#frames').value.trim(),
    input_latency_ms: $('#input_latency_ms').value.trim(),
    output_latency_ms: $('#output_latency_ms').value.trim(),
    keep_output_alive: !!$('#keep_output_alive').checked,
    input_channels: '16',
    threshold: '-160',
    preamp_db: preampPayloadValue(),
    lfe_lowpass: !!$('#lfe_lowpass').checked,
    swap_outputs: !!$('#swap_outputs').checked,
    global_output_peq_text: $('#global_output_peq_text').value,
    speaker_output_peq_text: $('#speaker_output_peq_text').value,
    routing_peq_profiles: routingPeqProfiles,
    active_routing_peq_profile: activeRoutingPeqProfile,
    input_device: $('#indev').value,
    output_device: $('#outdev').value,
    input_device_name: $('#indev').dataset.name || '',
    output_device_name: $('#outdev').dataset.name || '',
    input_collapsed: !document.getElementById('indevdetails').open,
    output_collapsed: !document.getElementById('outdevdetails').open,
    settings_collapsed: !document.getElementById('renderersettingsdetails').open,
    routing_peq_collapsed: !document.getElementById('routingpeqdetails').open,
    visualizer_collapsed: !document.getElementById('visualizerdetails').open,
    log_collapsed: !document.getElementById('logdetails').open,
    map: (LAYOUT_PRESETS['9.1.6 bed (1:1)'] || []).map(v => String(v)),
  };
}
function getSelectionValidationError(){
  const inputEl = $('#indev');
  const outputEl = $('#outdev');
  const inputName = (inputEl.dataset.name || '').trim();
  const outputName = (outputEl.dataset.name || '').trim();
  const inputValue = String(inputEl.value || '').trim();
  const outputValue = String(outputEl.value || '').trim();
  if(!inputValue && !inputName) return 'Select an input device.';
  if(!outputValue && !outputName) return 'Select an output device.';
  if(inputEl.dataset.missing === '1' || (inputName && !inputValue)){
    return 'Selected input device is unavailable or does not expose at least 16 input channels.';
  }
  if(outputEl.dataset.missing === '1' || (outputName && !outputValue)){
    return 'Selected output device is unavailable.';
  }
  return '';
}

function selectedDevicesSignature(){
  const inputEl = $('#indev');
  const outputEl = $('#outdev');
  return JSON.stringify({
    input: String(inputEl.value || ''),
    inputName: String(inputEl.dataset.name || ''),
    output: String(outputEl.value || ''),
    outputName: String(outputEl.dataset.name || '')
  });
}
function updateStartButtonState(){
  const startBtn = $('#start');
  const stopBtn = $('#stop');
  if(!startBtn || !stopBtn) return;
  startBtn.textContent = 'Start';
  const busyPhase = rendererRecoveryPending || currentPhase === 'running' || currentPhase === 'starting' || currentPhase === 'stopping' || currentPhase === 'disconnected';
  if(appInitializing || busyPhase){
    startBtn.disabled = true;
  }else{
    // Start should be available whenever the currently selected devices are
    // present in the UI. Do not gate Start behind an artificial post-hotplug
    // settling timer or a stale "readiness" packet. The backend still resolves
    // the selected devices immediately before launch and reports a real error if
    // the output disappears between the click and process start.
    const validationError = getSelectionValidationError();
    startBtn.disabled = !!validationError;
  }
  // Start stays locked during Core Audio recovery, but Stop must remain
  // available so a failed hotplug restart can be cancelled by the user.
  stopBtn.disabled = currentPhase === 'stopped' || currentPhase === 'error' || currentPhase === 'disconnected';
}
function setStartReadinessFromDevicePayload(j){
  // Keep this object only as informational state from the backend. It must not
  // disable Start. The visible device selections are the source of truth for
  // whether the user can try to start the renderer.
  const reason = String((j && j.start_not_ready_reason) || '').trim();
  const backendReady = !!(j && j.start_ready === true);
  const inputEnumerated = !!(j && j.input_enumerated === true);
  startReadiness = {
    ready: backendReady,
    reason: reason,
    lastRefreshAt: Date.now(),
    inputEnumerated
  };
  if(startReadinessTimer){
    clearTimeout(startReadinessTimer);
    startReadinessTimer = null;
  }
  if(currentPhase === 'stopped' || currentPhase === 'error'){
    const msgEl = $('#statusmsg');
    const current = String(msgEl.textContent || '');
    if(current.includes('still settling') || current.includes('current full input/output device scan') || current.includes('Start will be enabled')){
      msgEl.textContent = 'Stereo renderer is idle.';
    }
  }
  updateStartButtonState();
}
function startNotReadyMessage(){
  const validationError = getSelectionValidationError();
  if(validationError) return validationError;
  return startReadiness.reason || 'Selected audio devices are unavailable.';
}

async function savePrefsNow(){
  try{
    await fetch('/api/preferences', {
      method:'POST',
      headers:{'Content-Type':'application/json'},
      body: JSON.stringify(currentPayload()),
      keepalive: true
    });
  }catch(e){}
}
function scheduleSavePrefs(){
  clearTimeout(saveTimer);
  saveTimer = setTimeout(savePrefsNow, 120);
}
function updateInputHint(items){
  const hint = $('#indevhint');
  const panel = $('#indevincompat');
  const summary = $('#indevincompatsummary');
  const list = $('#indevincompatlist');
  if(!hint) return;
  const allItems = items || [];
  const compatible = allItems.filter(it => (it.compatible !== false) && Number(it.inputs || 0) >= 16);
  const incompatible = allItems.filter(it => Number(it.inputs || 0) > 0 && !(it.compatible !== false && Number(it.inputs || 0) >= 16));
  if(panel && list && summary){
    list.innerHTML = '';
    if(incompatible.length){
      incompatible.forEach(it => {
        const row = document.createElement('div');
        row.className = 'incompatitem';
        row.textContent = `${it.name} — ${Number(it.inputs || 0)} in`;
        list.appendChild(row);
      });
      summary.textContent = `Show incompatible devices (${incompatible.length})`;
      panel.hidden = false;
    }else{
      panel.hidden = true;
      panel.open = false;
    }
  }
  if(!allItems.length){
    hint.textContent = 'No input devices found.';
    hint.className = 'small devicehint warn';
    return;
  }
  if(compatible.length){
    hint.textContent = incompatible.length
      ? `Requires a 16-channel input device. ${incompatible.length} incompatible device${incompatible.length === 1 ? '' : 's'} hidden.`
      : 'Requires an input device with at least 16 channels.';
    hint.className = 'small devicehint';
    return;
  }
  hint.textContent = 'No compatible 16-channel input device found.';
  hint.className = 'small devicehint warn';
}
function updateDeviceSummary(hiddenInput){
  const isInput = hiddenInput.id === 'indev';
  const summaryId = isInput ? '#indevsummary' : '#outdevsummary';
  const listId = isInput ? '#indevlist' : '#outdevlist';
  const el = $(summaryId);
  const listEl = $(listId);
  if(!el || !listEl) return;
  const selected = listEl.querySelector('.devicerow.selected');
  let text = selected ? (selected.dataset.label || selected.textContent || '') : (isInput ? 'No input selected' : 'No output selected');
  if(hiddenInput.dataset.missing === '1' && (hiddenInput.dataset.name || '')){
    text = hiddenInput.dataset.name + ' (unavailable)';
  } else if((hiddenInput.dataset.name || '') && !hiddenInput.value){
    text = hiddenInput.dataset.name + ' (unavailable)';
  } else if(isInput && !selected && listEl.children.length){
    text = 'No compatible input device';
  }
  el.textContent = text;
  el.title = text;
}

function parseRemovedDeviceStatus(text){
  const raw = String(text || '').trim();
  const lower = raw.toLowerCase();
  let kind = '';
  if(lower.startsWith('renderer stopped because the selected output device was removed')) kind = 'outdev';
  else if(lower.startsWith('renderer stopped because the selected input device was removed')) kind = 'indev';
  else return null;
  let name = '';
  const colon = raw.indexOf(':');
  if(colon >= 0){
    name = raw.slice(colon + 1).trim().replace(/[.。]+$/g, '').trim();
  }
  return {kind, name};
}
function normalizeDeviceNameForMatch(name){
  return String(name || '')
    .replace(/\s*\(unavailable\)\s*$/i, '')
    .replace(/[.。]+$/g, '')
    .replace(/\s+/g, ' ')
    .trim()
    .toLowerCase();
}
function stripDeviceSampleRateSuffix(name){
  return normalizeDeviceNameForMatch(name)
    .replace(/\s+\d+(?:\.\d+)?\s*k(?:ilo)?hz$/i, '')
    .replace(/\s+\d+(?:\.\d+)?\s*hz$/i, '')
    .trim();
}
function deviceNamesMatch(a, b){
  const aa = normalizeDeviceNameForMatch(a);
  const bb = normalizeDeviceNameForMatch(b);
  if(!aa || !bb) return false;
  if(aa === bb) return true;
  const as = stripDeviceSampleRateSuffix(aa);
  const bs = stripDeviceSampleRateSuffix(bb);
  return !!(as && bs && as.length >= 6 && as === bs);
}
function findDeviceBySavedSelection(items, selectedValue='', selectedName='', isInput=false){
  const selectable = (items || []).filter(it => isInput ? ((it.compatible !== false) && Number(it.inputs || 0) >= 16) : isSelectableOutputDevice(it));
  const value = String(selectedValue || '').trim();
  const name = String(selectedName || '').trim();
  if(name){
    if(value){
      const exactBoth = selectable.find(it => it.name === name && String(it.index) === value);
      if(exactBoth) return {item: exactBoth, matchedByName: true, matchedByValue: true};
    }
    const exactName = selectable.find(it => it.name === name);
    if(exactName) return {item: exactName, matchedByName: true, matchedByValue: String(exactName.index) === value};
    const normalizedName = selectable.find(it => deviceNamesMatch(it.name, name));
    if(normalizedName) return {item: normalizedName, matchedByName: true, matchedByValue: String(normalizedName.index) === value};

    // Core Audio/PortAudio device indexes are not stable after hotplug. If the
    // saved name is gone, an index-only match may be a different physical output
    // that shifted into the old slot. Treat that as missing so the renderer stops
    // instead of silently switching to another DAC/interface.
    return {item: null, matchedByName: false, matchedByValue: false};
  }
  if(value){
    const exactValue = selectable.find(it => String(it.index) === value);
    if(exactValue) return {item: exactValue, matchedByName: false, matchedByValue: true};
  }
  return {item: null, matchedByName: false, matchedByValue: false};
}
function selectedDeviceIsAvailableInUi(kind, displayName=''){
  const hidden = $('#' + kind);
  const listEl = $('#' + kind + 'list');
  if(!hidden || !listEl) return false;
  if(hidden.dataset.missing === '1') return false;
  const selected = listEl.querySelector('.devicerow.selected');
  if(!selected || isMissingDeviceRow(selected)) return false;
  const hiddenValue = String(hidden.value || '').trim();
  if(!hiddenValue) return false;
  const selectedValue = String(selected.dataset.value || '').trim();
  if(selectedValue && selectedValue !== hiddenValue) return false;
  const selectedName = selected.dataset.label || selected.textContent || hidden.dataset.name || '';
  const wantedName = String(displayName || hidden.dataset.name || '').trim();
  return !wantedName || deviceNamesMatch(selectedName, wantedName);
}
function controlledStopUnavailableKey(revision, text){
  const rev = (typeof revision === 'number') ? String(revision) : '';
  return rev + '|' + String(text || '').trim();
}
function controlledStopAppliesToCurrentSelection(removed){
  if(!removed || !removed.kind) return false;
  const hidden = $('#' + removed.kind);
  if(!hidden) return false;
  const currentName = String(hidden.dataset.name || '').replace(/\s*\(unavailable\)\s*$/i, '').trim();
  const currentValue = String(hidden.value || '').trim();
  const removedName = String(removed.name || '').replace(/\s*\(unavailable\)\s*$/i, '').trim();

  // A device-removal status is only relevant while that same removed device is
  // still the current selection. If the user has already clicked another real
  // output while the renderer is stopped, old backend status packets should not
  // re-select the missing device and flicker the message back to the removal
  // text.
  if(!currentName && !currentValue) return false;
  if(removedName && currentName) return deviceNamesMatch(currentName, removedName);
  if(removedName) return hidden.dataset.missing === '1';
  return hidden.dataset.missing === '1';
}
function normalizeMissingSelectionRows(kind, labelBase=''){
  const hidden = $('#' + kind);
  const listEl = $('#' + kind + 'list');
  if(!hidden || !listEl) return null;
  const fallbackName = kind === 'indev' ? 'Selected input device' : 'Selected output device';
  const rawBase = String(labelBase || hidden.dataset.name || hidden.value || fallbackName).trim();
  const cleanBase = rawBase.replace(/\s*\(unavailable\)\s*$/i, '').trim() || fallbackName;
  const label = cleanBase + ' (unavailable)';
  let keeper = null;
  Array.from(listEl.querySelectorAll('.devicerow')).forEach(row=>{
    const rowLabel = String(row.dataset.label || row.textContent || '').trim();
    const rowValue = String(row.dataset.value || '').trim();
    const isMissing = row.dataset.missingSelection === '1' || rowValue.startsWith('__missing__:') || /\(unavailable\)\s*$/i.test(rowLabel);
    if(!isMissing) return;
    if(!keeper){
      keeper = row;
    }else{
      row.remove();
    }
  });
  if(keeper){
    keeper.type = 'button';
    keeper.className = 'devicerow selected';
    keeper.dataset.missingSelection = '1';
    keeper.dataset.value = '__missing__:' + cleanBase;
    keeper.dataset.label = label;
    keeper.textContent = label;
    keeper.disabled = false;
    keeper.setAttribute('role', 'option');
    keeper.setAttribute('aria-selected', 'true');
    keeper.setAttribute('aria-disabled', 'true');
    if(listEl.firstChild !== keeper){
      listEl.insertBefore(keeper, listEl.firstChild);
    }
  }
  return keeper;
}

function clearMissingDeviceSelection(kind, save=true){
  const hidden = $('#' + kind);
  const listEl = $('#' + kind + 'list');
  if(!hidden || !listEl) return false;
  const hadMissing = hidden.dataset.missing === '1' || (!hidden.value && !!(hidden.dataset.name || '').trim());
  if(!hadMissing) return false;
  missingSelectionClearedByUser[kind] = true;
  listEl.querySelectorAll('.devicerow').forEach(row=>{
    const rowLabel = String(row.dataset.label || row.textContent || '').trim();
    const rowValue = String(row.dataset.value || '').trim();
    const isMissingRow = row.dataset.missingSelection === '1' || rowValue.startsWith('__missing__:') || /\(unavailable\)\s*$/i.test(rowLabel);
    if(isMissingRow) row.remove();
    else {
      row.classList.remove('selected');
      row.setAttribute('aria-selected', 'false');
    }
  });
  hidden.value = '';
  hidden.dataset.name = '';
  hidden.dataset.missing = '0';
  if(kind === 'indev') lastInputDeviceSignature = '';
  else lastOutputDeviceSignature = '';
  deviceSelectionRevision += 1;
  updateDeviceSummary(hidden);
  updateStartButtonState();
  if(save && !appInitializing){
    if(currentPhase === 'error' || currentPhase === 'stopped'){
      savePrefsNow();
    }else{
      scheduleSavePrefs();
    }
  }
  return true;
}
function markSelectedDeviceUnavailable(kind, displayName=''){
  const hidden = $('#' + kind);
  const listEl = $('#' + kind + 'list');
  if(!hidden || !listEl) return;
  missingSelectionClearedByUser[kind] = false;
  const fallbackName = kind === 'indev' ? 'Selected input device' : 'Selected output device';
  const existingName = String(hidden.dataset.name || '').trim();
  const existingValue = String(hidden.value || '').trim();
  const name = String(displayName || existingName || '').trim();
  const labelBase = name || existingName || existingValue || fallbackName;
  const label = labelBase.replace(/\s*\(unavailable\)\s*$/i, '').trim() + ' (unavailable)';
  hidden.value = '';
  hidden.dataset.name = name || existingName || labelBase;
  hidden.dataset.name = String(hidden.dataset.name || '').replace(/\s*\(unavailable\)\s*$/i, '').trim();
  hidden.dataset.missing = '1';
  listEl.querySelectorAll('.devicerow').forEach(row=>{
    row.classList.remove('selected');
    row.setAttribute('aria-selected', 'false');
  });
  let row = normalizeMissingSelectionRows(kind, labelBase);
  if(!row){
    row = document.createElement('button');
    row.type = 'button';
    row.className = 'devicerow selected';
    row.dataset.missingSelection = '1';
    row.disabled = false;
    row.setAttribute('role', 'option');
    row.setAttribute('aria-disabled', 'true');
    listEl.insertBefore(row, listEl.firstChild);
  }
  row.classList.add('selected');
  row.dataset.missingSelection = '1';
  row.dataset.value = '__missing__:' + labelBase.replace(/\s*\(unavailable\)\s*$/i, '').trim();
  row.dataset.label = label;
  row.textContent = label;
  row.disabled = false;
  row.setAttribute('aria-selected', 'true');
  row.setAttribute('aria-disabled', 'true');
  normalizeMissingSelectionRows(kind, labelBase);
  updateDeviceSummary(hidden);
  updateStartButtonState();
}
function selectedOutputRemovedStopText(fallbackName=''){
  const outputEl = $('#outdev');
  const rawName = String(fallbackName || (outputEl && outputEl.dataset.name) || '').trim();
  const cleanName = rawName.replace(/\s*\(unavailable\)\s*$/i, '').trim();
  const displayName = cleanName || 'the selected output device';
  return `Renderer stopped because the selected output device was removed: ${displayName}.`;
}
function selectedInputRemovedStopText(fallbackName=''){
  const inputEl = $('#indev');
  const rawName = String(fallbackName || (inputEl && inputEl.dataset.name) || '').trim();
  const cleanName = rawName.replace(/\s*\(unavailable\)\s*$/i, '').trim();
  const displayName = cleanName || 'the selected input device';
  return `Renderer stopped because the selected input device was removed: ${displayName}.`;
}
function normalizeUnavailableStopMessage(msg){
  const text = String(msg || '').trim();
  if(text === 'Selected output device is unavailable.') return selectedOutputRemovedStopText();
  if(text === 'Selected input device is unavailable or does not expose at least 16 input channels.' ||
     text === 'Selected input device is unavailable or changed before startup.' ||
     text === 'Selected input device is unavailable or not ready.') return selectedInputRemovedStopText();
  return text;
}
function markUnavailableFromStatusText(text){
  const msg = String(text || '').trim();
  if(msg === 'Selected output device is unavailable.'){
    markSelectedDeviceUnavailable('outdev');
    return true;
  }
  if(msg === 'Selected input device is unavailable or does not expose at least 16 input channels.' ||
     msg === 'Selected input device is unavailable or changed before startup.' ||
     msg === 'Selected input device is unavailable or not ready.'){
    markSelectedDeviceUnavailable('indev');
    return true;
  }
  return false;
}


function isMissingDeviceRow(row){
  if(!row) return false;
  const rowLabel = String(row.dataset.label || row.textContent || '').trim();
  const rowValue = String(row.dataset.value || '').trim();
  return row.dataset.missingSelection === '1' || rowValue.startsWith('__missing__:') || /\(unavailable\)\s*$/i.test(rowLabel);
}

function installMissingDeviceOutsideClear(kind){
  const hidden = $('#' + kind);
  const listEl = $('#' + kind + 'list');
  if(!hidden || !listEl) return;
  const maybeClear = (target)=>{
    if(appInitializing) return;
    if(hidden.dataset.missing !== '1') return;

    // The previous version returned for any click inside the device list.
    // That was the bug: clicking the empty list area, scrollbar gutter, or even
    // the unavailable placeholder itself counted as "inside the list", so the
    // row stayed visible until the next background refresh rebuilt the list.
    // Clear the placeholder immediately unless the user is actively pressing a
    // real, available device row, in which case selectDevice() will run next.
    const row = target && target.closest ? target.closest('.devicerow') : null;
    const clickedRealRow = row && listEl.contains(row) && !isMissingDeviceRow(row);
    clearMissingDeviceSelection(kind, !clickedRealRow);
  };
  document.addEventListener('pointerdown', (ev)=>maybeClear(ev.target), true);
  document.addEventListener('focusin', (ev)=>maybeClear(ev.target), true);
}

function installTransientScrollbar(scrollEl){
  const wrap = document.getElementById(scrollEl.id.replace('list', 'wrap'));
  const thumb = document.getElementById(scrollEl.id.replace('list', 'thumb'));
  const trackEl = wrap ? wrap.querySelector('.scrollhint') : null;
  if(!wrap || !thumb || !trackEl) return;
  let timer = null;
  const update = ()=>{
    const total = scrollEl.scrollHeight || 0;
    const visible = scrollEl.clientHeight || 0;
    if(total <= visible + 2){
      wrap.classList.add('no-scroll');
      thumb.style.transform = 'translateY(0px)';
      thumb.style.height = '0px';
      return;
    }
    wrap.classList.remove('no-scroll');
    const track = Math.max(0, trackEl.clientHeight - 2);
    const thumbHeight = Math.max(28, Math.round((visible / total) * track));
    const maxTop = Math.max(0, track - thumbHeight);
    const scrollTop = scrollEl.scrollTop || 0;
    const maxScroll = Math.max(1, total - visible);
    const top = Math.round((scrollTop / maxScroll) * maxTop);
    thumb.style.height = thumbHeight + 'px';
    thumb.style.transform = `translateY(${top}px)`;
  };
  const show = ()=>{
    update();
    wrap.classList.add('show-scrollbar');
    clearTimeout(timer);
    timer = setTimeout(()=>wrap.classList.remove('show-scrollbar'), 1500);
  };
  ['scroll','wheel','touchmove','keydown','mousemove','mouseenter','focus','mousedown'].forEach(evt=>{
    scrollEl.addEventListener(evt, show, {passive: evt !== 'keydown' && evt !== 'focus' && evt !== 'mousedown'});
  });
  wrap.addEventListener('mouseenter', show);
  wrap.addEventListener('mousemove', show);
  wrap.addEventListener('mouseleave', ()=>{ clearTimeout(timer); timer = setTimeout(()=>wrap.classList.remove('show-scrollbar'), 350); });
  scrollEl.addEventListener('focus', show);
  scrollEl.addEventListener('blur', ()=>wrap.classList.remove('show-scrollbar'));
  window.addEventListener('resize', update);
  requestAnimationFrame(update);
}
function selectDevice(kind, value, label, save=true){
  const hidden = $('#' + kind);
  const listEl = $('#' + kind + 'list');
  if(!hidden || !listEl) return;
  const nextValue = (value === undefined || value === null) ? '' : String(value);
  const nextLabel = label || '';
  const wasMissing = hidden.dataset.missing === '1';
  if(nextValue || nextLabel) missingSelectionClearedByUser[kind] = false;
  if(kind === 'indev' && save) clearStartupInputRescan();
  const changed = hidden.value !== nextValue || (hidden.dataset.name || '') !== nextLabel || wasMissing;

  // An unavailable row is only a placeholder for the previously selected missing
  // device. As soon as the user selects a real output/input device, remove that
  // placeholder synchronously from the open list instead of waiting for the
  // periodic device refresh.
  if(nextValue && !String(nextValue).startsWith('__missing__:')){
    listEl.querySelectorAll('.devicerow').forEach(row=>{
      const rowLabel = String(row.dataset.label || row.textContent || '').trim();
      const rowValue = String(row.dataset.value || '').trim();
      const isMissingRow = row.dataset.missingSelection === '1' || rowValue.startsWith('__missing__:') || /\(unavailable\)\s*$/i.test(rowLabel);
      if(isMissingRow) row.remove();
    });
  }

  hidden.value = nextValue;
  hidden.dataset.name = nextLabel;
  hidden.dataset.missing = '0';
  if(changed) deviceSelectionRevision += 1;
  listEl.querySelectorAll('.devicerow').forEach(row=>{
    row.classList.toggle('selected', row.dataset.value === String(hidden.value));
    row.setAttribute('aria-selected', row.classList.contains('selected') ? 'true' : 'false');
  });
  updateDeviceSummary(hidden);
  if(changed){
    startReadiness = { ready:true, reason:'', lastRefreshAt:Date.now(), inputEnumerated:false };
    updateStartButtonState();
  }
  listEl.dispatchEvent(new Event('scroll'));
  if(save){
    if(currentPhase === 'error' || currentPhase === 'stopped'){
      savePrefsNow();
    }else{
      scheduleSavePrefs();
    }
  }
  if(changed && save){
    const validationError = getSelectionValidationError();
    if(!validationError && (currentPhase === 'error' || currentPhase === 'stopped')){
      setRunState('stopped', 'Stereo renderer is idle.');
      updateStartButtonState();
    }
  }
  if(save && changed) queueAutoApply(0);
}
function isSelectableOutputDevice(it){
  const outputs = Number((it && it.outputs) || 0);
  return outputs > 0 && outputs <= 2;
}
function renderDeviceRows(kind, items, preferredValue, preferredName){
  const hidden = $('#' + kind);
  const listEl = $('#' + kind + 'list');
  if(!hidden || !listEl) return;
  markListInteracting(kind, 250);
  const isInput = kind === 'indev';
  const prevValue = preferredValue || hidden.value;
  const prevName = preferredName || hidden.dataset.name || '';
  const hadPreviousSelection = !!(prevValue || prevName);
  listEl.innerHTML = '';
  const selectableItems = isInput
    ? items.filter(it => (it.compatible !== false) && Number(it.inputs || 0) >= 16)
    : items.filter(it => isSelectableOutputDevice(it));
  let wanted = '';
  let matchedByName = false;
  let matchedByValue = false;
  if(selectableItems.length){
    const savedMatch = findDeviceBySavedSelection(items, prevValue, prevName, isInput);
    if(savedMatch.item){
      wanted = String(savedMatch.item.index);
      matchedByName = !!savedMatch.matchedByName;
      matchedByValue = !!savedMatch.matchedByValue;
    }
  }
  const suppressAutoSelect = missingSelectionClearedByUser[kind] === true;
  if(selectableItems.length && !wanted && !hadPreviousSelection && !suppressAutoSelect) wanted = String(selectableItems[0].index);
  selectableItems.forEach(it=>{
    const row = document.createElement('button');
    row.type = 'button';
    row.className = 'devicerow';
    row.dataset.value = String(it.index);
    row.dataset.label = it.name;
    row.textContent = it.name;
    row.setAttribute('role', 'option');
    row.setAttribute('aria-selected', 'false');
    const selectNow = ()=>{
      markListInteracting(kind, 1200);
      selectDevice(kind, it.index, it.name, true);
    };
    row.addEventListener('pointerdown', selectNow);
    row.addEventListener('mousedown', selectNow);
    row.addEventListener('touchstart', selectNow, {passive:true});
    row.addEventListener('click', selectNow);
    listEl.appendChild(row);
  });
  if(isInput) updateInputHint(items);
  if(selectableItems.length && wanted){
    const selectedItem = selectableItems.find(it => String(it.index) === String(wanted));
    if(selectedItem){
      selectDevice(kind, selectedItem.index, selectedItem.name, false);
      return;
    }
  }
  const selectionMissing = hadPreviousSelection && !matchedByName && !matchedByValue;
  if(selectionMissing && prevName){
    const row = document.createElement('button');
    row.type = 'button';
    row.className = 'devicerow selected';
    row.dataset.missingSelection = '1';
    row.dataset.value = '__missing__:' + String(prevValue || prevName || '');
    row.dataset.label = prevName.replace(/\s*\(unavailable\)\s*$/i, '').trim() + ' (unavailable)';
    row.textContent = row.dataset.label;
    row.disabled = false;
    row.setAttribute('role', 'option');
    row.setAttribute('aria-selected', 'true');
    row.setAttribute('aria-disabled', 'true');
    listEl.insertBefore(row, listEl.firstChild);
  }
  hidden.value = hadPreviousSelection ? String(prevValue || '') : '';
  hidden.dataset.name = hadPreviousSelection ? String(prevName || '').replace(/\s*\(unavailable\)\s*$/i, '').trim() : '';
  hidden.dataset.missing = selectionMissing && prevName ? '1' : '0';
  if(selectionMissing && prevName) normalizeMissingSelectionRows(kind, prevName);
  updateDeviceSummary(hidden);
  listEl.dispatchEvent(new Event('scroll'));
}
function buildDeviceSignature(items){
  return JSON.stringify((items || []).map(it => ({
    index: String(it.index ?? ''),
    name: String(it.name || ''),
    inputs: Number(it.inputs || 0),
    outputs: Number(it.outputs || 0),
    compatible: it.compatible !== false
  })));
}
function inputSelectionMissingFromPayload(payload, inputValue, inputName){
  const wantedValue = String(inputValue || '').trim();
  const wantedName = String(inputName || '').replace(/\s*\(unavailable\)\s*$/i, '').trim();
  if(!wantedValue && !wantedName) return false;
  const rows = (payload && Array.isArray(payload.inputs)) ? payload.inputs : [];
  return !rows.some(it => {
    if((it.compatible === false) || Number(it.inputs || 0) < 16) return false;
    const rowValue = String(it.index ?? '').trim();
    const rowName = String(it.name || '').trim();
    if(wantedName && rowName === wantedName) return true;
    if(wantedValue && rowValue === wantedValue) return true;
    if(wantedValue && rowName === wantedValue) return true;
    return false;
  });
}
function clearStartupInputRescan(){
  startupInputRescanArmed = false;
  startupInputRescanAttempts = 0;
  if(startupInputRescanTimer){
    clearTimeout(startupInputRescanTimer);
    startupInputRescanTimer = null;
  }
}
function maybeScheduleStartupInputRescan(payload, source){
  if(!startupInputRescanArmed) return;
  if(currentPhase === 'starting' || currentPhase === 'running' || currentPhase === 'stopping' || currentPhase === 'disconnected') return;
  const inputEl = $('#indev');
  const inputValue = inputEl ? inputEl.value : '';
  const inputName = inputEl ? (inputEl.dataset.name || '') : '';
  if(!inputSelectionMissingFromPayload(payload, inputValue, inputName)){
    clearStartupInputRescan();
    const msgEl = $('#statusmsg');
    const msg = String(msgEl.textContent || '');
    if(msg.includes('Waiting for input device to become available after login')){
      setRunState('stopped', 'Stereo renderer is idle.');
    }
    return;
  }
  if(startupInputRescanAttempts >= STARTUP_INPUT_RESCAN_DELAYS_MS.length) return;
  const delay = STARTUP_INPUT_RESCAN_DELAYS_MS[startupInputRescanAttempts];
  startupInputRescanAttempts += 1;
  if(startupInputRescanTimer) clearTimeout(startupInputRescanTimer);
  const msgEl = $('#statusmsg');
  const current = String(msgEl.textContent || '');
  if(currentPhase === 'stopped' && (current === 'Stereo renderer is idle.' || current.includes('Selected input device is unavailable'))){
    msgEl.textContent = 'Waiting for input device to become available after login…';
  }
  startupInputRescanTimer = setTimeout(async ()=>{
    startupInputRescanTimer = null;
    try{
      const nextPayload = await refreshDevicesFull({startupRetry:true});
      maybeScheduleStartupInputRescan(nextPayload, 'startup retry');
    }catch(e){
      $('#log').textContent += 'Startup input rescan error: ' + e + '\n';
      maybeScheduleStartupInputRescan({inputs:[]}, 'startup retry error');
    }
  }, delay);
}
function setDevices(hiddenInput, items, preferredValue, preferredName, forceRender=false){
  const kind = hiddenInput.id;
  const hidden = hiddenInput;
  const nextValue = (preferredValue === undefined || preferredValue === null) ? '' : String(preferredValue || '');
  const nextName = String(preferredName || '');
  const signatureKey = buildDeviceSignature(items) + '|' + JSON.stringify({value: nextValue, name: nextName});
  const lastKey = kind === 'indev' ? lastInputDeviceSignature : lastOutputDeviceSignature;
  if(!forceRender && signatureKey === lastKey){
    hidden.value = nextValue;
    hidden.dataset.name = nextName.replace(/\s*\(unavailable\)\s*$/i, '').trim();
    if(hidden.dataset.missing === '1') normalizeMissingSelectionRows(kind, hidden.dataset.name || nextName || nextValue);
    updateDeviceSummary(hidden);
    return;
  }
  if(kind === 'indev') lastInputDeviceSignature = signatureKey;
  else lastOutputDeviceSignature = signatureKey;
  renderDeviceRows(kind, items, nextValue, nextName);
}
async function loadPrefs(){
  const r = await fetch('/api/preferences', {cache:'no-store'});
  const p = await r.json();
  $('#exe').value = p.exe || '';
  $('#frames').value = p.frames || '64';
  $('#input_latency_ms').value = p.input_latency_ms ?? '10';
  $('#output_latency_ms').value = p.output_latency_ms ?? '10';
  $('#keep_output_alive').checked = p.keep_output_alive !== false && String(p.keep_output_alive).toLowerCase() !== 'false';
  {
    const loadedPreamp = p.preamp_db ?? '-9.5';
    $('#preamp').value = String(loadedPreamp).trim() === '' ? '0' : loadedPreamp;
  }
  $('#lfe_lowpass').checked = p.lfe_lowpass !== false && String(p.lfe_lowpass).toLowerCase() !== 'false';
  $('#swap_outputs').checked = p.swap_outputs === true || String(p.swap_outputs).toLowerCase() === 'true';
  $('#global_output_peq_text').value = p.global_output_peq_text || '';
  $('#speaker_output_peq_text').value = p.speaker_output_peq_text || '';
  routingPeqProfiles = normalizeRoutingPeqProfiles(p.routing_peq_profiles);
  activeRoutingPeqProfile = String(p.active_routing_peq_profile || '').trim();
  renderRoutingPeqProfiles();
  updateLfeToggleCopy();
  $('#indev').value = p.input_device || '';
  $('#outdev').value = p.output_device || '';
  $('#indev').dataset.name = p.input_device_name || '';
  $('#outdev').dataset.name = p.output_device_name || '';
  syncApplyCommitValues();
  document.getElementById('indevdetails').open = !p.input_collapsed;
  document.getElementById('outdevdetails').open = !p.output_collapsed;
  document.getElementById('renderersettingsdetails').open = !p.settings_collapsed;
  document.getElementById('routingpeqdetails').open = !p.routing_peq_collapsed;
  document.getElementById('visualizerdetails').open = !p.visualizer_collapsed;
  document.getElementById('logdetails').open = !p.log_collapsed;
  updateDeviceSummary($('#indev'));
  updateDeviceSummary($('#outdev'));
  if($('#preset_display')) $('#preset_display').value = '9.1.6 bed (1:1)';
  return p;
}
async function refreshDevices(){
  const refreshId = ++deviceRefreshRequestId;
  const preserveInputList = isListInteracting('indev');
  const preserveOutputList = isListInteracting('outdev');
  const startSelectionRevision = deviceSelectionRevision;
  const snapshotInputValue = $('#indev').value;
  const snapshotOutputValue = $('#outdev').value;
  const snapshotInputName = $('#indev').dataset.name || '';
  const snapshotOutputName = $('#outdev').dataset.name || '';
  const inputClearedByUser = missingSelectionClearedByUser.indev === true;
  const outputClearedByUser = missingSelectionClearedByUser.outdev === true;
  const prefs = await fetch('/api/preferences', {cache:'no-store'}).then(r=>r.json()).catch(()=>({}));
  const exe = encodeURIComponent($('#exe').value.trim());
  const query = new URLSearchParams({
    exe: $('#exe').value.trim(),
    auto: '1',
    input_device: inputClearedByUser ? '' : (snapshotInputValue || prefs.input_device || ''),
    input_device_name: inputClearedByUser ? '' : (snapshotInputName || prefs.input_device_name || ''),
    output_device: outputClearedByUser ? '' : (snapshotOutputValue || prefs.output_device || ''),
    output_device_name: outputClearedByUser ? '' : (snapshotOutputName || prefs.output_device_name || '')
  });
  const r = await fetch('/api/devices?' + query.toString(), {cache:'no-store'});
  const j = await r.json();
  if(j.exe && $('#exe').value.trim() !== String(j.exe).trim()){
    $('#exe').value = String(j.exe).trim();
    if(typeof $('#exe').__syncCommittedValue === 'function') $('#exe').__syncCommittedValue();
  }
  if(refreshId !== deviceRefreshRequestId) return;
  const selectionChangedDuringRefresh = deviceSelectionRevision !== startSelectionRevision;
  const liveInputValue = $('#indev').value;
  const liveOutputValue = $('#outdev').value;
  const liveInputName = $('#indev').dataset.name || '';
  const liveOutputName = $('#outdev').dataset.name || '';
  const nextInputValue = inputClearedByUser ? '' : (selectionChangedDuringRefresh ? liveInputValue : (snapshotInputValue || prefs.input_device));
  const nextOutputValue = outputClearedByUser ? '' : (selectionChangedDuringRefresh ? liveOutputValue : (snapshotOutputValue || prefs.output_device));
  const nextInputName = inputClearedByUser ? '' : (selectionChangedDuringRefresh ? liveInputName : (snapshotInputName || prefs.input_device_name));
  const nextOutputName = outputClearedByUser ? '' : (selectionChangedDuringRefresh ? liveOutputName : (snapshotOutputName || prefs.output_device_name));
  if(!preserveInputList){
    setDevices(
      $('#indev'),
      j.inputs || [],
      nextInputValue,
      nextInputName
    );
  } else {
    updateInputHint(j.inputs || []);
    updateDeviceSummary($('#indev'));
  }
  if(!preserveOutputList){
    setDevices(
      $('#outdev'),
      j.outputs || [],
      nextOutputValue,
      nextOutputName
    );
  } else {
    updateDeviceSummary($('#outdev'));
  }
  const inputListAuthoritative = j.input_enumerated === true;
  const inputSelected = findDeviceBySavedSelection(j.inputs || [], nextInputValue, nextInputName, true).item;
  const outputSelected = findDeviceBySavedSelection(j.outputs || [], nextOutputValue, nextOutputName, false).item;
  const inputMissing = inputListAuthoritative && !!(nextInputValue || nextInputName) && !inputSelected;
  const outputMissing = !!(nextOutputValue || nextOutputName) && !outputSelected;
  if((currentPhase === 'running' || currentPhase === 'starting' || currentPhase === 'stopping') && (inputMissing || outputMissing)){
    const reason = inputMissing
      ? `Renderer stopped because the selected input device was removed: ${nextInputName || nextInputValue || 'the selected input device'}.`
      : `Renderer stopped because the selected output device was removed: ${nextOutputName || nextOutputValue || 'the selected output device'}.`;
    // Apply the stopped/unavailable UI before consuming backend readiness. The
    // selected device is already absent from this authoritative refresh, so there
    // is no useful intermediate Starting… / Waiting for audio devices state.
    stopRendererForMissingDevice(reason);
  }else if((currentPhase === 'error' || currentPhase === 'stopped') && !inputMissing && !outputMissing){
    const currentMessage = String($('#statusmsg').textContent || '').trim();
    if(
      currentMessage === 'Selected output device is unavailable.' ||
      currentMessage === 'Selected input device is unavailable or does not expose at least 16 input channels.' ||
      isControlledStopFinalText(currentMessage)
    ){
      setRunState('stopped', 'Stereo renderer is idle.');
      updateStartButtonState();
    }
  }
  setStartReadinessFromDevicePayload(j);
  // Do not save preferences from the 1.5 s automatic device refresh.
  // Saving preferences may need device-name resolution; on macOS, repeatedly
  // touching the input-device path after an output hot-unplug can retrigger
  // the microphone/TCC permission prompt in a tight loop. User edits already
  // save through selectDevice(), toggles, text commits, Start, and Apply.
  if(j.error){
    $('#log').textContent += 'Device refresh error: ' + j.error + '\n';
  }
}
async function refreshDevicesFull(options={}){
  const prefs = await fetch('/api/preferences', {cache:'no-store'}).then(r=>r.json()).catch(()=>({}));
  const query = new URLSearchParams({
    exe: $('#exe').value.trim(),
    auto: '0',
    input_device: missingSelectionClearedByUser.indev ? '' : ($('#indev').value || prefs.input_device || ''),
    input_device_name: missingSelectionClearedByUser.indev ? '' : ($('#indev').dataset.name || prefs.input_device_name || ''),
    output_device: missingSelectionClearedByUser.outdev ? '' : ($('#outdev').value || prefs.output_device || ''),
    output_device_name: missingSelectionClearedByUser.outdev ? '' : ($('#outdev').dataset.name || prefs.output_device_name || '')
  });
  const r = await fetch('/api/devices?' + query.toString(), {cache:'no-store'});
  const j = await r.json();
  if(j.exe && $('#exe').value.trim() !== String(j.exe).trim()){
    $('#exe').value = String(j.exe).trim();
    if(typeof $('#exe').__syncCommittedValue === 'function') $('#exe').__syncCommittedValue();
  }
  const nextInputValue = missingSelectionClearedByUser.indev ? '' : ($('#indev').value || prefs.input_device || '');
  const nextOutputValue = missingSelectionClearedByUser.outdev ? '' : ($('#outdev').value || prefs.output_device || '');
  const nextInputName = missingSelectionClearedByUser.indev ? '' : ($('#indev').dataset.name || prefs.input_device_name || '');
  const nextOutputName = missingSelectionClearedByUser.outdev ? '' : ($('#outdev').dataset.name || prefs.output_device_name || '');
  setDevices($('#indev'), j.inputs || [], nextInputValue, nextInputName, true);
  setDevices($('#outdev'), j.outputs || [], nextOutputValue, nextOutputName, true);
  updateInputHint(j.inputs || []);
  setStartReadinessFromDevicePayload(j);
  if(j.error) $('#log').textContent += 'Device scan error: ' + j.error + '\n';
  return j;
}
async function stopRendererForMissingDevice(reason){
  const normalizedReason = String(reason || '').trim() || 'Renderer stopped because the selected audio device was removed.';
  const stopReason = normalizedReason.toLowerCase().includes('selected input device') ? 'input_removed' : 'output_removed';
  const finalText = normalizedReason;

  // The UI must become idle atomically as soon as the selected device is known
  // to be gone. Do this even if a previous async /api/stop call is still in
  // flight, otherwise a quick start/disconnect race can leave the UI showing
  // Starting… with an unavailable output selector until the backend catches up.
  const removed = parseRemovedDeviceStatus(finalText);
  if(removed) markSelectedDeviceUnavailable(removed.kind, removed.name);
  setRunState('stopped', finalText);
  updateStartButtonState();

  if(missingDeviceStopInFlight && missingDeviceStopReason === normalizedReason) return;
  missingDeviceStopInFlight = true;
  missingDeviceStopReason = normalizedReason;
  try{
    await fetch('/api/stop', {
      method:'POST',
      headers:{'Content-Type':'application/json'},
      body: JSON.stringify({reason: finalText, stop_text: finalText, stop_reason: stopReason, restart_keepalive: false})
    });
  }catch(e){
  }finally{
    setTimeout(()=>{
      missingDeviceStopInFlight = false;
      missingDeviceStopReason = '';
    }, 1500);
  }
}
async function startRenderer(){
  const startBtn = $('#start');
  // Only a real click on an enabled Start button should launch the renderer.
  // Disabled clicks must not be remembered or replayed after initialization or
  // after a settings apply finishes.
  if(startBtn && startBtn.disabled) return;
  if(appInitializing || applyBusy){
    updateStartButtonState();
    return;
  }
  clearTimeout(autoApplyTimer);
  autoApplyTimer = null;
  applyBusy = true;
  try{
    const validationError = getSelectionValidationError();
    if(validationError){
      // A missing or not-yet-reconnected audio device is not a renderer fault.
      // Keep this in the normal idle/stopped state so a stale click during
      // hotplug cannot flash an Error pill.
      markUnavailableFromStatusText(validationError);
      const stopMessage = normalizeUnavailableStopMessage(validationError);
      setRunState('stopped', stopMessage);
      updateStartButtonState();
      return;
    }
    applyTransitionActive = true;
    applyTransitionIgnoreAllStatuses = true;
    applyTransitionMinRevision = lastStatusRevision;
    setRunState('starting', 'Launching stereo renderer…');
    $('#start').disabled = true;
    $('#stop').disabled = true;
    // /api/start saves the exact payload after resolving the devices. Do not
    // pre-save here: the preferences endpoint may spin up the output keep-alive
    // immediately before launch, which can leave the UI stuck at Starting… on
    // some Core Audio devices.
    const r = await fetch('/api/start', {
      method:'POST',
      headers:{'Content-Type':'application/json'},
      body: JSON.stringify(currentPayload())
    });
    const j = await r.json();
    if(!j.ok){
      applyTransitionActive = false;
      applyTransitionIgnoreAllStatuses = false;
      applyTransitionMinRevision = null;
      const message = j.status_text || j.error || 'Could not start renderer.';
      const requestedPhase = normalizeRunPhase(String(j.phase || '').trim(), message);
      if(requestedPhase === 'stopped'){
        markUnavailableFromStatusText(message);
        const stopMessage = normalizeUnavailableStopMessage(message);
        setRunState('stopped', stopMessage);
        updateStartButtonState();
        return;
      }
      try{
        const statusResp = await fetch('/api/status', {cache:'no-store'});
        if(statusResp.ok){
          const latestStatus = await statusResp.json();
          const latestPhase = latestStatus ? String(latestStatus.phase || '') : '';
          if(latestStatus && latestStatus.status_text && (latestPhase === 'error' || latestPhase === 'stopped')){
            applyStatusPayload(latestStatus);
          }else{
            setRunState('error', message);
          }
        }else{
          setRunState('error', message);
        }
      }catch(_e){
        setRunState('error', message);
      }
    }else{
      await refreshLog();
      try{
        const statusResp = await fetch('/api/status', {cache:'no-store'});
        applyTransitionActive = false;
        applyTransitionIgnoreAllStatuses = false;
        applyTransitionMinRevision = null;
        if(statusResp.ok){
          applyStatusPayload(await statusResp.json());
        }
      }catch(_e){
        applyTransitionActive = false;
        applyTransitionIgnoreAllStatuses = false;
        applyTransitionMinRevision = null;
      }
    }
  }catch(e){
    applyTransitionActive = false;
    applyTransitionIgnoreAllStatuses = false;
    applyTransitionMinRevision = null;
    const message = e && e.message ? e.message : 'Could not start renderer.';
    setRunState('error', message);
  } finally {
    applyBusy = false;
    if(pendingAutoApply){
      pendingAutoApply = false;
      setTimeout(()=>{ applyPresetAndRestart(); }, 0);
    }
  }
}
async function stopRenderer(){
  if(applyBusy) return;
  applyBusy = true;
  try{
    setRunState('stopping', 'Stopping renderer…');
    $('#start').disabled = true;
    $('#stop').disabled = true;
    await fetch('/api/stop', {method:'POST'});
  } finally {
    applyBusy = false;
  }
}
function handleDisconnect(){
  if(disconnected) return;
  disconnected = true;
  if(eventSource){
    try{ eventSource.close(); }catch(e){}
    eventSource = null;
  }
  clearTimeout(eventRetryTimer);
  $('#overlay').classList.add('show');
  setRunState('disconnected', 'Launcher script stopped.');
  clearTimeout(pollTimer);
  clearInterval(embeddedFallbackPollTimer);
  embeddedFallbackPollTimer = null;
  clearInterval(heartbeatTimer);
  clearInterval(logTimer);
  clearInterval(deviceRefreshTimer);
  try{ window.close(); }catch(e){}
  setTimeout(()=>{ try{ window.open('', '_self'); window.close(); }catch(e){} }, 120);
  setTimeout(()=>{ try{ location.replace('about:blank'); }catch(e){} }, 500);
}
window.__nativeApplyStatus = function(payload){
  pendingNativeStatus = mergeStatusPeakPayload(pendingNativeStatus, payload || {});
  if(document.hidden){
    const next = pendingNativeStatus;
    pendingNativeStatus = null;
    applyStatusPayload(next || {});
    return;
  }
  if(pendingNativeStatusFrame) return;
  pendingNativeStatusFrame = requestAnimationFrame(()=>{
    pendingNativeStatusFrame = 0;
    const next = pendingNativeStatus;
    pendingNativeStatus = null;
    applyStatusPayload(next || {});
  });
};
window.__nativeApplyLog = function(payload){ applyLogPayload(payload || {}); };
window.__nativeBridgeReady = true;

function isControlledStopFinalText(text){
  const msg = String(text || '').toLowerCase();
  return (
    msg.startsWith('renderer stopped because the selected output device was removed') ||
    msg.startsWith('renderer stopped because the selected input device was removed') ||
    msg.startsWith('renderer stopped because the selected audio device was removed') ||
    msg.startsWith('renderer stopped because the live audio stream ended')
  );
}
function controlledStopInterimText(finalText){
  const msg = String(finalText || '').toLowerCase();
  if(msg.includes('selected input device')) return 'Selected input device was removed. Stopping renderer…';
  if(msg.includes('selected audio device')) return 'Selected audio device was removed. Stopping renderer…';
  if(msg.includes('live audio stream ended')) return 'Live audio stream ended. Stopping renderer…';
  return 'Selected output device was removed. Stopping renderer…';
}
function clearControlledStopHold(){
  if(controlledStopHoldTimer){
    clearTimeout(controlledStopHoldTimer);
    controlledStopHoldTimer = null;
  }
  controlledStopHoldKey = '';
}
function applyStatusPayload(j){
  disconnectFailures = 0;
  const nextRevision = (typeof j.status_revision === 'number') ? j.status_revision : null;
  if(nextRevision !== null){
    if(nextRevision < lastStatusRevision) return;
  }
  rendererRecoveryPending = !!(j && j.renderer_recovery_pending);
  let nextText = j.status_text || 'Stereo renderer is idle.';
  let nextPhase = normalizeRunPhase(j.phase || 'stopped', nextText);
  const unavailableFinal = (nextPhase === 'stopped' || nextPhase === 'error') && markUnavailableFromStatusText(nextText);
  if(unavailableFinal){
    nextPhase = 'stopped';
    nextText = normalizeUnavailableStopMessage(nextText);
  }
  let controlledStopFinal = nextPhase === 'stopped' && isControlledStopFinalText(nextText);
  const controlledStopRemovedDevice = controlledStopFinal ? parseRemovedDeviceStatus(nextText) : null;
  const controlledStopKey = controlledStopFinal ? controlledStopUnavailableKey(nextRevision, nextText) : '';
  if(controlledStopFinal && controlledStopRemovedDevice){
    const staleForCurrentSelection = !controlledStopAppliesToCurrentSelection(controlledStopRemovedDevice);
    const alreadyHandledAndNowAvailable = lastAppliedControlledStopUnavailableKey === controlledStopKey && selectedDeviceIsAvailableInUi(controlledStopRemovedDevice.kind, controlledStopRemovedDevice.name);
    if(staleForCurrentSelection || alreadyHandledAndNowAvailable){
      nextText = 'Stereo renderer is idle.';
      controlledStopFinal = false;
    }
  }
  // Output/input hot-unplug is now shown as a direct final Stopped state.
  // Do not insert an artificial Stopping… hold on the UI side.
  if(controlledStopHoldTimer){
    clearControlledStopHold();
  }
  if(j.__controlled_stop_hold_release){
    controlledStopHoldKey = '';
    controlledStopHoldTimer = null;
  }

  if(applyTransitionActive){
    if(applyTransitionIgnoreAllStatuses){
      return;
    }
    const minRevision = (typeof applyTransitionMinRevision === 'number') ? applyTransitionMinRevision : lastStatusRevision;
    if(nextRevision !== null && nextRevision <= minRevision){
      return;
    }
    if(nextPhase === 'running' || nextPhase === 'error' || nextPhase === 'disconnected'){
      applyTransitionActive = false;
      applyTransitionMinRevision = null;
    }else{
      return;
    }
  }

  if(nextRevision !== null){
    lastStatusRevision = nextRevision;
  }

  if(nextPhase === 'stopped' || nextPhase === 'error' || nextPhase === 'disconnected'){
    missingDeviceStopInFlight = false;
    missingDeviceStopReason = '';
  }
  if(nextPhase === 'running'){
    lastAppliedControlledStopUnavailableKey = '';
    const inputLevelsMap = j.input_levels_db || null;
    const visualFlags = statusVisualSignalFlags(j);
    updateSharedVisualGate(visualFlags);
    if(document.hidden && !visualFlags.anyActive){
      // While hidden, requestAnimationFrame may not run, so a silent status
      // packet must clear the rendered DOM immediately instead of waiting for
      // the window to become visible again.
      forceIdleVisualState();
    }else{
      // Update both raw input-channel badges and folded stereo output meters from
      // the same status packet. Bed badges stay raw and never copy sum-meter color.
      setMeter('L', j.meter_left_db || '-inf', !!j.clip_left);
      setMeter('R', j.meter_right_db || '-inf', !!j.clip_right);
      setWaveTransientMap(j.input_transients_db || {});
      if(inputLevelsMap){
        setInputLevels(inputLevelsMap, true);
      }else{
        setActiveInputs(j.active_labels || [], true);
      }
    }
  }else{
    sharedVisualSilenceSince = 0;
    sharedVisualsCleared = true;
    sharedVisualInputGroupActive = false;
    sharedVisualOutputGroupActive = false;
    holdInputBadgesWithOutput = false;
    holdSumMetersWithInputs = false;
    setWaveTransientMap({});
    setInputLevels({}, false);
    resetWaveField();
    resetMeter('L');
    resetMeter('R');
  }
  if(controlledStopFinal){
    const removed = controlledStopRemovedDevice || parseRemovedDeviceStatus(nextText);
    if(removed){
      const key = controlledStopKey || controlledStopUnavailableKey(nextRevision, nextText);
      if(lastAppliedControlledStopUnavailableKey !== key){
        markSelectedDeviceUnavailable(removed.kind, removed.name);
        lastAppliedControlledStopUnavailableKey = key;
      }
    }
  }
  setRunState(nextPhase, nextText);
  const startBtn = $('#start');
  startBtn.textContent = 'Start';
  updateStartButtonState();
}
function applyLogPayload(j){
  if(typeof j.log_revision === 'number') lastLogRevision = j.log_revision;
  const nextLog = j.log || '';
  if($('#log').textContent !== nextLog){
    $('#log').textContent = nextLog;
    $('#log').scrollTop = $('#log').scrollHeight;
  }
}
async function poll(){
  try{
    const r = await fetch('/api/status', {cache:'no-store'});
    if(!r.ok) throw new Error('status fetch failed');
    const j = await r.json();
    applyStatusPayload(j);
    if(typeof j.log_revision === 'number' && j.log_revision !== lastLogRevision){
      refreshLog();
    }
  }catch(e){
    disconnectFailures += 1;
    if(disconnectFailures >= 8){
      handleDisconnect();
      return;
    }
    pollTimer = setTimeout(poll, 50);
    return;
  }
  scheduleNextPoll();
}
async function embeddedStatusFallbackPoll(){
  if(!EMBEDDED_MODE || disconnected) return;
  try{
    const r = await fetch('/api/status', {cache:'no-store'});
    if(!r.ok) throw new Error('status fetch failed');
    const j = await r.json();
    applyStatusPayload(j);
    if(typeof j.log_revision === 'number' && j.log_revision !== lastLogRevision){
      refreshLog();
    }
    disconnectFailures = 0;
  }catch(e){
    disconnectFailures += 1;
    if(disconnectFailures >= 12) handleDisconnect();
  }
}
function startEmbeddedStatusFallbackPoll(){
  if(!EMBEDDED_MODE || embeddedFallbackPollTimer) return;
  embeddedFallbackPollTimer = setInterval(embeddedStatusFallbackPoll, 750);
}
function connectEventStream(){
  if(disconnected || eventSource) return;
  try{
    eventSource = new EventSource('/api/events');
  }catch(e){
    scheduleNextPoll();
    return;
  }
  eventSource.addEventListener('status', (ev)=>{
    try{ applyStatusPayload(JSON.parse(ev.data)); }catch(e){}
  });
  eventSource.addEventListener('log', (ev)=>{
    try{ applyLogPayload(JSON.parse(ev.data)); }catch(e){}
  });
  eventSource.addEventListener('shutdown', ()=>{
    handleDisconnect();
  });
  eventSource.onopen = ()=>{
    disconnectFailures = 0;
    clearTimeout(pollTimer);
    clearTimeout(eventRetryTimer);
  };
  eventSource.onerror = ()=>{
    if(disconnected) return;
    if(eventSource){
      try{ eventSource.close(); }catch(e){}
      eventSource = null;
    }
    disconnectFailures += 1;
    if(disconnectFailures >= 8){
      handleDisconnect();
      return;
    }
    clearTimeout(eventRetryTimer);
    eventRetryTimer = setTimeout(connectEventStream, 80);
    pollTimer = setTimeout(poll, 0);
  };
}
async function refreshLog(){
  try{
    const r = await fetch('/api/log', {cache:'no-store'});
    if(!r.ok) throw new Error('log fetch failed');
    const j = await r.json();
    lastLogRevision = (typeof j.log_revision === 'number') ? j.log_revision : lastLogRevision;
    const nextLog = j.log || '';
    if($('#log').textContent !== nextLog){
      $('#log').textContent = nextLog;
      $('#log').scrollTop = $('#log').scrollHeight;
    }
  }catch(e){}
}
async function heartbeat(){
  try{
    await fetch('/api/client_ping', {
      method:'POST',
      headers:{'Content-Type':'application/json'},
      body: JSON.stringify({client_id: CLIENT_ID}),
      keepalive: true
    });
  }catch(e){
    // Let status polling decide when the launcher is truly gone.
  }
}
function notifyClose(){
  if(EMBEDDED_MODE) return;
  const data = JSON.stringify({client_id: CLIENT_ID});
  try{
    navigator.sendBeacon('/api/client_close', new Blob([data], {type:'application/json'}));
  }catch(e){
    try{
      fetch('/api/client_close', {
        method:'POST',
        headers:{'Content-Type':'application/json'},
        body: data,
        keepalive: true
      });
    }catch(_e){}
  }
}

badges();
fillPresets();

document.querySelectorAll('input:not([type=file]),select,textarea').forEach(el => {
  el.addEventListener('change', scheduleSavePrefs);
  // Do not save the preamp field on every keystroke. It is committed
  // deliberately on Enter/blur/change so partial edits like "-" or blank
  // never become the live or saved preamp value while the user is typing.
  if(el.id !== 'preamp') el.addEventListener('input', scheduleSavePrefs);
});
function installTextFileLoader(fileSelector, textSelectors, clearSelectors){
  const fileEl = $(fileSelector);
  if(!fileEl) return;
  fileEl.addEventListener('change', async ()=>{
    const file = fileEl.files && fileEl.files[0];
    if(!file) return;
    try{
      const text = await file.text();
      (clearSelectors || []).forEach(sel=>{
        const target = $(sel);
        if(target){
          target.value = '';
          if(typeof target.__syncCommittedValue === 'function') target.__syncCommittedValue();
        }
      });
      (textSelectors || []).forEach(sel=>{
        const target = $(sel);
        if(target){
          target.value = text;
          if(typeof target.__syncCommittedValue === 'function') target.__syncCommittedValue();
        }
      });
      scheduleSavePrefs();
      queueAutoApply(0);
    }catch(e){
      setRunState('error', 'Could not read PEQ file: ' + e);
    }finally{
      fileEl.value = '';
    }
  });
}
function installClearButton(buttonSelector, textSelector){
  const button = $(buttonSelector);
  const target = $(textSelector);
  if(!button || !target) return;
  button.addEventListener('click', ()=>{
    target.value = '';
    if(typeof target.__syncCommittedValue === 'function') target.__syncCommittedValue();
    scheduleSavePrefs();
    queueAutoApply(0);
  });
}
bindApplyOnCommit($('#frames'));
bindApplyOnCommit($('#input_latency_ms'));
bindApplyOnCommit($('#output_latency_ms'));
bindApplyOnCommit($('#preamp'), {normalizeBeforeCommit: normalizePreampEmptyToZero, onCommit: scheduleSavePrefs});
bindApplyOnCommit($('#lfe_lowpass'));
bindApplyOnCommit($('#swap_outputs'));
bindApplyOnCommit($('#global_output_peq_text'));
bindApplyOnCommit($('#speaker_output_peq_text'));

// Preamp edits are intentionally not auto-applied while typing. Press Enter,
// tab/click out, or use the number-field spinner to commit the value.
$('#lfe_lowpass').addEventListener('change', updateLfeToggleCopy);
installTextFileLoader('#global_peq_file', ['#global_output_peq_text']);
installTextFileLoader('#speaker_peq_file', ['#speaker_output_peq_text']);
installClearButton('#clear_global_peq', '#global_output_peq_text');
installClearButton('#clear_speaker_peq', '#speaker_output_peq_text');
$('#routing_peq_profile_select').addEventListener('change', ()=>{
  activeRoutingPeqProfile = $('#routing_peq_profile_select').value || '';
  const nameInput = $('#routing_peq_profile_name');
  if(nameInput) nameInput.value = activeRoutingPeqProfile;
  savePrefsNow();
  renderRoutingPeqProfiles();
});
$('#save_routing_peq_profile').onclick = saveRoutingPeqProfile;
$('#load_routing_peq_profile').onclick = loadRoutingPeqProfile;
$('#delete_routing_peq_profile').onclick = deleteRoutingPeqProfile;
$('#start').onclick = startRenderer;
$('#stop').onclick = stopRenderer;
document.getElementById('indevdetails').addEventListener('toggle', (ev)=>{
  if(!appInitializing && !ev.currentTarget.open) clearMissingDeviceSelection('indev', true);
  updateDeviceSummary($('#indev'));
  if(!appInitializing) savePrefsNow();
});
document.getElementById('outdevdetails').addEventListener('toggle', (ev)=>{
  if(!appInitializing && !ev.currentTarget.open) clearMissingDeviceSelection('outdev', true);
  updateDeviceSummary($('#outdev'));
  if(!appInitializing) savePrefsNow();
});
['renderersettingsdetails','routingpeqdetails','visualizerdetails','logdetails'].forEach((id)=>{
  const el = document.getElementById(id);
  if(el) el.addEventListener('toggle', ()=>{ savePrefsNow(); });
});
installMacMinimizeShortcut();
installTransientScrollbar($('#indevlist'));
installTransientScrollbar($('#outdevlist'));
['indevlist','outdevlist'].forEach((id)=>{
  const el = document.getElementById(id);
  const kind = id.replace('list','');
  if(!el) return;
  ['pointerdown','mousedown','touchstart','focus','mouseenter','keydown'].forEach((evt)=>{
    el.addEventListener(evt, ()=>markListInteracting(kind, 1200), {passive: evt === 'touchstart'});
  });
});

if(!EMBEDDED_MODE){
  window.addEventListener('pagehide', notifyClose);
  window.addEventListener('beforeunload', notifyClose);
}

function refreshAfterWindowReturn(){
  const wasSuspended = visualsWereSuspended;
  visualsWereSuspended = false;
  clearTimeout(focusDeviceRefreshTimer);
  if(wasSuspended){
    // Keep the last known live meter frame visible on return. The explicit
    // status refresh below will correct stale values, but it should not create
    // a visible empty-meter flash while music is still playing.
    snapVisualsToLatestRawState();
  }
  focusDeviceRefreshTimer = setTimeout(()=>{
    refreshStatusAndSnapVisuals();
    refreshDevices().catch(()=>{});
  }, 0);
}
document.addEventListener('visibilitychange', ()=>{
  if(document.hidden){
    visualsWereSuspended = true;
    meterAnimLastTs = 0;
    // Keep the last rendered meter frame. Active/silent hidden status packets
    // still update or clear the visuals, and focus return refreshes status.
  }else{
    refreshAfterWindowReturn();
  }
});
window.addEventListener('focus', refreshAfterWindowReturn);
window.addEventListener('pageshow', refreshAfterWindowReturn);

(async function init(){
  const prefs = await loadPrefs();
  await fetch('/api/client_open', {
    method:'POST',
    headers:{'Content-Type':'application/json'},
    body: JSON.stringify({client_id: CLIENT_ID})
  }).catch(()=>{});
  const refreshInputButton = $('#refresh_input_devices');
  if(refreshInputButton){
    refreshInputButton.addEventListener('click', ()=>{ refreshDevicesFull().catch(e=>{ $('#log').textContent += 'Device scan error: ' + e + '\n'; }); });
  }
  // The first scan after opening the app is an intentional foreground scan, not
  // a background hotplug refresh. It must populate input devices even when the
  // previously selected output device is currently disconnected. Later timer
  // refreshes stay output-safe and avoid touching the input side during/after
  // hot-unplug events.
  //
  // After a reboot/login reopen, CoreAudio can briefly report an incomplete
  // input inventory while the multichannel device is still coming back. The
  // normal 1.5 s refresh is output-only by design, so do a bounded set of
  // startup-only full rescans until the saved input reappears.
  let initialDevicePayload = null;
  try{
    initialDevicePayload = await refreshDevicesFull({startupInitial:true});
  }catch(e){
    $('#log').textContent += 'Initial device scan error: ' + e + '\n';
    await refreshDevices();
    initialDevicePayload = {inputs:[]};
  }
  maybeScheduleStartupInputRescan(initialDevicePayload, 'initial open');
  deviceRefreshTimer = setInterval(()=>{ refreshDevices().catch(()=>{}); }, 1500);
  heartbeatTimer = setInterval(heartbeat, 2000);
  renderMeter('L', 0);
  renderMeter('R', 0);
  meterAnimHandle = requestAnimationFrame(animateMeters);
  refreshLog();
  appInitializing = false;
  updateStartButtonState();
  if(EMBEDDED_MODE){
    try{
      const r = await fetch('/api/status', {cache:'no-store'});
      if(r.ok) applyStatusPayload(await r.json());
    }catch(e){}
    startEmbeddedStatusFallbackPoll();
  }else{
    poll();
    connectEventStream();
  }
})();
</script>
</body>
</html>'''

def load_preferences():
    prefs = dict(DEFAULT_PREFS)
    raw = None
    try:
        if PREFS_PATH.exists():
            raw = json.loads(PREFS_PATH.read_text())
            if isinstance(raw, dict):
                prefs.update({k: v for k, v in raw.items() if k in prefs or k.endswith("_name")})
    except Exception:
        raw = None
    # Keep any previously saved preamp value exactly as-is. The -9.5 dB
    # value in DEFAULT_PREFS only applies on first launch, or if an older
    # preferences file does not contain a preamp_db key at all.
    if not isinstance(prefs.get("map"), list) or len(prefs["map"]) != len(BED_LABELS):
        prefs["map"] = list(DEFAULT_PREFS["map"])
    prefs["exe"] = normalize_renderer_exe(prefs.get("exe"))
    return prefs

def save_preferences(prefs):
    clean = dict(DEFAULT_PREFS)
    clean.update(prefs or {})
    if not isinstance(clean.get("map"), list) or len(clean["map"]) != len(BED_LABELS):
        clean["map"] = list(DEFAULT_PREFS["map"])
    clean["exe"] = normalize_renderer_exe(clean.get("exe"))
    try:
        PREFS_PATH.write_text(json.dumps(clean, indent=2))
    except Exception:
        pass
    return clean

def parse_preamp_db(value):
    text = str(value if value is not None else "").strip()
    if text == "":
        return 0.0
    try:
        return float(text)
    except Exception:
        raise ValueError("Preamp dB must be a number. Leave it blank to use 0 dB.")


def bool_value(value, default=True):
    if isinstance(value, bool):
        return value
    if value is None:
        return default
    text = str(value).strip().lower()
    if text in ("1", "true", "yes", "on"):
        return True
    if text in ("0", "false", "no", "off"):
        return False
    return default


class NativeBridgeBase:
    def push_status(self, payload):
        return

    def push_log(self, payload):
        return

    def minimize(self):
        return False


class NullNativeBridge(NativeBridgeBase):
    pass


def set_native_bridge(bridge):
    global NATIVE_BRIDGE
    NATIVE_BRIDGE = bridge or NullNativeBridge()


def push_native_status(payload=None):
    bridge = NATIVE_BRIDGE
    if bridge is None:
        return
    if payload is None:
        payload = STATE.status()
    try:
        bridge.push_status(payload)
    except Exception:
        pass


def push_native_log(payload=None):
    bridge = NATIVE_BRIDGE
    if bridge is None:
        return
    if payload is None:
        payload = STATE.log_payload()
    try:
        bridge.push_log(payload)
    except Exception:
        pass


class RendererState:
    def __init__(self):
        self.lock = threading.Lock()
        self.cond = threading.Condition(self.lock)
        self.proc = None
        self.proc_pgid = None
        self.reader_thread = None
        self.keepalive_proc = None
        self.keepalive_proc_pgid = None
        self.keepalive_reader_thread = None
        self.keepalive_stop_requested = False
        self.keepalive_restart_pending = False
        self.renderer_recovery_pending = False
        self.renderer_recovery_cancel_requested = False
        self.server = None
        self.shutdown_requested = False
        self.renderer_stop_requested = False
        self.renderer_stop_reason = ""
        self.renderer_stop_final_text = ""
        self.renderer_seen_live = False
        self.clients = {}
        self.ever_had_client = False
        self.active_labels = []
        self.last_active = "(none)"
        self.input_levels_db = default_input_levels_db()
        self.input_transients_db = default_input_levels_db()
        self.meter_left_db = "-inf"
        self.meter_right_db = "-inf"
        self.clip_left = False
        self.clip_right = False
        self.clip_left_until = 0.0
        self.clip_right_until = 0.0
        self.phase = "stopped"
        self.status_text = "Stereo renderer is idle."
        self.last_exit_code = None
        self.log_lines = []
        self.max_log_lines = 2000
        self.log_revision = 0
        self.status_revision = 0
        self.log_cache = ""
        self.preferences = load_preferences()
        self.client_shutdown_timer = None
        self.lifecycle_lock = threading.Lock()
        self.running_exe = ""
        self.running_input_device = ""
        self.running_output_device = ""
        self.running_input_device_name = ""
        self.running_output_device_name = ""
        self.cached_inputs = []
        self.cached_outputs = []
        self.keepalive_exe = ""
        self.keepalive_output_device = ""
        self.keepalive_output_device_name = ""
        self.awaiting_live_status = False
        self.audio_device_quiet_until = 0.0
        self.audio_device_quiet_reason = ""
        self.device_inventory_signature = ""
        self.device_topology_changed_at = 0.0
        self.last_full_device_scan_at = 0.0

    def bump_status(self):
        self.status_revision += 1
        self.cond.notify_all()

    def status_unlocked(self):
        # The renderer can report a one-buffer clip event that is shorter than
        # a browser repaint or status-poll cycle. Latch it in the launcher
        # state, not only in JavaScript, so native-status coalescing and HTTP
        # polling cannot hide short clipping events.
        now = time.monotonic()
        clip_left_visible = self.clip_left or (now < self.clip_left_until)
        clip_right_visible = self.clip_right or (now < self.clip_right_until)
        return {
            "phase": self.phase,
            "status_text": self.status_text,
            "renderer_recovery_pending": bool(self.renderer_recovery_pending),
            "stop_reason": self.renderer_stop_reason,
            "active_labels": list(self.active_labels),
            "last_active": self.last_active,
            "input_levels_db": dict(self.input_levels_db),
            "input_transients_db": dict(self.input_transients_db),
            "meter_left_db": self.meter_left_db,
            "meter_right_db": self.meter_right_db,
            "clip_left": clip_left_visible,
            "clip_right": clip_right_visible,
            "log_revision": self.log_revision,
            "status_revision": self.status_revision,
        }

    def log_payload_unlocked(self):
        return {
            "log_revision": self.log_revision,
            "log": self.log_cache,
        }

    def append_log(self, line):
        line = line.rstrip("\n")
        if not line:
            return
        payload = None
        with self.lock:
            self.log_lines.append(line)
            if len(self.log_lines) > self.max_log_lines:
                self.log_lines = self.log_lines[-self.max_log_lines:]
            self.log_cache = "\n".join(self.log_lines[-1200:])
            self.log_revision += 1
            self.cond.notify_all()
            payload = self.log_payload_unlocked()
        push_native_log(payload)

    def status(self):
        with self.lock:
            return self.status_unlocked()

    def log_payload(self):
        with self.lock:
            return self.log_payload_unlocked()

    def register_client(self, client_id):
        with self.lock:
            self.clients[client_id] = time.time()
            self.ever_had_client = True
            timer = self.client_shutdown_timer
            self.client_shutdown_timer = None
        if timer is not None:
            try:
                timer.cancel()
            except Exception:
                pass

    def unregister_client(self, client_id):
        with self.lock:
            self.clients.pop(client_id, None)

    def touch_client(self, client_id):
        with self.lock:
            self.clients[client_id] = time.time()
            timer = self.client_shutdown_timer
            self.client_shutdown_timer = None
        if timer is not None:
            try:
                timer.cancel()
            except Exception:
                pass

    def live_client_count(self, stale_after=6.0):
        now = time.time()
        with self.lock:
            stale = [cid for cid, ts in self.clients.items() if now - ts > stale_after]
            for cid in stale:
                self.clients.pop(cid, None)
            return len(self.clients)

STATE = RendererState()
set_native_bridge(NullNativeBridge())


def cancel_pending_client_shutdown():
    with STATE.lock:
        timer = STATE.client_shutdown_timer
        STATE.client_shutdown_timer = None
    if timer is not None:
        try:
            timer.cancel()
        except Exception:
            pass



def _clear_renderer_signal_state_unlocked():
    STATE.active_labels = []
    STATE.last_active = "(none)"
    STATE.input_levels_db = default_input_levels_db()
    STATE.input_transients_db = default_input_levels_db()
    STATE.meter_left_db = "-inf"
    STATE.meter_right_db = "-inf"
    STATE.clip_left = False
    STATE.clip_right = False
    STATE.clip_left_until = 0.0
    STATE.clip_right_until = 0.0


def _stop_reason_from_text(text):
    msg = str(text or "").strip().lower()
    if msg.startswith("renderer stopped because the selected output device was removed"):
        return "output_removed"
    if msg.startswith("renderer stopped because the selected input device was removed"):
        return "input_removed"
    if msg.startswith("renderer stopped because the selected audio device was removed"):
        return "audio_device_removed"
    if msg.startswith("core audio restarted") or "core audio service may have restarted" in msg:
        return "coreaudio_reset"
    return ""


def _selected_output_removed_text(name_or_id=""):
    display_name = str(name_or_id or "the selected output device").strip() or "the selected output device"
    display_name = re.sub(r"\s*\(unavailable\)\s*$", "", display_name, flags=re.I).strip() or "the selected output device"
    return f"Renderer stopped because the selected output device was removed: {display_name}."


def _selected_input_removed_text(name_or_id=""):
    display_name = str(name_or_id or "the selected input device").strip() or "the selected input device"
    display_name = re.sub(r"\s*\(unavailable\)\s*$", "", display_name, flags=re.I).strip() or "the selected input device"
    return f"Renderer stopped because the selected input device was removed: {display_name}."


def _normalize_unavailable_stop_text(message, input_name="", output_name="", input_device="", output_device=""):
    text = str(message or "").strip()
    if text == "Selected output device is unavailable.":
        return _selected_output_removed_text(output_name or output_device)
    if text in (
        "Selected input device is unavailable or does not expose at least 16 input channels.",
        "Selected input device is unavailable or changed before startup.",
        "Selected input device is unavailable or not ready.",
    ):
        return _selected_input_removed_text(input_name or input_device)
    return text


def _removed_device_info_from_stop_text(text):
    raw = str(text or "").strip()
    lower = raw.lower()
    if lower.startswith("renderer stopped because the selected output device was removed"):
        kind = "outdev"
    elif lower.startswith("renderer stopped because the selected input device was removed"):
        kind = "indev"
    else:
        return None
    name = ""
    if ":" in raw:
        name = raw.split(":", 1)[1].strip()
        name = re.sub(r"[.。]+$", "", name).strip()
    return {"kind": kind, "name": name}


def _enter_audio_device_quiet_window_unlocked(reason="", seconds=3.0):
    # After a hot-unplug, macOS/CoreAudio can report a device as half-present
    # for a short time. During that window, never run full input enumeration
    # from background/UI refresh paths, because PortAudio input enumeration can
    # re-enter the macOS microphone/TCC permission path.
    STATE.audio_device_quiet_until = max(STATE.audio_device_quiet_until, time.monotonic() + max(0.0, float(seconds)))
    STATE.audio_device_quiet_reason = str(reason or "audio_device_change").strip() or "audio_device_change"


def _audio_device_quiet_window_active_unlocked():
    return time.monotonic() < float(getattr(STATE, "audio_device_quiet_until", 0.0) or 0.0)


def _audio_device_quiet_window_active():
    with STATE.lock:
        return _audio_device_quiet_window_active_unlocked()


def _coreaudio_recovery_launch_prefs_available_unlocked():
    prefs = dict(STATE.preferences or {})
    input_selected = str(prefs.get("input_device", "") or prefs.get("input_device_name", "")).strip()
    output_selected = str(prefs.get("output_device", "") or prefs.get("output_device_name", "")).strip()
    return bool(input_selected and output_selected)


def _begin_controlled_renderer_stop_unlocked(stop_reason="", stop_text="Stopping renderer…", final_text="Renderer stopped."):
    # This is the single authoritative stop-intent state. Detection paths may be
    # different, but they all set this state and the process-exit handler is the
    # only place that classifies the final renderer exit.
    stop_reason = str(stop_reason or "").strip()
    final_text = str(final_text or "Renderer stopped.").strip() or "Renderer stopped."
    stop_text = str(stop_text or "Stopping renderer…").strip() or "Stopping renderer…"
    direct_stopped_reasons = ("output_removed", "input_removed", "audio_device_removed", "audio_stream_ended")
    if stop_reason == "coreaudio_reset" and _coreaudio_recovery_launch_prefs_available_unlocked():
        _enter_audio_device_quiet_window_unlocked(stop_reason, seconds=4.0)
        STATE.phase = "starting"
        STATE.status_text = final_text
    elif stop_reason in direct_stopped_reasons:
        _enter_audio_device_quiet_window_unlocked(stop_reason, seconds=4.0)
        STATE.phase = "stopped"
        STATE.status_text = final_text
    else:
        STATE.phase = "stopping"
        STATE.status_text = stop_text
    STATE.renderer_stop_requested = True
    STATE.renderer_stop_reason = stop_reason
    STATE.renderer_stop_final_text = final_text
    STATE.awaiting_live_status = False
    _clear_renderer_signal_state_unlocked()
    STATE.bump_status()
    return STATE.status_unlocked()


def _mark_output_device_removed_from_renderer_unlocked(message=""):
    display_name = STATE.running_output_device_name or STATE.running_output_device or "the selected output device"
    final_text = f"Renderer stopped because the selected output device was removed: {display_name}."
    if STATE.renderer_stop_reason == "output_removed":
        return None
    return _begin_controlled_renderer_stop_unlocked(
        stop_reason="output_removed",
        stop_text="Selected output device was removed. Stopping renderer…",
        final_text=final_text,
    )


def _mark_coreaudio_reset_from_renderer_unlocked(message=""):
    final_text = "Core Audio restarted. Reopening audio stream…"
    if STATE.renderer_stop_reason == "coreaudio_reset":
        return None
    return _begin_controlled_renderer_stop_unlocked(
        stop_reason="coreaudio_reset",
        stop_text=final_text,
        final_text=final_text,
    )
def schedule_shutdown_if_no_clients(delay=2.5, reason="Launcher page closed. Shutting down launcher."):
    cancel_pending_client_shutdown()

    def _maybe_shutdown():
        with STATE.lock:
            if STATE.shutdown_requested:
                return
        if STATE.live_client_count() == 0:
            request_shutdown(reason)

    timer = threading.Timer(delay, _maybe_shutdown)
    timer.daemon = True
    with STATE.lock:
        if STATE.shutdown_requested:
            return
        STATE.client_shutdown_timer = timer
    timer.start()


def terminate_renderer(wait_timeout=6.0):
    with STATE.lock:
        proc = STATE.proc
        proc_pgid = STATE.proc_pgid

    if proc is not None and proc.poll() is None:
        try:
            if proc_pgid is not None:
                os.killpg(proc_pgid, signal.SIGINT)
            else:
                proc.send_signal(signal.SIGINT)
            proc.wait(timeout=1.5)
        except Exception:
            try:
                if proc_pgid is not None:
                    os.killpg(proc_pgid, signal.SIGTERM)
                else:
                    proc.terminate()
                proc.wait(timeout=1.5)
            except Exception:
                try:
                    if proc_pgid is not None:
                        os.killpg(proc_pgid, signal.SIGKILL)
                    else:
                        proc.kill()
                    proc.wait(timeout=max(0.1, wait_timeout - 3.0))
                except Exception:
                    pass

    with STATE.cond:
        if STATE.proc is proc:
            STATE.proc = None
            STATE.proc_pgid = None
            STATE.reader_thread = None
        STATE.running_exe = ""
        STATE.running_input_device = ""
        STATE.running_output_device = ""
        STATE.running_input_device_name = ""
        STATE.running_output_device_name = ""
        _clear_renderer_signal_state_unlocked()
        STATE.bump_status()
        status_payload = STATE.status_unlocked()
    push_native_status(status_payload)


def signal_renderer_process_for_controlled_stop(proc, wait_timeout=3.0):
    # A Core Audio hotplug/reset marker means the current PortAudio stream is no
    # longer trustworthy.  Do not wait for the C++ process to exit on its own:
    # some Core Audio failures leave it alive while the launcher is already in
    # the Starting/Reopening state.  Signal only the process here and let
    # reader_worker() perform the authoritative state transition when stdout
    # closes, so recovery scheduling is not skipped as a stale-process exit.
    if proc is None:
        return
    with STATE.lock:
        if STATE.proc is not proc:
            return
        proc_pgid = STATE.proc_pgid
    if proc.poll() is not None:
        return

    remaining = max(0.5, float(wait_timeout))
    steps = (
        ("interrupt", 0.8),
        ("terminate", 0.8),
        ("kill", max(0.2, remaining - 1.6)),
    )
    for action, timeout in steps:
        if proc.poll() is not None:
            return
        try:
            if action == "interrupt":
                if proc_pgid is not None:
                    os.killpg(proc_pgid, signal.SIGINT)
                else:
                    proc.send_signal(signal.SIGINT)
            elif action == "terminate":
                if proc_pgid is not None:
                    os.killpg(proc_pgid, signal.SIGTERM)
                else:
                    proc.terminate()
            else:
                if proc_pgid is not None:
                    os.killpg(proc_pgid, signal.SIGKILL)
                else:
                    proc.kill()
            proc.wait(timeout=max(0.1, timeout))
            return
        except Exception:
            continue


def _output_keepalive_start_blocked_unlocked():
    phase = str(STATE.phase or "")
    # Keep-alive is intentionally allowed to run at the same time as the real
    # renderer. It writes digital silence only, so it must not be treated as an
    # idle-only stream or blocked by the renderer being starting/running/stopping.
    return bool(STATE.shutdown_requested or phase == "disconnected")


def _output_keepalive_start_blocked():
    with STATE.lock:
        return _output_keepalive_start_blocked_unlocked()


def terminate_keepalive(wait_timeout=3.0):
    with STATE.lock:
        proc = STATE.keepalive_proc
        proc_pgid = STATE.keepalive_proc_pgid
        STATE.keepalive_stop_requested = True
        STATE.keepalive_restart_pending = False

    if proc is not None and proc.poll() is None:
        try:
            if proc_pgid is not None:
                os.killpg(proc_pgid, signal.SIGINT)
            else:
                proc.send_signal(signal.SIGINT)
            proc.wait(timeout=1.0)
        except Exception:
            try:
                if proc_pgid is not None:
                    os.killpg(proc_pgid, signal.SIGTERM)
                else:
                    proc.terminate()
                proc.wait(timeout=1.0)
            except Exception:
                try:
                    if proc_pgid is not None:
                        os.killpg(proc_pgid, signal.SIGKILL)
                    else:
                        proc.kill()
                    proc.wait(timeout=max(0.1, wait_timeout - 2.0))
                except Exception:
                    pass

    with STATE.lock:
        if STATE.keepalive_proc is proc:
            STATE.keepalive_proc = None
            STATE.keepalive_proc_pgid = None
            STATE.keepalive_reader_thread = None
            STATE.keepalive_exe = ""
            STATE.keepalive_output_device = ""
            STATE.keepalive_output_device_name = ""
        STATE.keepalive_stop_requested = False
        STATE.keepalive_restart_pending = False


def keepalive_reader_worker(proc):
    stream = proc.stdout
    buffer = ""
    proc_pid = getattr(proc, "pid", None)
    try:
        if stream is not None:
            while True:
                chunk = os.read(stream.fileno(), 4096)
                if not chunk:
                    break
                buffer += chunk.decode("utf-8", errors="replace")
                parts = re.split(r"\r|\n", buffer)
                buffer = parts.pop() if parts else ""
                for line in parts:
                    line = line.strip()
                    if line:
                        STATE.append_log(f"Keep-alive: {line}")
    except Exception as exc:
        STATE.append_log(f"Keep-alive reader error: {exc}")
    rc = proc.wait()
    stale = False
    with STATE.lock:
        stale = STATE.keepalive_proc is not proc
        stop_requested = STATE.keepalive_stop_requested or STATE.shutdown_requested
        if not stale:
            STATE.keepalive_proc = None
            STATE.keepalive_proc_pgid = None
            STATE.keepalive_reader_thread = None
            STATE.keepalive_exe = ""
            STATE.keepalive_output_device = ""
            STATE.keepalive_output_device_name = ""
            STATE.keepalive_stop_requested = False
            STATE.keepalive_restart_pending = False
    if stale:
        STATE.append_log(f"Ignored exit from stale output keep-alive process {proc_pid} with code {rc}.")
    elif stop_requested:
        STATE.append_log(f"Output keep-alive stopped with code {rc}.")
    else:
        STATE.append_log(f"Output keep-alive exited with code {rc}.")


def renderer_startup_watchdog(proc, timeout_seconds=RENDERER_STARTUP_TIMEOUT_SECONDS):
    try:
        time.sleep(max(0.5, float(timeout_seconds)))
        should_stop = False
        status_payload = None
        with STATE.cond:
            if (STATE.proc is proc and
                    STATE.phase == "starting" and
                    STATE.awaiting_live_status and
                    not STATE.shutdown_requested and
                    proc.poll() is None):
                recovery_pending = bool(STATE.renderer_recovery_pending)
                STATE.renderer_stop_requested = True
                STATE.renderer_stop_reason = "startup_timeout"
                if recovery_pending:
                    STATE.renderer_stop_final_text = (
                        "Core Audio recovery attempt timed out while reopening the audio stream. Retrying…"
                    )
                    STATE.phase = "starting"
                else:
                    STATE.renderer_stop_final_text = (
                        "Renderer stopped because it did not become live. "
                        "The selected audio device may still be reconnecting. Wait a moment and press Start again."
                    )
                    STATE.phase = "stopped"
                    STATE.renderer_recovery_pending = False
                STATE.status_text = STATE.renderer_stop_final_text
                STATE.awaiting_live_status = False
                STATE.renderer_seen_live = False
                _clear_renderer_signal_state_unlocked()
                STATE.bump_status()
                status_payload = STATE.status_unlocked()
                should_stop = True
        if status_payload is not None:
            push_native_status(status_payload)
        if should_stop:
            STATE.append_log("Renderer startup timed out before the stream became live. Terminating startup process.")
            terminate_renderer(wait_timeout=1.5)
    except Exception as exc:
        STATE.append_log(f"Renderer startup watchdog error: {exc}")


def _selected_output_device(exe, output_device, output_device_name="", deadline_seconds=0.0):
    selected_output = None
    first_attempt = True
    deadline = time.time() + max(0.0, float(deadline_seconds))
    while first_attempt or time.time() < deadline:
        first_attempt = False
        outputs = list_output_devices(exe)
        with STATE.lock:
            _record_device_inventory_unlocked(outputs=outputs, input_enumerated=False)
        selected_output = _match_device(outputs, output_device, output_device_name)
        if selected_output is not None:
            return selected_output
        if time.time() >= deadline:
            break
        time.sleep(0.2)
    return None


def _recent_log_tail_text(max_lines=30):
    with STATE.lock:
        return "\n".join(STATE.log_lines[-max_lines:])


def _startup_failure_message(rc, exe, input_device, output_device, input_device_name="", output_device_name=""):
    # Give the reader thread a brief chance to append the renderer's actual
    # PortAudio/Core Audio error line before the verifier classifies the early
    # exit. Without this, users see the unhelpful generic code-1 message.
    time.sleep(0.12)
    tail = _recent_log_tail_text()
    lower_tail = tail.lower()
    if "selected output device is unavailable" in lower_tail:
        return "Selected output device is unavailable."
    if "selected input device is unavailable or changed before startup" in lower_tail:
        return "Selected input device is unavailable or changed before startup."
    output_error_markers = (
        "pa_openstream failed",
        "pa_startstream failed",
        "output stream became inactive",
        "core audio output device was removed",
        "output device was probably removed",
        "requested output",
        "output keep-alive",
        "invalid output device",
    )
    if any(marker in lower_tail for marker in output_error_markers):
        try:
            output_ok = _selected_output_still_available(exe, output_device=output_device, output_device_name=output_device_name)
        except Exception:
            output_ok = True
        if output_ok:
            return "Renderer failed to start because Core Audio rejected the selected output device during startup. Re-select the output device and start again."
        return "Selected output device is unavailable."
    input_error_markers = (
        "invalid input device",
        "requested input",
        "input stream",
        "could not query device info",
    )
    if any(marker in lower_tail for marker in input_error_markers):
        return "Selected input device is unavailable or not ready."
    if rc == 1:
        return "Renderer could not start because Core Audio/PortAudio rejected the selected device during startup. Check the log for the detailed PortAudio error."
    return f"Renderer exited with code {rc}."


def ensure_output_keepalive(data=None, resolve_deadline_seconds=0.0, log_errors=False):
    if _output_keepalive_start_blocked():
        return False

    data = dict(data or STATE.preferences)
    if not bool_value(data.get("keep_output_alive", True), default=True):
        terminate_keepalive(wait_timeout=1.5)
        return False

    exe = str(data.get("exe", DEFAULT_PREFS["exe"])).strip()
    output_device = str(data.get("output_device", "")).strip()
    output_device_name = str(data.get("output_device_name", "")).strip()
    if not exe or not os.path.exists(exe) or not (output_device or output_device_name):
        terminate_keepalive(wait_timeout=1.5)
        return False

    try:
        selected_output = _selected_output_device(
            exe,
            output_device=output_device,
            output_device_name=output_device_name,
            deadline_seconds=resolve_deadline_seconds,
        )
    except Exception as exc:
        if log_errors:
            STATE.append_log(f"Could not refresh devices for output keep-alive: {exc}")
        return False

    if selected_output is None:
        terminate_keepalive(wait_timeout=1.5)
        if log_errors:
            STATE.append_log("Output keep-alive not started because the selected output device is unavailable.")
        return False

    output_device = str(selected_output["index"])
    output_device_name = str(selected_output.get("name", ""))

    with STATE.lock:
        proc = STATE.keepalive_proc
        already_running = proc is not None and proc.poll() is None
        if (already_running and
                STATE.keepalive_exe == exe and
                STATE.keepalive_output_device == output_device and
                STATE.keepalive_output_device_name == output_device_name):
            return True

    terminate_keepalive(wait_timeout=1.5)

    frames = str(data.get("frames", DEFAULT_PREFS.get("frames", "64"))).strip() or "64"
    output_latency_text = str(data.get("output_latency_ms", DEFAULT_PREFS.get("output_latency_ms", "10"))).strip()
    cmd = [
        exe,
        "--keep-output-alive",
        "--output-device", output_device,
    ]
    cmd.extend([
        "--frames-per-buffer", str(int(float(frames))),
    ])
    if output_latency_text != "":
        try:
            output_latency_ms = float(output_latency_text)
            if output_latency_ms < 0:
                output_latency_ms = 0.0
            if output_latency_ms > 250:
                output_latency_ms = 250.0
            cmd.extend(["--output-latency-ms", f"{output_latency_ms:g}"])
        except Exception:
            cmd.extend(["--output-latency-ms", DEFAULT_PREFS.get("output_latency_ms", "10")])

    # Re-check immediately before opening the silent stream. There is no timed
    # suppression here, and the real renderer being live is not a blocker.
    if _output_keepalive_start_blocked():
        return False

    try:
        proc = subprocess.Popen(cmd, stdout=subprocess.PIPE, stderr=subprocess.STDOUT, bufsize=0, start_new_session=True)
    except Exception as exc:
        if log_errors:
            STATE.append_log(f"Could not start output keep-alive: {exc}")
        return False

    reader = threading.Thread(target=keepalive_reader_worker, args=(proc,), daemon=True)
    with STATE.lock:
        STATE.keepalive_proc = proc
        try:
            STATE.keepalive_proc_pgid = os.getpgid(proc.pid)
        except Exception:
            STATE.keepalive_proc_pgid = None
        STATE.keepalive_reader_thread = reader
        STATE.keepalive_stop_requested = False
        STATE.keepalive_exe = exe
        STATE.keepalive_output_device = output_device
        STATE.keepalive_output_device_name = output_device_name
    STATE.append_log(f"Starting output keep-alive on {output_device_name or output_device}.")
    STATE.append_log(" ".join(cmd))
    reader.start()
    return True


def ensure_output_keepalive_from_preferences_async(delay=0.05, log_errors=False):
    with STATE.lock:
        if STATE.shutdown_requested or STATE.keepalive_restart_pending:
            return
        STATE.keepalive_restart_pending = True

    def _worker():
        try:
            if delay > 0:
                time.sleep(delay)
            with STATE.lock:
                if _output_keepalive_start_blocked_unlocked():
                    return
                prefs = dict(STATE.preferences)
            ensure_output_keepalive(prefs, resolve_deadline_seconds=0.25, log_errors=log_errors)
        finally:
            with STATE.lock:
                STATE.keepalive_restart_pending = False
    threading.Thread(target=_worker, daemon=True).start()


def maybe_resume_keepalive_after_output_inventory(outputs=None, delay=0.05, log_errors=False):
    # A hot-unplug intentionally stops the keep-alive stream. When the same
    # selected output later reappears, a normal output-only inventory refresh must
    # be enough to resume keep-alive; otherwise the device can sit visible in the
    # UI but asleep until the user toggles settings or restarts the app. This path
    # never enumerates inputs, and keep-alive may run in parallel with the real
    # renderer.
    with STATE.lock:
        if STATE.shutdown_requested:
            return False
        phase = str(STATE.phase or '')
        prefs = dict(STATE.preferences)
        keep_proc = STATE.keepalive_proc
        keep_running = keep_proc is not None and keep_proc.poll() is None
        keep_exe = STATE.keepalive_exe
        keep_output_device = STATE.keepalive_output_device
        keep_output_device_name = STATE.keepalive_output_device_name

    if phase == 'disconnected':
        return False
    if not bool_value(prefs.get('keep_output_alive', True), default=True):
        if keep_running:
            terminate_keepalive(wait_timeout=1.0)
        return False

    exe = str(prefs.get('exe', DEFAULT_PREFS['exe'])).strip()
    output_device = str(prefs.get('output_device', '') or '').strip()
    output_device_name = str(prefs.get('output_device_name', '') or '').strip()
    if not exe or not os.path.exists(exe) or not (output_device or output_device_name):
        return False

    selected_output = None
    if outputs is not None:
        try:
            selected_output = _match_device(list(outputs), output_device, output_device_name)
        except Exception:
            selected_output = None
        if selected_output is None:
            if keep_running:
                terminate_keepalive(wait_timeout=1.0)
            return False

    if selected_output is not None:
        current_output_device = str(selected_output.get('index', output_device))
        current_output_name = str(selected_output.get('name', output_device_name) or '')
        if (keep_running and keep_exe == exe and
                keep_output_device == current_output_device and
                keep_output_device_name == current_output_name):
            return True
        prefs = dict(prefs)
        prefs['output_device'] = current_output_device
        prefs['output_device_name'] = current_output_name
    elif keep_running:
        return True

    with STATE.lock:
        if STATE.shutdown_requested or STATE.keepalive_restart_pending:
            return False
        STATE.keepalive_restart_pending = True

    def _worker():
        try:
            if delay > 0:
                time.sleep(delay)
            with STATE.lock:
                if _output_keepalive_start_blocked_unlocked():
                    return
            ensure_output_keepalive(prefs, resolve_deadline_seconds=0.0 if selected_output is not None else 0.25, log_errors=log_errors)
        finally:
            with STATE.lock:
                STATE.keepalive_restart_pending = False
    threading.Thread(target=_worker, daemon=True).start()
    return True


def request_shutdown(reason=""):
    cancel_pending_client_shutdown()
    with STATE.cond:
        if STATE.shutdown_requested:
            return
        STATE.shutdown_requested = True
        STATE.phase = "disconnected"
        STATE.status_text = "Launcher is shutting down."
        STATE.bump_status()
        status_payload = STATE.status_unlocked()
    push_native_status(status_payload)
    if reason:
        STATE.append_log(reason)
    terminate_renderer()
    terminate_keepalive()
    server = STATE.server
    if server is not None:
        threading.Thread(target=server.shutdown, daemon=True).start()

def client_watchdog():
    # Intentionally disabled. The earlier heartbeat-based auto-shutdown could
    # incorrectly terminate the launcher when the browser throttled timers,
    # the tab went into the background, or the machine briefly slept.
    # Explicit page-close notifications still shut the launcher down.
    while True:
        time.sleep(1.0)
        with STATE.lock:
            if STATE.shutdown_requested:
                return

def _parse_device_listing(stdout):
    inputs, outputs = [], []
    for line in stdout.splitlines():
        m = DEVICE_RE.match(line.strip())
        if not m:
            continue
        idx, name, ins, outs = m.groups()
        item = {
            "index": int(idx),
            "name": name.strip(),
            "inputs": int(ins),
            "outputs": int(outs),
            "compatible": int(ins) >= 16,
        }
        if item["inputs"] > 0:
            inputs.append(item)
        if item["outputs"] > 0:
            outputs.append(item)
    return inputs, outputs



def _device_inventory_signature(inputs, outputs):
    def norm(items):
        out = []
        for item in items or []:
            try:
                out.append((
                    int(item.get("index", -1)),
                    str(item.get("name", "")),
                    int(item.get("inputs", 0)),
                    int(item.get("outputs", 0)),
                ))
            except Exception:
                continue
        return sorted(out)
    return json.dumps({"inputs": norm(inputs), "outputs": norm(outputs)}, sort_keys=True, separators=(",", ":"))


def _record_device_inventory_unlocked(inputs=None, outputs=None, input_enumerated=False):
    next_inputs = list(STATE.cached_inputs if inputs is None else inputs)
    next_outputs = list(STATE.cached_outputs if outputs is None else outputs)
    next_sig = _device_inventory_signature(next_inputs, next_outputs)
    now = time.monotonic()
    if STATE.device_inventory_signature != next_sig:
        STATE.device_inventory_signature = next_sig
        STATE.device_topology_changed_at = now
    if inputs is not None:
        STATE.cached_inputs = list(inputs)
    if outputs is not None:
        STATE.cached_outputs = list(outputs)
    if input_enumerated:
        STATE.last_full_device_scan_at = now


def _start_readiness_reason_unlocked(input_device="", input_device_name="", output_device="", output_device_name="", allow_recovery_launch=False):
    phase = str(STATE.phase or "")
    if STATE.renderer_recovery_pending and not allow_recovery_launch:
        return "Renderer is restarting."
    if phase in ("starting", "running", "stopping", "disconnected"):
        # Automatic Core Audio recovery deliberately holds the UI in the
        # Starting state before the replacement renderer process exists.  The
        # recovery worker itself must be allowed through this readiness check;
        # ordinary user/API starts remain blocked while recovery is pending.
        if not (allow_recovery_launch and STATE.renderer_recovery_pending and phase == "starting"):
            return "Renderer state is not idle."
    # Do not block Start behind an artificial stability/settling window. If the
    # selected output is currently visible, the user should be able to press
    # Start. The launch path below still resolves the devices again immediately
    # before starting the renderer, so a real hot-unplug race reports a real
    # unavailable-device error instead of leaving the UI stuck.
    selected_input = _match_device(STATE.cached_inputs, input_device, input_device_name)
    selected_output = _match_device(STATE.cached_outputs, output_device, output_device_name)
    if selected_input is None:
        return "Selected input device is unavailable or does not expose at least 16 input channels."
    if selected_output is None:
        return "Selected output device is unavailable."
    if not _output_device_is_stereo_compatible(selected_output):
        return f"Selected output device must expose 1 or 2 output channels; {selected_output.get('name', 'it')} exposes {_output_channel_count_text(selected_output)}."
    return ""


def _start_readiness_payload_unlocked(input_device="", input_device_name="", output_device="", output_device_name="", allow_recovery_launch=False):
    reason = _start_readiness_reason_unlocked(input_device, input_device_name, output_device, output_device_name, allow_recovery_launch=allow_recovery_launch)
    return {
        "start_ready": not bool(reason),
        "start_not_ready_reason": reason,
        "start_device_stable_ms": int(START_DEVICE_STABLE_SECONDS * 1000),
        "last_full_device_scan_age_ms": int(max(0.0, time.monotonic() - STATE.last_full_device_scan_at) * 1000) if STATE.last_full_device_scan_at else None,
    }

def _run_renderer_device_query(cmd, label):
    try:
        proc = subprocess.run(
            cmd,
            capture_output=True,
            text=True,
            check=True,
            timeout=DEVICE_ENUMERATION_TIMEOUT_SECONDS,
        )
        return proc.stdout
    except subprocess.TimeoutExpired as exc:
        raise TransientAudioDeviceError(
            f"{label} timed out while macOS was reconnecting audio devices. Wait a moment and press Start again."
        ) from exc


def list_devices(exe_path):
    stdout = _run_renderer_device_query([exe_path, "--list-devices"], "Audio device scan")
    return _parse_device_listing(stdout)


def list_output_devices(exe_path):
    # Deliberately output-only. Falling back to --list-devices can touch the
    # macOS input/TCC path, which is exactly what caused microphone permission
    # prompt loops after an output hot-unplug or after the UI window closed.
    # The bundled helper in this build supports --list-output-devices. If an
    # older helper is accidentally selected, fail closed and let callers use
    # cached output devices rather than probing inputs.
    stdout = _run_renderer_device_query([exe_path, "--list-output-devices"], "Output device scan")
    _inputs, outputs = _parse_device_listing(stdout)
    return outputs

def update_runtime_status_from_line(line):
    if line.strip() == "Renderer stream started.":
        with STATE.cond:
            if STATE.renderer_stop_requested or STATE.phase in ("stopping", "stopped", "error", "disconnected"):
                return True
            STATE.renderer_seen_live = True
            if STATE.phase == "starting" and STATE.awaiting_live_status:
                STATE.phase = "running"
                STATE.status_text = "Stereo renderer is running."
                STATE.awaiting_live_status = False
                STATE.renderer_recovery_pending = False
                STATE.bump_status()
                status_payload = STATE.status_unlocked()
            else:
                status_payload = None
        if status_payload is not None:
            push_native_status(status_payload)
        return True
    m = STATUS_RE.search(line)
    if not m:
        return False
    active_text, levels_text, meter_l, meter_r, clip_l, clip_r, transients_text = m.groups()
    active_labels = ACTIVE_ITEM_RE.findall(active_text) if active_text and active_text != "(none)" else []
    input_levels_db = parse_input_levels_db(levels_text)
    input_transients_db = parse_input_levels_db(transients_text)
    with STATE.cond:
        if STATE.renderer_stop_requested or STATE.phase in ("stopping", "stopped", "error", "disconnected"):
            return True
        STATE.renderer_seen_live = True
        STATE.active_labels = active_labels
        STATE.last_active = active_text.strip() or "(none)"
        STATE.input_levels_db = input_levels_db
        STATE.input_transients_db = input_transients_db
        STATE.meter_left_db = meter_l
        STATE.meter_right_db = meter_r
        now = time.monotonic()
        STATE.clip_left = (clip_l == "1")
        STATE.clip_right = (clip_r == "1")
        if STATE.clip_left:
            STATE.clip_left_until = now + CLIP_INDICATOR_LATCH_SECONDS
        if STATE.clip_right:
            STATE.clip_right_until = now + CLIP_INDICATOR_LATCH_SECONDS
        if STATE.phase == "starting" and STATE.awaiting_live_status:
            STATE.phase = "running"
            STATE.status_text = "Stereo renderer is running."
            STATE.awaiting_live_status = False
            STATE.renderer_recovery_pending = False
        STATE.bump_status()
        status_payload = STATE.status_unlocked()
    push_native_status(status_payload)
    return True


def _renderer_coreaudio_recover_marker(text):
    lower = str(text or "").lower()
    return any(marker in lower for marker in (
        "core audio service may have restarted",
        "audio stream callback stalled",
        "audio stream became inactive",
        "pa_isstreamactive failed",
        "stream became inactive",
    ))


def _renderer_output_removed_marker(text):
    lower = str(text or "").lower()
    return any(marker in lower for marker in (
        "core audio output device was removed",
        "selected output device was probably removed",
        "output device was removed",
    ))


def _runtime_failure_is_controlled_stop(rc, seen_live, tail_text):
    # Startup failures are still errors. Once the renderer has reported a live
    # stream, a non-zero exit from the PortAudio/Core Audio monitor path is a
    # runtime stream stop, not a launch failure. This prevents a stale, generic
    # "Renderer exited with code 1" from flashing when an output disconnect is
    # detected by the renderer before the UI/watchdog path sees the hot-unplug.
    if not seen_live or rc == 0:
        return (False, "")
    if _renderer_coreaudio_recover_marker(tail_text):
        return (True, "coreaudio_reset")
    if _renderer_output_removed_marker(tail_text):
        return (True, "output_removed")
    lower = str(tail_text or "").lower()
    if "selected input device" in lower or "input stream" in lower:
        return (True, "input_removed")
    # The C++ renderer returns code 1 for exceptions from the live audio stream.
    # After the stream has been live, do not surface this as a startup error.
    if rc == 1:
        return (True, "audio_stream_ended")
    return (False, "")

def _schedule_coreaudio_renderer_recovery(reason="", delay=0.35, max_attempts=4):
    with STATE.cond:
        if STATE.shutdown_requested or STATE.renderer_recovery_pending:
            return False
        if not _coreaudio_recovery_launch_prefs_available_unlocked():
            return False
        STATE.renderer_recovery_pending = True
        STATE.renderer_recovery_cancel_requested = False
        STATE.phase = "starting"
        STATE.status_text = "Core Audio restarted. Reopening audio stream…"
        STATE.bump_status()
        status_payload = STATE.status_unlocked()
    push_native_status(status_payload)
    STATE.append_log("Core Audio restart detected. Reopening renderer when the selected devices are ready.")

    def _worker():
        final_message = "Core Audio restarted, but the selected audio devices did not become ready. Press Start after they reappear."
        recovery_deadline = time.monotonic() + COREAUDIO_RECOVERY_TOTAL_TIMEOUT_SECONDS
        try:
            # Any existing keep-alive stream was opened against the old Core Audio
            # service instance. Close it before reopening the duplex renderer.
            terminate_keepalive(wait_timeout=0.8)
            for attempt in range(max(1, int(max_attempts))):
                remaining_total = recovery_deadline - time.monotonic()
                if remaining_total <= 0:
                    break
                sleep_time = max(0.0, float(delay)) if attempt == 0 else min(1.25, 0.25 + 0.15 * attempt)
                sleep_time = min(sleep_time, max(0.0, remaining_total))
                if sleep_time > 0:
                    time.sleep(sleep_time)
                with STATE.lock:
                    if STATE.shutdown_requested or STATE.renderer_recovery_cancel_requested:
                        return
                    current_proc = STATE.proc
                    prefs = dict(STATE.preferences)
                if current_proc is not None and current_proc.poll() is None:
                    wait_budget = min(2.0, max(0.1, recovery_deadline - time.monotonic()))
                    if _wait_for_renderer_live_or_exit(current_proc, timeout_seconds=wait_budget):
                        return
                    STATE.append_log("Core Audio recovery found a stale renderer that never became live. Terminating it before retrying.")
                    signal_renderer_process_for_controlled_stop(current_proc, wait_timeout=1.5)
                    continue

                try:
                    with STATE.lifecycle_lock:
                        stale_proc = None
                        with STATE.lock:
                            if STATE.shutdown_requested or STATE.renderer_recovery_cancel_requested:
                                return
                            current_proc = STATE.proc
                            if current_proc is not None and current_proc.poll() is None:
                                stale_proc = current_proc
                                launch_data = None
                            else:
                                launch_data = dict(STATE.preferences)
                        if stale_proc is not None:
                            signal_renderer_process_for_controlled_stop(stale_proc, wait_timeout=1.5)
                            raise TransientAudioDeviceError("Stale renderer is still exiting after Core Audio reset.")
                        launch_resolve_budget = min(0.75, max(0.0, recovery_deadline - time.monotonic()))
                        if launch_resolve_budget <= 0:
                            raise TransientAudioDeviceError("Core Audio recovery timed out before relaunch.")
                        result = _launch_renderer_locked(
                            launch_data,
                            action_text="Core Audio restarted. Reopening audio stream…",
                            resolve_deadline_seconds=launch_resolve_budget,
                            publish_wait_status=False,
                            allow_recovery_launch=True,
                            clear_recovery_pending_on_launch=False,
                        )
                        with STATE.lock:
                            prefs = dict(STATE.preferences)
                            prefs.update(result.get("data", launch_data))
                            STATE.preferences = save_preferences(prefs)
                            launched_proc = STATE.proc
                    live_wait_budget = min(4.5, max(0.5, recovery_deadline - time.monotonic()))
                    if _wait_for_renderer_live_or_exit(launched_proc, timeout_seconds=live_wait_budget):
                        STATE.append_log("Renderer relaunched after Core Audio restart.")
                        return
                    with STATE.lock:
                        if STATE.shutdown_requested or STATE.renderer_recovery_cancel_requested:
                            return
                    with STATE.cond:
                        if STATE.proc is launched_proc and launched_proc is not None and launched_proc.poll() is None:
                            status_payload = _mark_recovery_attempt_timeout_unlocked()
                        else:
                            status_payload = None
                    if status_payload is not None:
                        push_native_status(status_payload)
                        STATE.append_log("Core Audio recovery attempt launched a renderer, but the stream never became live. Terminating and retrying.")
                        terminate_renderer(wait_timeout=1.5)
                    raise TransientAudioDeviceError("Renderer did not become live after Core Audio recovery launch.")
                except Exception as exc:
                    with STATE.lock:
                        if STATE.shutdown_requested or STATE.renderer_recovery_cancel_requested:
                            return
                    message = str(exc)
                    lower = message.lower()
                    transient = (
                        isinstance(exc, TransientAudioDeviceError)
                        or "unavailable" in lower
                        or "not ready" in lower
                        or "timed out" in lower
                        or "core audio" in lower
                        or "portaudio" in lower
                        or "reconnecting" in lower
                    )
                    if attempt in (0, 3, 7, 12) or not transient:
                        STATE.append_log(f"Core Audio recovery attempt {attempt + 1} failed: {message}")
                    if not transient:
                        final_message = f"Core Audio recovery failed: {message}"
                        break
            with STATE.cond:
                if STATE.renderer_recovery_cancel_requested:
                    return
                if not STATE.shutdown_requested:
                    current_proc = STATE.proc
                    if current_proc is None or current_proc.poll() is not None:
                        STATE.phase = "stopped"
                        STATE.status_text = final_message
                        STATE.renderer_stop_requested = False
                        STATE.renderer_stop_reason = ""
                        STATE.renderer_stop_final_text = ""
                        STATE.renderer_seen_live = False
                        STATE.awaiting_live_status = False
                        _clear_renderer_signal_state_unlocked()
                        STATE.bump_status()
                        status_payload = STATE.status_unlocked()
                    else:
                        status_payload = None
                else:
                    status_payload = None
            if status_payload is not None:
                push_native_status(status_payload)
        finally:
            status_payload = None
            with STATE.cond:
                current_proc = STATE.proc
                recovery_launch_still_starting = (
                    current_proc is not None
                    and current_proc.poll() is None
                    and str(STATE.phase or "") == "starting"
                    and bool(STATE.awaiting_live_status)
                )
                if STATE.renderer_recovery_pending and not recovery_launch_still_starting:
                    STATE.renderer_recovery_pending = False
                    STATE.bump_status()
                    status_payload = STATE.status_unlocked()
            if status_payload is not None:
                push_native_status(status_payload)

    threading.Thread(target=_worker, daemon=True).start()
    return True


def reader_worker(proc):
    stream = proc.stdout
    if stream is None:
        return
    buffer = ""
    proc_pid = getattr(proc, "pid", None)

    def handle_renderer_line(line):
        plain_line = line.strip()
        controlled_stop_detected = False
        if _renderer_coreaudio_recover_marker(plain_line):
            with STATE.cond:
                status_payload = _mark_coreaudio_reset_from_renderer_unlocked(plain_line)
            if status_payload is not None:
                push_native_status(status_payload)
                controlled_stop_detected = True
        elif _renderer_output_removed_marker(plain_line):
            with STATE.cond:
                status_payload = _mark_output_device_removed_from_renderer_unlocked(plain_line)
            if status_payload is not None:
                push_native_status(status_payload)
                controlled_stop_detected = True
        if controlled_stop_detected:
            # Do not let a dead Core Audio stream keep the process alive while
            # the UI says it is reopening.  The reader thread will schedule the
            # appropriate stopped/recovery state when the process exits.
            threading.Thread(
                target=signal_renderer_process_for_controlled_stop,
                args=(proc,),
                kwargs={"wait_timeout": 3.0},
                daemon=True,
            ).start()
        if update_runtime_status_from_line(line):
            return
        STATE.append_log(line)

    try:
        while True:
            chunk = os.read(stream.fileno(), 4096)
            if not chunk:
                break
            buffer += chunk.decode("utf-8", errors="replace")
            parts = re.split(r"\r|\n", buffer)
            buffer = parts.pop() if parts else ""
            for line in parts:
                handle_renderer_line(line)
        if buffer.strip():
            for line in re.split(r"\r|\n", buffer):
                if line.strip():
                    handle_renderer_line(line)
    except Exception as exc:
        STATE.append_log(f"Reader error: {exc}")
    rc = proc.wait()
    status_payload = None
    current_proc_exited = False
    schedule_recovery = False
    recovery_reason = ""
    with STATE.cond:
        current_proc_exited = (STATE.proc is proc)
        if current_proc_exited:
            exited_running_exe = STATE.running_exe
            exited_running_input_device = STATE.running_input_device
            exited_running_output_device = STATE.running_output_device
            exited_running_input_device_name = STATE.running_input_device_name
            exited_running_output_device_name = STATE.running_output_device_name
            STATE.proc = None
            STATE.proc_pgid = None
            STATE.reader_thread = None
            STATE.running_exe = ""
            STATE.running_input_device = ""
            STATE.running_output_device = ""
            STATE.running_input_device_name = ""
            STATE.running_output_device_name = ""
            STATE.awaiting_live_status = False
            stop_requested = STATE.renderer_stop_requested
            stop_reason = str(STATE.renderer_stop_reason or "").strip()
            stop_final_text = str(STATE.renderer_stop_final_text or "").strip()
            seen_live = bool(STATE.renderer_seen_live)
            log_tail_text = "\n".join(STATE.log_lines[-40:])
            runtime_stop, runtime_stop_reason = _runtime_failure_is_controlled_stop(rc, seen_live, log_tail_text)
            STATE.renderer_stop_requested = False
            STATE.renderer_stop_reason = ""
            STATE.renderer_stop_final_text = ""
            STATE.renderer_seen_live = False
            if STATE.shutdown_requested:
                STATE.phase = "disconnected"
                STATE.status_text = "Launcher is shutting down."
            elif stop_reason:
                if stop_reason == "coreaudio_reset" and _coreaudio_recovery_launch_prefs_available_unlocked():
                    STATE.phase = "starting"
                else:
                    STATE.phase = "stopped"
                STATE.status_text = stop_final_text or "Renderer stopped."
                if stop_reason == "coreaudio_reset":
                    schedule_recovery = True
                    recovery_reason = stop_reason
            elif stop_requested or rc == 0:
                STATE.phase = "stopped"
                STATE.status_text = "Renderer stopped."
            elif runtime_stop:
                if runtime_stop_reason in ("output_removed", "input_removed", "audio_device_removed"):
                    _enter_audio_device_quiet_window_unlocked(runtime_stop_reason, seconds=4.0)
                if runtime_stop_reason == "coreaudio_reset" and _coreaudio_recovery_launch_prefs_available_unlocked():
                    STATE.phase = "starting"
                else:
                    STATE.phase = "stopped"
                if runtime_stop_reason == "coreaudio_reset":
                    STATE.status_text = "Core Audio restarted. Reopening audio stream…"
                    schedule_recovery = True
                    recovery_reason = runtime_stop_reason
                elif runtime_stop_reason == "output_removed":
                    display_name = exited_running_output_device_name or exited_running_output_device or "the selected output device"
                    STATE.status_text = f"Renderer stopped because the selected output device was removed: {display_name}."
                elif runtime_stop_reason == "input_removed":
                    display_name = exited_running_input_device_name or exited_running_input_device or "the selected input device"
                    STATE.status_text = f"Renderer stopped because the selected input device was removed: {display_name}."
                else:
                    STATE.status_text = "Renderer stopped because the live audio stream ended."
            else:
                preserved_text = str(STATE.status_text or "").strip()
                inferred_text = ""
                try:
                    devices_exe = exited_running_exe or STATE.preferences.get("exe", DEFAULT_PREFS["exe"])
                    devices_output = str(exited_running_output_device or STATE.preferences.get("output_device", "") or "").strip()
                    devices_output_name = str(exited_running_output_device_name or STATE.preferences.get("output_device_name", "") or "").strip()
                    outputs = list_output_devices(devices_exe)
                    _record_device_inventory_unlocked(outputs=outputs, input_enumerated=False)
                    matched_output = _match_device(outputs, devices_output, devices_output_name)
                    if matched_output is None:
                        inferred_text = _selected_output_removed_text(devices_output_name or devices_output)
                    # Do not call list_devices() here. This is an asynchronous
                    # renderer-exit path, and full input enumeration can re-enter
                    # the macOS microphone/TCC path after output removal.
                except Exception:
                    inferred_text = ""

                ignored_status_texts = (
                    "Stereo renderer is running.",
                    "Launching stereo renderer…",
                    "Restarting renderer with updated settings…",
                    "Starting renderer with applied settings…",
                    "Applying changes and restarting renderer…",
                    "Stopping renderer…",
                    "Selected output device was removed. Stopping renderer…",
                    "Selected audio device was removed. Stopping renderer…",
                    "Core Audio restarted. Reopening audio stream…",
                )
                if preserved_text and preserved_text not in ignored_status_texts:
                    final_exit_text = preserved_text
                elif inferred_text:
                    final_exit_text = inferred_text
                else:
                    final_exit_text = _startup_failure_message(rc, exited_running_exe, exited_running_input_device, exited_running_output_device, exited_running_input_device_name, exited_running_output_device_name)

                # A missing selected device during a start/disconnect race is an idle
                # stopped state, not a renderer fault. This is the central backend
                # classification so the UI no longer depends on masking an Error pill.
                normalized_exit_text = _normalize_unavailable_stop_text(
                    final_exit_text,
                    input_name=exited_running_input_device_name,
                    output_name=exited_running_output_device_name,
                    input_device=exited_running_input_device,
                    output_device=exited_running_output_device,
                )
                if normalized_exit_text != final_exit_text:
                    final_exit_text = normalized_exit_text
                final_stop_reason = _stop_reason_from_text(final_exit_text)
                if final_exit_text in (
                    "Select both an input device and an output device.",
                ) or final_stop_reason or final_exit_text.startswith("Renderer stopped because the live audio stream ended"):
                    if final_stop_reason == "coreaudio_reset" and _coreaudio_recovery_launch_prefs_available_unlocked():
                        STATE.phase = "starting"
                        schedule_recovery = True
                        recovery_reason = final_stop_reason
                    else:
                        STATE.phase = "stopped"
                else:
                    STATE.phase = "error"
                STATE.status_text = final_exit_text
            STATE.last_exit_code = rc
            _clear_renderer_signal_state_unlocked()
            STATE.bump_status()
            status_payload = STATE.status_unlocked()
    if status_payload is not None:
        push_native_status(status_payload)
        STATE.append_log(f"Renderer exited with code {rc}.")
        if schedule_recovery:
            _schedule_coreaudio_renderer_recovery(recovery_reason, delay=0.35)
    else:
        STATE.append_log(f"Ignored exit from stale renderer process {proc_pid} with code {rc}.")


def _output_device_is_stereo_compatible(item):
    try:
        outputs = int((item or {}).get("outputs", 0))
    except Exception:
        outputs = 0
    return outputs > 0 and outputs <= 2


def _output_channel_count_text(item):
    try:
        outputs = int((item or {}).get("outputs", 0))
    except Exception:
        outputs = 0
    return f"{outputs} output channel{'' if outputs == 1 else 's'}"


def _normalize_device_name_for_match(name):
    text = str(name or "")
    text = re.sub(r"\s*\(unavailable\)\s*$", "", text, flags=re.I)
    text = re.sub(r"[.。]+$", "", text).strip()
    text = re.sub(r"\s+", " ", text)
    return text.lower()


def _strip_device_sample_rate_suffix(name):
    text = _normalize_device_name_for_match(name)
    text = re.sub(r"\s+\d+(?:\.\d+)?\s*k(?:ilo)?hz$", "", text, flags=re.I)
    text = re.sub(r"\s+\d+(?:\.\d+)?\s*hz$", "", text, flags=re.I)
    return text.strip()


def _device_names_match(a, b):
    aa = _normalize_device_name_for_match(a)
    bb = _normalize_device_name_for_match(b)
    if not aa or not bb:
        return False
    if aa == bb:
        return True
    aa_base = _strip_device_sample_rate_suffix(aa)
    bb_base = _strip_device_sample_rate_suffix(bb)
    return bool(aa_base and bb_base and len(aa_base) >= 6 and aa_base == bb_base)


def _match_device(items, selected_index="", selected_name=""):
    selected_index = str(selected_index or "").strip()
    selected_name = str(selected_name or "").strip()

    if selected_name:
        exact_name_matches = [item for item in items if item.get("name") == selected_name]
        if selected_index:
            exact_name_and_index = next((item for item in exact_name_matches if str(item.get("index")) == selected_index), None)
            if exact_name_and_index is not None:
                return exact_name_and_index
        if exact_name_matches:
            return exact_name_matches[0]

        normalized_name_matches = [item for item in items if _device_names_match(item.get("name"), selected_name)]
        if selected_index:
            normalized_name_and_index = next((item for item in normalized_name_matches if str(item.get("index")) == selected_index), None)
            if normalized_name_and_index is not None:
                return normalized_name_and_index
        if normalized_name_matches:
            return normalized_name_matches[0]

        # Core Audio/PortAudio device indexes are not stable after hotplug. If
        # the saved name is gone, an index-only match may be a different physical
        # output that shifted into the old slot. Treat that as missing so the
        # renderer stops instead of silently switching to another DAC/interface.
        return None

    if selected_index:
        exact_index_match = next((item for item in items if str(item.get("index")) == selected_index), None)
        if exact_index_match is not None:
            return exact_index_match

    return None

def _resolve_selected_devices(exe, input_device, output_device, input_device_name="", output_device_name="", deadline_seconds=10.0, wait_status_text="Waiting for audio devices…", publish_wait_status=True):
    selected_input = None
    selected_output = None
    last_inputs = []
    last_outputs = []
    first_attempt = True
    deadline = time.time() + max(0.0, float(deadline_seconds))
    while first_attempt or time.time() < deadline:
        first_attempt = False
        last_inputs, last_outputs = list_devices(exe)
        with STATE.lock:
            _record_device_inventory_unlocked(inputs=last_inputs, outputs=last_outputs, input_enumerated=True)
        selected_input = _match_device(last_inputs, input_device, input_device_name)
        selected_output = _match_device(last_outputs, output_device, output_device_name)
        if selected_input is not None and selected_output is not None:
            return selected_input, selected_output
        if not publish_wait_status or time.time() >= deadline:
            break
        with STATE.cond:
            STATE.phase = "starting"
            STATE.status_text = wait_status_text
            STATE.bump_status()
            status_payload = STATE.status_unlocked()
        push_native_status(status_payload)
        time.sleep(0.2)
    return selected_input, selected_output


def _selected_output_still_available(exe, output_device, output_device_name=""):
    outputs = list_output_devices(exe)
    with STATE.lock:
        _record_device_inventory_unlocked(outputs=outputs, input_enumerated=False)
    selected_output = _match_device(outputs, output_device, output_device_name)
    return selected_output is not None


def _wait_for_renderer_live_or_exit(proc, timeout_seconds=6.0):
    deadline = time.monotonic() + max(0.1, float(timeout_seconds))
    with STATE.cond:
        while True:
            if STATE.proc is not proc:
                return str(STATE.phase or "") == "running"
            if str(STATE.phase or "") == "running":
                return True
            if proc is None or proc.poll() is not None:
                return False
            remaining = deadline - time.monotonic()
            if remaining <= 0:
                return False
            STATE.cond.wait(timeout=min(0.2, remaining))


def _mark_recovery_attempt_timeout_unlocked():
    STATE.renderer_stop_requested = True
    STATE.renderer_stop_reason = "startup_timeout"
    STATE.renderer_stop_final_text = (
        "Core Audio recovery attempt timed out while reopening the audio stream. Retrying…"
    )
    STATE.phase = "starting"
    STATE.status_text = STATE.renderer_stop_final_text
    STATE.awaiting_live_status = False
    STATE.renderer_seen_live = False
    _clear_renderer_signal_state_unlocked()
    STATE.bump_status()
    return STATE.status_unlocked()


def _write_runtime_peq_file(label, text):
    text = str(text or "")
    if not text.strip():
        return None
    safe_label = re.sub(r"[^A-Za-z0-9_.-]+", "_", label).strip("_") or "peq"
    f = tempfile.NamedTemporaryFile(
        mode="w",
        encoding="utf-8",
        suffix=f"_{safe_label}.txt",
        prefix="downmix_renderer_",
        delete=False,
    )
    try:
        f.write(text)
        if not text.endswith("\n"):
            f.write("\n")
        return f.name
    finally:
        f.close()


def _launch_renderer_locked(data, action_text="Launching stereo renderer…", resolve_deadline_seconds=0.0, publish_wait_status=False, allow_recovery_launch=False, clear_recovery_pending_on_launch=True):
    exe = normalize_renderer_exe(data.get("exe"))
    data["exe"] = exe
    if not exe or not os.path.exists(exe):
        raise ValueError(f"Renderer executable not found: {exe}")

    input_device = str(data["input_device"]).strip()
    output_device = str(data["output_device"]).strip()
    if not input_device or not output_device:
        raise ValueError("Select both an input device and an output device.")

    # Do not stop the keep-alive stream before launching the real duplex
    # renderer. Keep-alive is a parallel silent output client, not an idle-only
    # substitute for the renderer.

    input_device_name = str(data.get("input_device_name", "")).strip()
    output_device_name = str(data.get("output_device_name", "")).strip()

    # Use the same full-device resolution path as the last known stable build.
    # The output-only preflight helper was intended to avoid touching input/TCC
    # during stale-output checks, but on some USB DACs it can leave Start stuck
    # before the real renderer process becomes authoritative.
    ensure_microphone_access_for_launch()

    selected_input, selected_output = _resolve_selected_devices(
        exe,
        input_device=input_device,
        output_device=output_device,
        input_device_name=input_device_name,
        output_device_name=output_device_name,
        deadline_seconds=resolve_deadline_seconds,
        publish_wait_status=publish_wait_status,
    )
    if selected_input is None:
        raise TransientAudioDeviceError("Selected input device is unavailable or does not expose at least 16 input channels.")
    if selected_output is None:
        raise TransientAudioDeviceError("Selected output device is unavailable.")
    if not _output_device_is_stereo_compatible(selected_output):
        raise TransientAudioDeviceError(
            f"Selected output device must expose 1 or 2 output channels; {selected_output.get('name', 'it')} exposes {_output_channel_count_text(selected_output)}."
        )

    with STATE.lock:
        not_ready_reason = _start_readiness_reason_unlocked(
            input_device=str(selected_input.get("index", input_device)),
            input_device_name=str(selected_input.get("name", input_device_name)),
            output_device=str(selected_output.get("index", output_device)),
            output_device_name=str(selected_output.get("name", output_device_name)),
            allow_recovery_launch=allow_recovery_launch,
        )
    if not_ready_reason:
        raise TransientAudioDeviceError(not_ready_reason)

    input_device = str(selected_input["index"])
    output_device = str(selected_output["index"])
    data = dict(data)
    data["input_device"] = input_device
    data["output_device"] = output_device
    data["input_device_name"] = str(selected_input.get("name", ""))
    data["output_device_name"] = str(selected_output.get("name", ""))

    fixed_map = list(LAYOUT_PRESETS["9.1.6 bed (1:1)"])
    input_latency_text = str(data.get("input_latency_ms", DEFAULT_PREFS.get("input_latency_ms", "10"))).strip()
    input_latency_ms = None
    if input_latency_text != "":
        try:
            input_latency_ms = float(input_latency_text)
        except Exception:
            raise ValueError("Input safety latency must be a number of milliseconds.")
        if input_latency_ms < 0:
            raise ValueError("Input safety latency must be 0 ms or greater.")
        if input_latency_ms > 250:
            raise ValueError("Input safety latency is unexpectedly high. Use 0 to 250 ms.")

    output_latency_text = str(data.get("output_latency_ms", DEFAULT_PREFS.get("output_latency_ms", "10"))).strip()
    output_latency_ms = None
    if output_latency_text != "":
        try:
            output_latency_ms = float(output_latency_text)
        except Exception:
            raise ValueError("Output safety latency must be a number of milliseconds.")
        if output_latency_ms < 0:
            raise ValueError("Output safety latency must be 0 ms or greater.")
        if output_latency_ms > 250:
            raise ValueError("Output safety latency is unexpectedly high. Use 0 to 250 ms.")

    cmd = [
        exe,
        "--input-device", input_device,
        "--output-device", output_device,
    ]
    cmd.extend([
        "--frames-per-buffer", str(int(data.get("frames", 64))),
        "--input-channels", "16",
    ])
    if input_latency_ms is not None:
        cmd.extend(["--input-latency-ms", f"{input_latency_ms:g}"])
    if output_latency_ms is not None:
        cmd.extend(["--output-latency-ms", f"{output_latency_ms:g}"])
    cmd.extend([
        "--show-active-inputs",
        "--show-output-meter",
        "--status-interval-ms", "8",
        "--xrun-log-interval-ms", "100",
        "--active-threshold-db", "-160",
        "--master-gain-db", f"{parse_preamp_db(data.get('preamp_db', 0)):g}",
        "--lfe-filter-mode", "butterworth" if bool_value(data.get("lfe_lowpass", True), default=True) else "dry",
    ])
    if bool_value(data.get("swap_outputs", False), default=False):
        cmd.append("--swap-outputs")

    global_peq_path = _write_runtime_peq_file("global_output_peq", data.get("global_output_peq_text", ""))
    speaker_peq_path = _write_runtime_peq_file("speaker_output_peq", data.get("speaker_output_peq_text", ""))
    if global_peq_path:
        cmd.extend(["--global-output-peq-file", global_peq_path, "--global-output-peq-channel", "first"])
    swap_outputs = bool_value(data.get("swap_outputs", False), default=False)
    # Stereo correction channel-swap behavior: a stereo L/R correction file stays
    # tied to the driver/channel it corrected. When output swap is enabled,
    # flip the imported correction channel assignment as well.
    # This prevents a CH:0/CH:1 correction file from being applied backwards
    # after the renderer swaps the audio streams.
    left_corr_channel = "1" if swap_outputs else "0"
    right_corr_channel = "0" if swap_outputs else "1"
    if speaker_peq_path:
        cmd.extend(["--speaker-output-peq-file", speaker_peq_path, "--speaker-left-peq-channel", left_corr_channel, "--speaker-right-peq-channel", right_corr_channel])

    cmd.extend([
        "--input-map", ",".join(str(x) for x in fixed_map),
    ])

    with STATE.cond:
        if STATE.proc is not None and STATE.proc.poll() is None:
            raise ValueError("Renderer is already running.")
        STATE.phase = "starting"
        STATE.status_text = action_text
        STATE.renderer_stop_requested = False
        STATE.renderer_stop_reason = ""
        STATE.renderer_stop_final_text = ""
        STATE.renderer_seen_live = False
        STATE.awaiting_live_status = False
        _clear_renderer_signal_state_unlocked()
        STATE.log_lines.clear()
        STATE.log_cache = ""
        STATE.log_revision += 1
        STATE.bump_status()
        status_payload = STATE.status_unlocked()
        log_payload = STATE.log_payload_unlocked()
    push_native_status(status_payload)
    push_native_log(log_payload)

    proc = subprocess.Popen(cmd, stdout=subprocess.PIPE, stderr=subprocess.STDOUT, bufsize=0, start_new_session=True)
    reader = threading.Thread(target=reader_worker, args=(proc,), daemon=True)
    with STATE.cond:
        STATE.proc = proc
        try:
            STATE.proc_pgid = os.getpgid(proc.pid)
        except Exception:
            STATE.proc_pgid = None
        STATE.reader_thread = reader
        STATE.running_exe = exe
        STATE.running_input_device = input_device
        STATE.running_output_device = output_device
        STATE.running_input_device_name = data.get("input_device_name", "")
        STATE.running_output_device_name = data.get("output_device_name", "")
        STATE.awaiting_live_status = True
        if clear_recovery_pending_on_launch:
            STATE.renderer_recovery_pending = False
    STATE.append_log("Launching:")
    STATE.append_log(" ".join(cmd))
    reader.start()
    threading.Thread(target=renderer_startup_watchdog, args=(proc,), daemon=True).start()

    # Do not run any post-launch PortAudio/Core Audio helper processes here.
    # Earlier builds polled --list-output-devices for the first few hundred ms
    # after Popen. That meant the real duplex renderer and a second helper
    # process touched Core Audio at the same time, exactly while the input stream
    # was being established. Startup success/failure is now reported only by the
    # real renderer process through reader_worker().
    return {"ok": True, "data": data}


def _stop_renderer_locked(stop_text="Stopping renderer…", final_text="Renderer stopped.", restart_keepalive=True, stop_reason=""):
    if not stop_reason:
        stop_reason = _stop_reason_from_text(final_text)
    with STATE.cond:
        if STATE.renderer_recovery_pending:
            STATE.renderer_recovery_cancel_requested = True
            STATE.renderer_recovery_pending = False
        status_payload = _begin_controlled_renderer_stop_unlocked(
            stop_reason=stop_reason,
            stop_text=stop_text,
            final_text=final_text,
        )
    push_native_status(status_payload)
    STATE.append_log("Stop requested." if not stop_reason else f"Stop requested: {stop_reason}.")
    terminate_renderer()
    # terminate_renderer can make the reader thread a stale-exit path. Finalize
    # here through the same explicit reason state instead of reclassifying by
    # message text or return code.
    with STATE.cond:
        final_message = str(STATE.renderer_stop_final_text or final_text or "Renderer stopped.").strip()
        STATE.phase = "stopped"
        STATE.status_text = final_message or "Renderer stopped."
        STATE.renderer_stop_requested = False
        STATE.renderer_stop_reason = ""
        STATE.renderer_stop_final_text = ""
        STATE.renderer_seen_live = False
        STATE.awaiting_live_status = False
        _clear_renderer_signal_state_unlocked()
        STATE.bump_status()
        status_payload = STATE.status_unlocked()
    push_native_status(status_payload)
    if restart_keepalive:
        ensure_output_keepalive_from_preferences_async(delay=0.05, log_errors=True)
    else:
        terminate_keepalive(wait_timeout=1.5)
    return {"ok": True}


def monitor_audio_devices():
    last_error = ""
    while True:
        time.sleep(1.0)
        with STATE.lock:
            if STATE.shutdown_requested:
                return
            proc = STATE.proc
            running = proc is not None and proc.poll() is None
            keep_proc = STATE.keepalive_proc
            keepalive_running = keep_proc is not None and keep_proc.poll() is None
            exe = STATE.preferences.get("exe", DEFAULT_PREFS["exe"])

        if running:
            # Do not spawn a second PortAudio/CoreAudio process while the duplex
            # renderer is live. The live renderer already monitors Pa_IsStreamActive
            # and callback stalls; background output scans can briefly disturb some
            # USB/CoreAudio outputs and produce periodic crackles during digital
            # silence.
            last_error = ""
            continue

        if keepalive_running:
            # Same rule for the silent keep-alive stream: while an audio stream is
            # already holding the output open, do not run periodic device scans in
            # another process. If the keep-alive stream exits after a device change,
            # this loop will resume scanning on the next pass so it can restart when
            # the selected output reappears.
            last_error = ""
            continue

        try:
            outputs = list_output_devices(exe)
            with STATE.lock:
                _record_device_inventory_unlocked(outputs=outputs, input_enumerated=False)
            last_error = ""
        except Exception as exc:
            message = f"Automatic output device refresh error: {exc}"
            if message != last_error:
                STATE.append_log(message)
                last_error = message
            continue

        maybe_resume_keepalive_after_output_inventory(outputs, delay=0.05, log_errors=False)


class Handler(BaseHTTPRequestHandler):
    def _send(self, code, body, content_type="application/json; charset=utf-8"):
        data = body if isinstance(body, (bytes, bytearray)) else body.encode("utf-8")
        self.send_response(code)
        self.send_header("Content-Type", content_type)
        self.send_header("Content-Length", str(len(data)))
        self.send_header("Cache-Control", "no-store")
        self.end_headers()
        self.wfile.write(data)

    def _json_body(self):
        length = int(self.headers.get("Content-Length", "0") or "0")
        raw = self.rfile.read(length) if length else b"{}"
        return json.loads(raw.decode("utf-8"))

    def do_GET(self):
        parsed = urlparse(self.path)
        if parsed.path == "/":
            page = (HTML
                .replace("%BED_LABELS%", json.dumps(BED_LABELS))
                .replace("%LAYOUT_PRESETS%", json.dumps(LAYOUT_PRESETS))
                .replace("%CLIENT_ID%", json.dumps(str(uuid.uuid4())))
                .replace("%EMBEDDED_MODE%", json.dumps(parse_qs(parsed.query).get("embedded", ["0"])[0] == "1")))
            return self._send(200, page, "text/html; charset=utf-8")
        if parsed.path == "/api/status":
            return self._send(200, json.dumps(STATE.status()))
        if parsed.path == "/api/events":
            self.send_response(200)
            self.send_header("Content-Type", "text/event-stream; charset=utf-8")
            self.send_header("Cache-Control", "no-store")
            self.send_header("Connection", "keep-alive")
            self.end_headers()

            def send_event(name, payload):
                data = json.dumps(payload, separators=(",", ":"))
                self.wfile.write(f"event: {name}\ndata: {data}\n\n".encode("utf-8"))
                self.wfile.flush()

            last_status = -1
            last_log = -1
            try:
                while True:
                    timed_out = False
                    with STATE.cond:
                        if STATE.shutdown_requested:
                            status_payload = STATE.status_unlocked()
                            log_payload = STATE.log_payload_unlocked()
                        else:
                            current_status = STATE.status_revision
                            current_log = STATE.log_revision
                            if current_status == last_status and current_log == last_log:
                                notified = STATE.cond.wait(timeout=15.0)
                                timed_out = not notified
                            status_payload = STATE.status_unlocked()
                            log_payload = STATE.log_payload_unlocked()
                    if status_payload["status_revision"] != last_status:
                        send_event("status", status_payload)
                        last_status = status_payload["status_revision"]
                    if log_payload["log_revision"] != last_log:
                        send_event("log", log_payload)
                        last_log = log_payload["log_revision"]
                    if status_payload.get("phase") == "disconnected":
                        send_event("shutdown", {"ok": True})
                        return
                    if timed_out:
                        self.wfile.write(b": ping\n\n")
                        self.wfile.flush()
            except (BrokenPipeError, ConnectionResetError):
                return
            except Exception:
                return
        if parsed.path == "/api/log":
            return self._send(200, json.dumps(STATE.log_payload()))
        if parsed.path == "/api/preferences":
            with STATE.lock:
                prefs = dict(STATE.preferences)
            return self._send(200, json.dumps(prefs))
        if parsed.path == "/api/devices":
            query = parse_qs(parsed.query)
            exe = normalize_renderer_exe(query.get("exe", [STATE.preferences.get("exe", DEFAULT_PREFS["exe"])])[0])
            auto_refresh = str(query.get("auto", ["0"])[0]).lower() in ("1", "true", "yes")
            try:
                with STATE.lock:
                    phase = STATE.phase
                    cached_inputs = list(STATE.cached_inputs)
                    cached_outputs = list(STATE.cached_outputs)
                    pref_input_device = str(STATE.preferences.get("input_device", "") or "").strip()
                    pref_input_device_name = str(STATE.preferences.get("input_device_name", "") or "").strip()
                    pref_output_device = str(STATE.preferences.get("output_device", "") or "").strip()
                    pref_output_device_name = str(STATE.preferences.get("output_device_name", "") or "").strip()

                requested_output_device = str(query.get("output_device", [pref_output_device])[0] or "").strip()
                requested_output_device_name = str(query.get("output_device_name", [pref_output_device_name])[0] or "").strip()

                if auto_refresh:
                    # Automatic refresh is now strictly output-only. Even when the
                    # renderer is idle/stopped, a periodic refresh, focus-return
                    # refresh, or output-device selection must not run
                    # --list-devices, because that enumerates inputs and can make
                    # macOS re-enter the microphone/TCC permission path. Input
                    # devices are populated only by the intentional foreground
                    # refreshDevicesFull() path at app open, the manual Refresh
                    # devices button, or the real Start path.
                    outputs = list_output_devices(exe)
                    inputs = cached_inputs
                    input_enumerated = False
                else:
                    inputs, outputs = list_devices(exe)
                    input_enumerated = True
                requested_input_device = str(query.get("input_device", [pref_input_device])[0] or "").strip()
                requested_input_device_name = str(query.get("input_device_name", [pref_input_device_name])[0] or "").strip()
                with STATE.lock:
                    _record_device_inventory_unlocked(inputs=inputs, outputs=outputs, input_enumerated=input_enumerated)
                    STATE.preferences["exe"] = exe
                    STATE.preferences = save_preferences(STATE.preferences)
                    pref_exe = STATE.preferences.get("exe", exe)
                    readiness = _start_readiness_payload_unlocked(
                        input_device=requested_input_device,
                        input_device_name=requested_input_device_name,
                        output_device=requested_output_device,
                        output_device_name=requested_output_device_name,
                    )
                maybe_resume_keepalive_after_output_inventory(outputs, delay=0.05, log_errors=False)
                payload = {"inputs": inputs, "outputs": outputs, "exe": pref_exe, "input_enumerated": input_enumerated}
                payload.update(readiness)
                return self._send(200, json.dumps(payload))
            except Exception as exc:
                with STATE.lock:
                    inputs = list(STATE.cached_inputs)
                    outputs = list(STATE.cached_outputs)
                    readiness = _start_readiness_payload_unlocked(
                        input_device=str(query.get("input_device", [pref_input_device])[0] or "").strip(),
                        input_device_name=str(query.get("input_device_name", [pref_input_device_name])[0] or "").strip(),
                        output_device=str(query.get("output_device", [pref_output_device])[0] or "").strip(),
                        output_device_name=str(query.get("output_device_name", [pref_output_device_name])[0] or "").strip(),
                    )
                maybe_resume_keepalive_after_output_inventory(outputs, delay=0.05, log_errors=False)
                payload = {"inputs": inputs, "outputs": outputs, "exe": exe, "input_enumerated": False, "error": str(exc)}
                payload.update(readiness)
                return self._send(200, json.dumps(payload))
        return self._send(404, json.dumps({"ok": False, "error": "Not found"}))

    def _save_preferences(self, data):
        indev_name = ""
        outdev_name = ""
        requested_indev_name = str(data.get("input_device_name", "")).strip()
        requested_outdev_name = str(data.get("output_device_name", "")).strip()
        exe = normalize_renderer_exe(data.get("exe", STATE.preferences.get("exe", DEFAULT_PREFS["exe"])))
        try:
            with STATE.lock:
                cached_inputs = list(STATE.cached_inputs)
                cached_outputs = list(STATE.cached_outputs)
            # Preference saving should not probe the input-device side. The
            # caller may be an automatic UI refresh or a collapse/expand toggle,
            # and on macOS a full input enumeration can retrigger microphone/TCC
            # prompts, especially immediately after the selected output is
            # disconnected. Resolve output names with the output-only helper and
            # preserve cached/requested input names until an intentional launch.
            inputs = cached_inputs
            try:
                outputs = list_output_devices(exe)
            except Exception:
                outputs = cached_outputs
            with STATE.lock:
                # This path only preserves cached input rows while resolving the
                # output name. Do not mark it as a fresh input enumeration; no
                # input/CoreAudio/TCC probe happened here.
                _record_device_inventory_unlocked(inputs=inputs if inputs else None, outputs=outputs, input_enumerated=False)
            indev = str(data.get("input_device", "")).strip()
            outdev = str(data.get("output_device", "")).strip()
            for item in inputs:
                if str(item["index"]) == indev:
                    candidate_name = item["name"]
                    if not requested_indev_name or candidate_name == requested_indev_name:
                        indev_name = candidate_name
                        break
            for item in outputs:
                if str(item["index"]) == outdev:
                    candidate_name = item["name"]
                    if not requested_outdev_name or candidate_name == requested_outdev_name:
                        outdev_name = candidate_name
                        break
        except Exception:
            pass
        data = dict(data)
        status_payload = None
        with STATE.lock:
            prefs = dict(STATE.preferences)
            prefs.update(data)
            if indev_name:
                prefs["input_device_name"] = indev_name
            elif "input_device_name" in data:
                prefs["input_device_name"] = requested_indev_name
            if outdev_name:
                prefs["output_device_name"] = outdev_name
            elif "output_device_name" in data:
                prefs["output_device_name"] = requested_outdev_name
            STATE.preferences = save_preferences(prefs)

            # If the renderer is already stopped and the user selects a different
            # available device, clear the old hot-unplug stop message in the
            # backend too. Otherwise /api/status can keep replaying the previous
            # "atom 3 removed" state after the UI has already moved to RODE/SMSL,
            # causing the Stopped message to flicker between removed and idle.
            removed = _removed_device_info_from_stop_text(STATE.status_text)
            if STATE.phase in ("stopped", "error") and removed:
                if removed["kind"] == "outdev":
                    selected_name = str(STATE.preferences.get("output_device_name", "") or "").strip()
                    selected_value = str(STATE.preferences.get("output_device", "") or "").strip()
                else:
                    selected_name = str(STATE.preferences.get("input_device_name", "") or "").strip()
                    selected_value = str(STATE.preferences.get("input_device", "") or "").strip()
                removed_name = str(removed.get("name", "") or "").strip()
                still_selected_removed_device = bool(
                    removed_name and selected_name and _device_names_match(selected_name, removed_name)
                )
                if not still_selected_removed_device and (selected_name or selected_value):
                    STATE.phase = "stopped"
                    STATE.status_text = "Stereo renderer is idle."
                    STATE.renderer_stop_requested = False
                    STATE.renderer_stop_reason = ""
                    STATE.renderer_stop_final_text = ""
                    STATE.renderer_seen_live = False
                    STATE.awaiting_live_status = False
                    _clear_renderer_signal_state_unlocked()
                    STATE.bump_status()
                    status_payload = STATE.status_unlocked()
            saved = dict(STATE.preferences)
        if status_payload:
            push_native_status(status_payload)
        return saved

    def _save_preferences_direct(self, data):
        # Used immediately after successful renderer launch. The launch path has
        # already resolved input/output names, so do not enumerate devices again
        # here. Enumerating through PortAudio while the duplex renderer is
        # starting can interfere with live input capture on some macOS devices.
        data = dict(data or {})
        if "exe" in data:
            data["exe"] = normalize_renderer_exe(data.get("exe"))
        with STATE.lock:
            prefs = dict(STATE.preferences)
            prefs.update(data)
            STATE.preferences = save_preferences(prefs)
            return dict(STATE.preferences)

    def do_POST(self):
        if self.path == "/api/minimize":
            try:
                ok = bool(NATIVE_BRIDGE.minimize())
                return self._send(200, json.dumps({"ok": ok}))
            except Exception as exc:
                return self._send(200, json.dumps({"ok": False, "error": str(exc)}))

        if self.path == "/api/preferences":
            try:
                data = self._json_body()
                prefs = self._save_preferences(data)
                ensure_output_keepalive_from_preferences_async(delay=0.05, log_errors=True)
                return self._send(200, json.dumps({"ok": True, "preferences": prefs}))
            except Exception as exc:
                return self._send(200, json.dumps({"ok": False, "error": str(exc)}))

        if self.path == "/api/start":
            try:
                data = self._json_body()
                with STATE.lifecycle_lock:
                    # Launch from the submitted payload directly. _launch_renderer_locked
                    # resolves and validates the selected devices, then returns the
                    # canonical device indices/names. Saving before launch performs an
                    # extra output-device scan and can restart the keep-alive process
                    # immediately before the real duplex stream opens, which is exactly
                    # the path that can leave the UI stuck at Starting….
                    result = _launch_renderer_locked(data, action_text="Launching stereo renderer…", resolve_deadline_seconds=0.0, publish_wait_status=False)
                    saved = self._save_preferences_direct(result.get("data", data))
                return self._send(200, json.dumps({"ok": True, "preferences": saved}))
            except TransientAudioDeviceError as exc:
                raw_message = str(exc)
                message = _normalize_unavailable_stop_text(
                    raw_message,
                    input_name=str(data.get("input_device_name", "")).strip(),
                    output_name=str(data.get("output_device_name", "")).strip(),
                    input_device=str(data.get("input_device", "")).strip(),
                    output_device=str(data.get("output_device", "")).strip(),
                )
                with STATE.cond:
                    STATE.phase = "stopped"
                    STATE.status_text = message
                    STATE.renderer_stop_requested = False
                    STATE.renderer_stop_reason = ""
                    STATE.renderer_stop_final_text = ""
                    STATE.renderer_seen_live = False
                    STATE.awaiting_live_status = False
                    _clear_renderer_signal_state_unlocked()
                    STATE.bump_status()
                    status_payload = STATE.status_unlocked()
                push_native_status(status_payload)
                return self._send(200, json.dumps({"ok": False, "error": message, "status_text": message, "phase": "stopped"}))
            except Exception as exc:
                raw_message = str(exc)
                message = _normalize_unavailable_stop_text(
                    raw_message,
                    input_name=str(data.get("input_device_name", "")).strip(),
                    output_name=str(data.get("output_device_name", "")).strip(),
                    input_device=str(data.get("input_device", "")).strip(),
                    output_device=str(data.get("output_device", "")).strip(),
                )
                device_unavailable = raw_message in (
                    "Selected output device is unavailable.",
                    "Selected input device is unavailable or does not expose at least 16 input channels.",
                    "Select both an input device and an output device.",
                )
                if _stop_reason_from_text(message):
                    device_unavailable = True
                with STATE.cond:
                    STATE.phase = "stopped" if device_unavailable else "error"
                    STATE.status_text = message
                    STATE.renderer_stop_requested = False
                    STATE.renderer_stop_reason = ""
                    STATE.renderer_stop_final_text = ""
                    STATE.renderer_seen_live = False
                    STATE.awaiting_live_status = False
                    _clear_renderer_signal_state_unlocked()
                    STATE.bump_status()
                    status_payload = STATE.status_unlocked()
                push_native_status(status_payload)
                return self._send(200, json.dumps({"ok": False, "error": message, "status_text": message, "phase": STATE.phase}))

        if self.path == "/api/stop":
            data = self._json_body()
            stop_text = str(data.get("stop_text", "Stopping renderer…") or "Stopping renderer…")
            final_text = str(data.get("reason", data.get("final_text", "Renderer stopped.")) or "Renderer stopped.")
            restart_keepalive = bool_value(data.get("restart_keepalive", True), default=True)
            stop_reason = str(data.get("stop_reason", "") or "").strip() or _stop_reason_from_text(final_text)
            with STATE.lifecycle_lock:
                result = _stop_renderer_locked(stop_text=stop_text, final_text=final_text, restart_keepalive=restart_keepalive, stop_reason=stop_reason)
            return self._send(200, json.dumps(result))

        if self.path == "/api/apply":
            had_running_proc = False
            try:
                data = self._json_body()
                with STATE.lifecycle_lock:
                    self._save_preferences(data)
                    with STATE.lock:
                        had_running_proc = STATE.proc is not None and STATE.proc.poll() is None

                    exe = str(data.get("exe", "")).strip()
                    input_device = str(data.get("input_device", "")).strip()
                    output_device = str(data.get("output_device", "")).strip()
                    input_device_name = str(data.get("input_device_name", "")).strip()
                    output_device_name = str(data.get("output_device_name", "")).strip()
                    selected_output_preflight = _selected_output_device(
                        exe,
                        output_device=output_device,
                        output_device_name=output_device_name,
                        deadline_seconds=0.35,
                    )
                    if selected_output_preflight is None:
                        raise ValueError("Selected output device is unavailable.")
                    if not _output_device_is_stereo_compatible(selected_output_preflight):
                        raise ValueError(
                            f"Selected output device must expose 1 or 2 output channels; {selected_output_preflight.get('name', 'it')} exposes {_output_channel_count_text(selected_output_preflight)}."
                        )

                    selected_input, selected_output = _resolve_selected_devices(
                        exe,
                        input_device=input_device,
                        output_device=str(selected_output_preflight.get("index", output_device)),
                        input_device_name=input_device_name,
                        output_device_name=str(selected_output_preflight.get("name", output_device_name)),
                        deadline_seconds=0.35,
                        publish_wait_status=False,
                    )
                    if selected_input is None:
                        raise ValueError("Selected input device is unavailable or does not expose at least 16 input channels.")
                    if selected_output is None:
                        raise ValueError("Selected output device is unavailable.")

                    if had_running_proc or STATE.phase in ("running", "starting", "stopping"):
                        _stop_renderer_locked(
                            stop_text="Applying changes and restarting renderer…",
                            final_text="Renderer stopped for apply."
                        )
                    result = _launch_renderer_locked(
                        data,
                        action_text="Restarting renderer with updated settings…" if had_running_proc else "Starting renderer with applied settings…",
                        resolve_deadline_seconds=0.75,
                        publish_wait_status=False,
                    )
                    saved = self._save_preferences(result.get("data", data))
                return self._send(200, json.dumps({"ok": True, "preferences": saved}))
            except Exception as exc:
                if had_running_proc:
                    try:
                        terminate_renderer(wait_timeout=1.5)
                    except Exception:
                        pass
                raw_message = str(exc)
                message = _normalize_unavailable_stop_text(
                    raw_message,
                    input_name=str(data.get("input_device_name", "")).strip(),
                    output_name=str(data.get("output_device_name", "")).strip(),
                    input_device=str(data.get("input_device", "")).strip(),
                    output_device=str(data.get("output_device", "")).strip(),
                )
                device_unavailable = raw_message in (
                    "Selected output device is unavailable.",
                    "Selected input device is unavailable or does not expose at least 16 input channels.",
                    "Select both an input device and an output device.",
                )
                if _stop_reason_from_text(message):
                    device_unavailable = True
                with STATE.cond:
                    STATE.phase = "stopped" if device_unavailable else "error"
                    STATE.status_text = message
                    STATE.renderer_stop_requested = False
                    STATE.renderer_stop_reason = ""
                    STATE.renderer_stop_final_text = ""
                    STATE.renderer_seen_live = False
                    STATE.awaiting_live_status = False
                    _clear_renderer_signal_state_unlocked()
                    STATE.bump_status()
                    status_payload = STATE.status_unlocked()
                push_native_status(status_payload)
                return self._send(200, json.dumps({"ok": False, "error": message, "status_text": message, "phase": STATE.phase}))

        if self.path == "/api/client_open":
            data = self._json_body()
            client_id = str(data.get("client_id", "")).strip()
            if client_id:
                STATE.register_client(client_id)
            return self._send(200, json.dumps({"ok": True}))

        if self.path == "/api/client_ping":
            data = self._json_body()
            client_id = str(data.get("client_id", "")).strip()
            if client_id:
                STATE.touch_client(client_id)
            return self._send(200, json.dumps({"ok": True}))

        if self.path == "/api/client_close":
            data = self._json_body()
            client_id = str(data.get("client_id", "")).strip()
            if client_id:
                STATE.unregister_client(client_id)
            if STATE.live_client_count() == 0:
                schedule_shutdown_if_no_clients(2.5, "Launcher page closed. Shutting down launcher.")
            return self._send(200, json.dumps({"ok": True}))

        return self._send(404, json.dumps({"ok": False, "error": "Not found"}))

    def log_message(self, format, *args):
        return

def find_port(start=8765):
    for port in range(start, start + 50):
        with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
            try:
                s.bind(("127.0.0.1", port))
                return port
            except OSError:
                continue
    raise RuntimeError("Could not find a free localhost port")

def _cleanup_child_processes_for_exit():
    try:
        terminate_renderer(wait_timeout=1.5)
    except Exception:
        pass
    try:
        terminate_keepalive(wait_timeout=1.5)
    except Exception:
        pass


def main():
    atexit.register(_cleanup_child_processes_for_exit)
    port = find_port()
    server = ThreadingHTTPServer(("127.0.0.1", port), Handler)
    STATE.server = server
    url = f"http://127.0.0.1:{port}/"
    print(f"Bed Renderer web launcher running at {url}")
    print(f"Preferences file: {PREFS_PATH}")
    print("Close the launcher page to request launcher shutdown.")
    
    def stop_from_signal(signum, frame):
        request_shutdown(f"Launcher received signal {signum}. Shutting down.")

    for sig in (signal.SIGINT, signal.SIGTERM):
        try:
            signal.signal(sig, stop_from_signal)
        except Exception:
            pass

    threading.Timer(0.4, lambda: webbrowser.open(url)).start()
    ensure_output_keepalive_from_preferences_async(delay=0.8, log_errors=False)
    threading.Thread(target=client_watchdog, daemon=True).start()
    threading.Thread(target=monitor_audio_devices, daemon=True).start()

    try:
        server.serve_forever()
    finally:
        terminate_renderer()
        terminate_keepalive()
        server.server_close()
    return 0

if __name__ == "__main__":
    raise SystemExit(main())
