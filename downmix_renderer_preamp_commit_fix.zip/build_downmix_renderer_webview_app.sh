#!/bin/bash
set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "$0")" && pwd)"
cd "$SCRIPT_DIR"

APP_NAME="Downmix Renderer"
PY_FILE="downmix_renderer_webview_app.py"
CORE_FILE="bed_renderer_web_launcher.py"
BIN_FILE="bed_renderer_916_low_latency"
CPP_FILE="bed_renderer_916_low_latency.cpp"
BUNDLE_ID="com.peqdb.downmixrenderer"
VENV_DIR="$SCRIPT_DIR/.pyinstaller-venv-webview"
DIST_DIR="$SCRIPT_DIR/dist"
BUILD_DIR="$SCRIPT_DIR/build"
ZIP_PATH="$SCRIPT_DIR/${APP_NAME}.zip"
ICON_PATH="$SCRIPT_DIR/DownmixRenderer.icns"
APP_PATH="$DIST_DIR/$APP_NAME.app"
PLIST_PATH="$APP_PATH/Contents/Info.plist"

for f in "$PY_FILE" "$CORE_FILE" "$CPP_FILE"; do
  if [[ ! -f "$f" ]]; then
    echo "Missing $f"
    exit 1
  fi
done

if ! command -v python3 >/dev/null 2>&1; then
  echo "python3 is required but was not found."
  exit 1
fi

if [[ "$(uname -s)" != "Darwin" ]]; then
  echo "This build script must be run on macOS because the renderer uses Core Audio."
  exit 1
fi

if [[ -z "${PORTAUDIO_PREFIX:-}" ]]; then
  if [[ -d "/opt/homebrew/opt/portaudio" ]]; then
    PORTAUDIO_PREFIX="/opt/homebrew/opt/portaudio"
  elif [[ -d "/usr/local/opt/portaudio" ]]; then
    PORTAUDIO_PREFIX="/usr/local/opt/portaudio"
  else
    echo "Could not find Homebrew PortAudio. Install it with: brew install portaudio"
    echo "Or set PORTAUDIO_PREFIX=/path/to/portaudio before running this script."
    exit 1
  fi
fi

rm -f "$SCRIPT_DIR/$BIN_FILE"

echo "Compiling $BIN_FILE from $CPP_FILE..."
"${CXX:-clang++}" -std=c++17 -O3 -Wall -Wextra \
  "$SCRIPT_DIR/$CPP_FILE" \
  -o "$SCRIPT_DIR/$BIN_FILE" \
  -I"$PORTAUDIO_PREFIX/include" \
  -L"$PORTAUDIO_PREFIX/lib" \
  -Wl,-rpath,"$PORTAUDIO_PREFIX/lib" \
  -lportaudio \
  -framework CoreAudio \
  -framework AudioToolbox \
  -framework AudioUnit \
  -framework CoreFoundation

chmod +x "$BIN_FILE" || true
if ! strings "$SCRIPT_DIR/$BIN_FILE" | grep -q -- "--lfe-filter-mode"; then
  echo "Compiled renderer does not contain --lfe-filter-mode support. Build aborted."
  exit 1
fi
if ! strings "$SCRIPT_DIR/$BIN_FILE" | grep -q -- "--list-output-devices"; then
  echo "Compiled renderer does not contain output-only device listing support. Build aborted."
  exit 1
fi

python3 -m venv "$VENV_DIR"
source "$VENV_DIR/bin/activate"
python -m pip install --upgrade pip
python -m pip install pyinstaller pywebview pyobjc-framework-AVFoundation pyobjc-framework-Cocoa

rm -rf "$DIST_DIR" "$BUILD_DIR"

if [[ -f "$ICON_PATH" ]]; then
  pyinstaller \
    --noconfirm \
    --clean \
    --windowed \
    --onedir \
    --name "$APP_NAME" \
    --add-binary "$SCRIPT_DIR/$BIN_FILE:." \
    --osx-bundle-identifier "$BUNDLE_ID" \
    --collect-all webview \
    --icon "$ICON_PATH" \
    "$SCRIPT_DIR/$PY_FILE"
else
  pyinstaller \
    --noconfirm \
    --clean \
    --windowed \
    --onedir \
    --name "$APP_NAME" \
    --add-binary "$SCRIPT_DIR/$BIN_FILE:." \
    --osx-bundle-identifier "$BUNDLE_ID" \
    --collect-all webview \
    "$SCRIPT_DIR/$PY_FILE"
fi

if [[ ! -d "$APP_PATH" ]]; then
  echo "Build did not produce $APP_PATH"
  exit 1
fi

/usr/libexec/PlistBuddy -c "Add :NSMicrophoneUsageDescription string Downmix Renderer needs microphone access to open the selected input audio device for real-time downmixing." "$PLIST_PATH" 2>/dev/null || \
/usr/libexec/PlistBuddy -c "Set :NSMicrophoneUsageDescription Downmix Renderer needs microphone access to open the selected input audio device for real-time downmixing." "$PLIST_PATH"

/usr/libexec/PlistBuddy -c "Add :LSApplicationCategoryType string public.app-category.music" "$PLIST_PATH" 2>/dev/null || true

codesign --force --deep --sign - "$APP_PATH"

rm -f "$ZIP_PATH"
ditto -c -k --keepParent "$APP_PATH" "$ZIP_PATH"

echo
echo "Built webview app: $APP_PATH"
echo "Shareable zip: $ZIP_PATH"
echo
echo "Launch the app by double-clicking it."
echo "This build waits for the local UI server before loading the main page, so it should no longer show a blank white window after the splash screen."
