#!/usr/bin/env python3
import atexit
import html
import json
import os
import signal
import socket
import sys
import threading
import time
import urllib.request
from http.server import ThreadingHTTPServer

try:
    import webview
except Exception as exc:
    raise SystemExit(
        "pywebview is not installed. Run the build script or install it with "
        "`python3 -m pip install pywebview`."
    ) from exc

import bed_renderer_web_launcher as core

LOADING_HTML = """<!doctype html>
<html>
<head>
<meta charset=\"utf-8\">
<meta name=\"viewport\" content=\"width=device-width, initial-scale=1\">
<title>Downmix Renderer</title>
<style>
  :root { color-scheme: dark; }
  body {
    margin: 0;
    min-height: 100vh;
    width: 100%;
    max-width: 100%;
    overflow-x: hidden;
    display: grid;
    place-items: center;
    background: #000000;
    color: #f0f3f8;
    font: 16px -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif;
  }
  .card {
    width: min(560px, calc(100vw - 48px));
    border-radius: 18px;
    border: 1px solid #333742;
    background: #000000;
    box-shadow: none;
    padding: 26px 28px;
  }
  h1 { margin: 0 0 12px 0; font-size: 24px; }
  p { margin: 0; color: #b5bcc9; line-height: 1.5; }
  .sub { margin-top: 10px; font-size: 14px; }
  .spinner {
    width: 32px; height: 32px; border-radius: 999px;
    border: 3px solid rgba(255,255,255,.18);
    border-top-color: #62a8ff;
    animation: spin .8s linear infinite;
    margin-bottom: 16px;
  }
  @keyframes spin { to { transform: rotate(360deg); } }
  code {
    display: inline-block;
    margin-top: 8px;
    padding: 6px 8px;
    border-radius: 10px;
    background: rgba(255,255,255,.06);
    color: #dbe7ff;
  }
</style>
</head>
<body>
  <div class=\"card\">
    <div class=\"spinner\"></div>
    <h1>Opening Downmix Renderer</h1>
    <p>The app window is waiting for the local control page to start.</p>
    <p class=\"sub\">If this takes more than a few seconds, the app will show a diagnostic message instead of a blank page.</p>
  </div>
</body>
</html>"""

ERROR_HTML_TEMPLATE = """<!doctype html>
<html>
<head>
<meta charset=\"utf-8\">
<meta name=\"viewport\" content=\"width=device-width, initial-scale=1\">
<title>Downmix Renderer</title>
<style>
  :root { color-scheme: dark; }
  body {
    margin: 0;
    min-height: 100vh;
    width: 100%;
    max-width: 100%;
    overflow-x: hidden;
    display: grid;
    place-items: center;
    background: #000000;
    color: #f0f3f8;
    font: 16px -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif;
  }
  .card {
    width: min(760px, calc(100vw - 48px));
    border-radius: 18px;
    border: 1px solid #5a2830;
    background: #000000;
    box-shadow: none;
    padding: 26px 28px;
  }
  h1 { margin: 0 0 12px 0; font-size: 24px; color: #ffd7de; }
  p { margin: 0 0 12px 0; color: #efc8cf; line-height: 1.5; }
  ul { color: #efc8cf; }
  code, pre {
    display: block;
    white-space: pre-wrap;
    word-break: break-word;
    margin-top: 10px;
    padding: 10px 12px;
    border-radius: 10px;
    background: rgba(255,255,255,.06);
    color: #fff1f4;
  }
</style>
</head>
<body>
  <div class=\"card\">
    <h1>Downmix Renderer could not load its UI</h1>
    <p>The native app window opened, but the local control page did not become ready in time.</p>
    <p>Try closing the app, then opening it again. If it keeps happening, delete the launcher preferences file and relaunch:</p>
    <code>{prefs_path}</code>
    <p>Last startup error:</p>
    <pre>{error_text}</pre>
  </div>
</body>
</html>"""


_CMD_M_MONITOR = None


def _parse_db_text(value):
    try:
        text = str(value or "").strip().lower()
        if text in ("", "-inf", "-infinity"):
            return float("-inf")
        return float(text)
    except Exception:
        return float("-inf")


def _max_db_text(a, b):
    da = _parse_db_text(a)
    db = _parse_db_text(b)
    if da == float("-inf") and db == float("-inf"):
        return "-inf"
    return str(b) if db > da else str(a)


def _merge_level_peak_maps(a, b):
    out = dict(a or {})
    for key, value in dict(b or {}).items():
        out[key] = _max_db_text(out.get(key), value)
    return out


def _merge_status_peak_payload(previous, incoming):
    if not previous:
        return incoming
    if not incoming:
        return previous
    if previous.get("phase") != "running" or incoming.get("phase") != "running":
        return incoming

    merged = dict(incoming)
    merged["meter_left_db"] = _max_db_text(previous.get("meter_left_db"), incoming.get("meter_left_db"))
    merged["meter_right_db"] = _max_db_text(previous.get("meter_right_db"), incoming.get("meter_right_db"))
    merged["input_levels_db"] = _merge_level_peak_maps(previous.get("input_levels_db"), incoming.get("input_levels_db"))
    merged["input_transients_db"] = _merge_level_peak_maps(previous.get("input_transients_db"), incoming.get("input_transients_db"))
    merged["clip_left"] = bool(previous.get("clip_left")) or bool(incoming.get("clip_left"))
    merged["clip_right"] = bool(previous.get("clip_right")) or bool(incoming.get("clip_right"))
    labels = []
    seen = set()
    for item in list(previous.get("active_labels") or []) + list(incoming.get("active_labels") or []):
        if item not in seen:
            seen.add(item)
            labels.append(item)
    merged["active_labels"] = labels
    return merged


def install_macos_cmd_m_minimize_shortcut():
    global _CMD_M_MONITOR
    if sys.platform != "darwin":
        return False
    if _CMD_M_MONITOR is not None:
        return True
    try:
        from AppKit import NSApplication, NSEvent
        try:
            from AppKit import NSEventMaskKeyDown
        except Exception:
            NSEventMaskKeyDown = 1 << 10
        try:
            from AppKit import NSEventModifierFlagCommand
        except Exception:
            NSEventModifierFlagCommand = 1 << 20

        def _handler(event):
            try:
                flags = int(event.modifierFlags())
                chars = str(event.charactersIgnoringModifiers() or "").lower()
                if chars == "m" and (flags & int(NSEventModifierFlagCommand)):
                    app = NSApplication.sharedApplication()
                    ns_window = app.keyWindow() or app.mainWindow()
                    if ns_window is not None:
                        ns_window.miniaturize_(None)
                        return None
            except Exception:
                pass
            return event

        _CMD_M_MONITOR = NSEvent.addLocalMonitorForEventsMatchingMask_handler_(NSEventMaskKeyDown, _handler)
        return True
    except Exception as exc:
        print(f"Could not install Command-M minimize shortcut: {exc}")
        return False


class WebViewNativeBridge(core.NativeBridgeBase):
    def __init__(self, window):
        self.window = window
        self.cond = threading.Condition()
        self.pending_status = None
        self.pending_log = None
        self.running = True
        self.thread = threading.Thread(target=self._worker, daemon=True)
        self.thread.start()

    def stop(self):
        with self.cond:
            self.running = False
            self.cond.notify_all()
        self.thread.join(timeout=1.0)

    def push_status(self, payload):
        with self.cond:
            self.pending_status = _merge_status_peak_payload(self.pending_status, payload)
            self.cond.notify_all()

    def push_log(self, payload):
        with self.cond:
            self.pending_log = payload
            self.cond.notify_all()

    def minimize(self):
        try:
            minimize_fn = getattr(self.window, "minimize", None)
            if callable(minimize_fn):
                minimize_fn()
                return True
        except Exception:
            pass

        if sys.platform == "darwin":
            try:
                from AppKit import NSApplication
                app = NSApplication.sharedApplication()
                ns_window = app.keyWindow() or app.mainWindow()
                if ns_window is not None:
                    ns_window.miniaturize_(None)
                    return True
            except Exception:
                pass
        return False

    def _dispatch_js(self, fn_name, payload):
        js = f"if(window.{fn_name}) window.{fn_name}({json.dumps(payload, separators=(',', ':'))});"
        self.window.evaluate_js(js)

    def _worker(self):
        while True:
            with self.cond:
                if self.running and self.pending_status is None and self.pending_log is None:
                    self.cond.wait(timeout=0.25)
                if not self.running:
                    return
                status = self.pending_status
                log = self.pending_log
                self.pending_status = None
                self.pending_log = None
            try:
                if status is not None:
                    self._dispatch_js('__nativeApplyStatus', status)
                if log is not None:
                    self._dispatch_js('__nativeApplyLog', log)
            except Exception:
                time.sleep(0.01)
                with self.cond:
                    if status is not None and self.pending_status is None:
                        self.pending_status = status
                    if log is not None and self.pending_log is None:
                        self.pending_log = log



def request_microphone_access():
    result = {
        "supported": False,
        "state": "deferred",
        "granted": True,
        "error": None,
        "api": None,
    }

    if sys.platform != "darwin":
        result["error"] = "Microphone permission prompting is only relevant on macOS."
        return result

    try:
        from AVFoundation import AVCaptureDevice, AVMediaTypeAudio
        result["supported"] = True
        status = int(AVCaptureDevice.authorizationStatusForMediaType_(AVMediaTypeAudio))
        if status == 3:
            result["api"] = "AVCaptureDevice.authorizationStatus"
            result["state"] = "authorized"
            result["granted"] = True
        elif status == 2:
            result["api"] = "AVCaptureDevice.authorizationStatus"
            result["state"] = "denied"
            result["granted"] = False
        elif status == 1:
            result["api"] = "AVCaptureDevice.authorizationStatus"
            result["state"] = "restricted"
            result["granted"] = False
        elif status == 0:
            # Ask once during foreground app launch, before any renderer start or
            # hotplug handling. Device refresh paths still never request TCC.
            result["api"] = "AVCaptureDevice.requestAccess"
            done = threading.Event()
            granted_box = {"granted": False}

            def _completion(granted):
                granted_box["granted"] = bool(granted)
                done.set()

            AVCaptureDevice.requestAccessForMediaType_completionHandler_(AVMediaTypeAudio, _completion)
            if done.wait(60.0):
                granted = bool(granted_box.get("granted"))
                result["state"] = "authorized" if granted else "denied"
                result["granted"] = granted
            else:
                result["state"] = "timed_out"
                result["granted"] = False
                result["error"] = "Timed out waiting for the macOS microphone permission prompt."
        else:
            result["api"] = "AVCaptureDevice.authorizationStatus"
            result["state"] = f"unknown({status})"
            result["granted"] = True
        return result
    except Exception as exc:
        result["error"] = f"AVCaptureDevice authorization/requestAccess unavailable: {exc}"
        result["state"] = "query_failed_deferred"
        result["granted"] = True
        return result



def _serve(server):
    try:
        server.serve_forever()
    finally:
        core.terminate_renderer()
        core.terminate_keepalive()
        server.server_close()


def _wait_for_server(url: str, timeout: float = 12.0):
    deadline = time.time() + timeout
    probe_url = url.rstrip("/") + "/api/status"
    last_error = None

    while time.time() < deadline:
        try:
            with urllib.request.urlopen(probe_url, timeout=0.75) as response:
                if 200 <= response.status < 300:
                    return True, None
        except Exception as exc:  # pragma: no cover - best effort diagnostics
            last_error = exc
            time.sleep(0.12)

    return False, last_error


def _cleanup_child_processes_for_exit():
    try:
        core.terminate_renderer(wait_timeout=1.5)
    except Exception:
        pass
    try:
        core.terminate_keepalive(wait_timeout=1.5)
    except Exception:
        pass


def _force_exit_after_window_close(delay=1.5):
    def _worker():
        time.sleep(delay)
        try:
            core.terminate_renderer(wait_timeout=0.5)
        except Exception:
            pass
        try:
            core.terminate_keepalive(wait_timeout=0.5)
        except Exception:
            pass
        os._exit(0)
    threading.Thread(target=_worker, daemon=True).start()


def main():
    atexit.register(_cleanup_child_processes_for_exit)
    port = core.find_port()
    server = ThreadingHTTPServer(("127.0.0.1", port), core.Handler)
    core.STATE.server = server
    core.STATE.shutdown_requested = False
    url = f"http://127.0.0.1:{port}/"
    app_url = url + "?embedded=1"

    print(f"Downmix Renderer window launching at {url}")
    print(f"Preferences file: {core.PREFS_PATH}")

    # Request microphone permission once during the foreground app launch.
    # Hotplug, device-refresh, and window-return paths still do non-prompting
    # device management only, so output disconnects cannot create a TCC loop.
    mic_permission = request_microphone_access()
    print(f"Microphone permission state: {mic_permission.get('state')} via {mic_permission.get('api')}")

    def stop_from_signal(signum, frame):
        core.request_shutdown(f"Launcher received signal {signum}. Shutting down.")

    for sig in (signal.SIGINT, signal.SIGTERM):
        try:
            signal.signal(sig, stop_from_signal)
        except Exception:
            pass

    server_thread = threading.Thread(target=_serve, args=(server,), daemon=True)
    server_thread.start()
    threading.Thread(target=core.client_watchdog, daemon=True).start()
    threading.Thread(target=core.monitor_audio_devices, daemon=True).start()

    window = webview.create_window(
        "Downmix Renderer",
        html=LOADING_HTML,
        width=1380,
        height=960,
        min_size=(1000, 720),
        resizable=True,
        background_color="#101114",
        text_select=True,
    )

    def _on_closed(*_args, **_kwargs):
        core.request_shutdown("Main window closed. Shutting down launcher.")
        _force_exit_after_window_close()

    native_bridge = WebViewNativeBridge(window)
    core.set_native_bridge(native_bridge)
    install_macos_cmd_m_minimize_shortcut()

    try:
        window.events.closing += _on_closed
    except Exception:
        pass
    window.events.closed += _on_closed

    def _bootstrap(window_ref):
        ok, err = _wait_for_server(url)
        if ok:
            try:
                window_ref.load_url(app_url)
                if mic_permission.get("supported") and not mic_permission.get("granted"):
                    js = """
                    setTimeout(function(){
                      alert("Microphone access is required to open the selected input device.\n\nIf you clicked Don’t Allow earlier, enable it in System Settings > Privacy & Security > Microphone for Downmix Renderer, then relaunch the app.");
                    }, 250);
                    """
                    try:
                        window_ref.evaluate_js(js)
                    except Exception:
                        pass
                return
            except Exception as exc:
                err = exc
        error_text = html.escape(repr(err) if err else "Unknown startup error")
        prefs_path = html.escape(str(core.PREFS_PATH))
        window_ref.load_html(ERROR_HTML_TEMPLATE.format(
            prefs_path=prefs_path,
            error_text=error_text,
        ))

    try:
        webview.start(_bootstrap, window, debug=False)
    finally:
        try:
            native_bridge.stop()
        except Exception:
            pass
        core.set_native_bridge(core.NullNativeBridge())
        core.request_shutdown("Application window closed. Shutting down launcher.")
        try:
            core.terminate_renderer(wait_timeout=1.5)
        except Exception:
            pass
        try:
            core.terminate_keepalive(wait_timeout=1.5)
        except Exception:
            pass
        server_thread.join(timeout=3.0)

    return 0


if __name__ == "__main__":
    raise SystemExit(main())
