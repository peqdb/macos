
const BED_LABELS = [];
const LAYOUT_PRESETS = {};
const CLIENT_ID = "test";
const EMBEDDED_MODE = false;
let disconnected = false;
let disconnectFailures = 0;
let heartbeatTimer = null;
let pollTimer = null;
let embeddedFallbackPollTimer = null;
let eventSource = null;
let eventRetryTimer = null;
let autoApplyTimer = null;
let pendingAutoApply = false;
let saveTimer = null;
let currentPhase = 'stopped';
let rendererRecoveryPending = false;
let appInitializing = true;
let missingDeviceStopInFlight = false;
let missingDeviceStopReason = '';
const CONTROLLED_STOP_MIN_VISIBLE_MS = 0;
let controlledStopHoldTimer = null;
let controlledStopHoldKey = '';
let lastAppliedControlledStopUnavailableKey = '';
let deviceSelectionRevision = 0;
let deviceRefreshRequestId = 0;
let startupInputRescanTimer = null;
let startupInputRescanAttempts = 0;
let startupInputRescanArmed = true;
const STARTUP_INPUT_RESCAN_DELAYS_MS = [500, 1200, 2500, 5000, 8000, 12000, 18000, 25000];
const START_READY_STABLE_MS = 0;
const START_READINESS_MAX_AGE_MS = 60000;
let startReadiness = { ready:true, reason:'', lastRefreshAt:Date.now(), inputEnumerated:false };
let startReadinessTimer = null;
let applyBusy = false;
let applyTransitionActive = false;
let applyTransitionIgnoreAllStatuses = false;
let applyTransitionMinRevision = null;
let logTimer = null;
let lastStatusRevision = -1;
let lastLogRevision = -1;
let meterAnimHandle = null;
let meterAnimLastTs = 0;
let lastInputDeviceSignature = '';
let lastOutputDeviceSignature = '';
let listInteractionUntil = { indev: 0, outdev: 0 };
  let missingSelectionClearedByUser = { indev: false, outdev: false };
let pendingNativeStatus = null;
let pendingNativeStatusFrame = 0;
let visualsWereSuspended = false;
window.__nativeBridgeReady = false;
const METER_FLOOR_DB = -160;
const SUM_METER_TICK_STEP_DB = 10;
const SUM_METER_LABEL_STEP_DB = 20;
const VISUAL_IDLE_SUPPRESS_DB = METER_FLOOR_DB;
const OUTPUT_READOUT_FLOOR_DB = METER_FLOOR_DB;
const METER_PEAK_HOLD_MS = 8;
const METER_RELEASE_DB_PER_SEC = 45;
// Sum meters now follow the renderer's actual stereo output meters.
// They are no longer suppressed or forced idle based on bed-input silence.
const INPUT_PEAK_HOLD_MS = METER_PEAK_HOLD_MS;
const INPUT_RELEASE_DB_PER_SEC = METER_RELEASE_DB_PER_SEC;
const INPUT_RENDER_BUCKET_DB = 0.5;
const READOUT_HYSTERESIS_DB = 0.35;
const READOUT_FAST_DELTA_DB = 0.9;
const READOUT_MIN_INTERVAL_MS = 45;
const INPUT_SILENCE_GRACE_MS = 0;
const INPUT_OFF_HOLD_MS = 95;
// Bed inputs and stereo sum meters share one silence gate so neither visual
// path can disappear earlier than the other when audio stops. The gate also
// bridges one status interval where only the input side or only the output side
// reports residual activity, so the two visual groups cannot clear separately.
const VISUAL_OFF_HOLD_MS = INPUT_OFF_HOLD_MS;
const READOUT_SILENCE_GRACE_MS = 0;
let sharedVisualSilenceSince = 0;
let sharedVisualsCleared = true;
let sharedVisualInputGroupActive = false;
let sharedVisualOutputGroupActive = false;
let holdInputBadgesWithOutput = false;
let holdSumMetersWithInputs = false;
// Bed badges are colored only by their own raw input-channel dBFS.
// Sum meters separately show the actual folded-down stereo output level.
const ACTIVE_BADGE_FALLBACK_DB = -18;
const activeBadgeState = {};
const speakerElementsByLabel = {};
const soundWaveElementsByLabel = {};
function roomPoint(label, x, y, className=''){
  return {label, x, y, className};
}
const SPEAKER_LAYOUT_916 = [
  // Clean concentric layout: the main bed channels read as a more even ring
  // around the listener, with height speakers on a balanced inner ring.
  roomPoint('C', 50, 16),
  roomPoint('L', 34, 20), roomPoint('R', 66, 20),
  roomPoint('Lw', 19, 35), roomPoint('Rw', 81, 35),
  roomPoint('Ls', 16, 50), roomPoint('Rs', 84, 50),
  roomPoint('Lrs', 28, 76), roomPoint('Rrs', 72, 76),

  // Ceiling layer, arranged as a balanced inner ring around the listener.
  roomPoint('Ltf', 40, 33, 'top'), roomPoint('Rtf', 60, 33, 'top'),
  roomPoint('Ltm', 31, 50, 'top'), roomPoint('Rtm', 69, 50, 'top'),
  roomPoint('Ltr', 40, 67, 'top'), roomPoint('Rtr', 60, 67, 'top'),

  // Non-localized LFE marker near the front center.
  roomPoint('LFE', 50, 31, 'lfe')
];
const METER_COLOR_STOPS = [
  {p:0, c:[74,124,255]},
  {p:38, c:[103,213,255]},
  {p:60, c:[111,226,108]},
  {p:72, c:[199,239,102]},
  {p:80, c:[255,209,102]},
  {p:88, c:[255,159,90]},
  {p:94, c:[255,107,99]},
  {p:100, c:[255,93,115]}
];
// The 200 ms clip latch is handled in the Python launcher state so short
// clipping events cannot be lost before the browser paints. Keep the JS latch
// at zero to avoid doubling the visible hold time.
const CLIP_LATCH_MS = 0;
const meterState = {
  L: {target: 0, current: 0, rawDb: -Infinity, latestRawDb: -Infinity, shownDb: -Infinity, displayDb: -Infinity, holdUntil: 0, lastReadoutAt: 0, silenceSince: 0, lastColorBucket: null, clipOn: false, clipUntil: 0},
  R: {target: 0, current: 0, rawDb: -Infinity, latestRawDb: -Infinity, shownDb: -Infinity, displayDb: -Infinity, holdUntil: 0, lastReadoutAt: 0, silenceSince: 0, lastColorBucket: null, clipOn: false, clipUntil: 0}
};

const $ = s => document.querySelector(s);

function installMacMinimizeShortcut(){
  document.addEventListener('keydown', (ev)=>{
    const key = String(ev.key || '').toLowerCase();
    if(!ev.metaKey || ev.shiftKey || ev.altKey || key !== 'm') return;
    ev.preventDefault();
    ev.stopPropagation();
    fetch('/api/minimize', {method:'POST', headers:{'Content-Type':'application/json'}, body:'{}'}).catch(()=>{});
  }, true);
}

function interpolateColor(percent){
  const p = Math.max(0, Math.min(100, percent));
  for(let i=1; i<METER_COLOR_STOPS.length; i++){
    const a = METER_COLOR_STOPS[i - 1];
    const b = METER_COLOR_STOPS[i];
    if(p <= b.p){
      const span = Math.max(0.0001, b.p - a.p);
      const t = (p - a.p) / span;
      return a.c.map((v, idx)=>Math.round(v + (b.c[idx] - v) * t));
    }
  }
  return METER_COLOR_STOPS[METER_COLOR_STOPS.length - 1].c.slice();
}
function colorForDb(db){
  if(!Number.isFinite(db) || db <= METER_FLOOR_DB) return null;
  return interpolateColor(meterWidthFromDb(db));
}
function maxDbText(a, b){
  const da = parseMeterDb(a);
  const db = parseMeterDb(b);
  if(!Number.isFinite(da)) return Number.isFinite(db) ? String(b) : '-inf';
  if(!Number.isFinite(db)) return String(a);
  return db > da ? String(b) : String(a);
}
function mergeLevelPeakMaps(a, b){
  const out = Object.assign({}, a || {});
  const next = b || {};
  Object.keys(next).forEach(k=>{
    out[k] = maxDbText(out[k], next[k]);
  });
  return out;
}
function mergeStatusPeakPayload(previous, next){
  if(!previous) return next || {};
  if(!next) return previous || {};
  const prevPhase = previous.phase || 'stopped';
  const nextPhase = next.phase || 'stopped';
  // For non-running transitions, latest state must win immediately so Stop,
  // errors, and disconnects are never hidden behind peak coalescing.
  if(prevPhase !== 'running' || nextPhase !== 'running') return next;

  const out = Object.assign({}, next);
  out.meter_left_db = maxDbText(previous.meter_left_db, next.meter_left_db);
  out.meter_right_db = maxDbText(previous.meter_right_db, next.meter_right_db);
  out.input_levels_db = mergeLevelPeakMaps(previous.input_levels_db, next.input_levels_db);
  out.input_transients_db = mergeLevelPeakMaps(previous.input_transients_db, next.input_transients_db);
  out.clip_left = !!previous.clip_left || !!next.clip_left;
  out.clip_right = !!previous.clip_right || !!next.clip_right;
  const labels = new Set([...(previous.active_labels || []), ...(next.active_labels || [])]);
  out.active_labels = Array.from(labels);
  return out;
}
function levelColorBucketDb(db){
  if(!Number.isFinite(db)) return -Infinity;
  return Math.round(db / INPUT_RENDER_BUCKET_DB) * INPUT_RENDER_BUCKET_DB;
}
function levelColorStyle(color){
  if(!color) return null;
  const [r,g,b] = color;
  const rgb = `${r},${g},${b}`;
  return {
    rgb,
    backgroundColor: `rgba(${rgb},0.44)`,
    // Flat fill by design: gradients scale differently on the circular bed badges
    // and the tall sum meters, which made a digital color meter read them as
    // different colors even when the base RGB was the same.
    backgroundImage: 'none',
    borderColor: `rgba(${rgb},0.88)`,
    softBorderColor: `rgba(${rgb},0.88)`,
    boxShadow: `0 0 0 1px rgba(${rgb},0.12) inset, 0 0 24px rgba(${rgb},0.26)`
  };
}


function clamp01(v){
  return Math.max(0, Math.min(1, v));
}
function sourceLevelStrength(db){
  if(!Number.isFinite(db) || db <= METER_FLOOR_DB) return 0;
  return clamp01((db - METER_FLOOR_DB) / (0 - METER_FLOOR_DB));
}
function resetSoundWaveStyle(_el){}
function applySoundWaveLevelStyle(_label, _db){}
function createSoundWaveOverlay(_stage){}
function setWaveTransientMap(_map){}
function resetWaveField(){}
function clearWaveCanvas(){}
function animateWaveEquation(_ts, _dt){}
function outputColorForDb(db){
  // Sum meters and bed badges intentionally share the same color lookup.
  // The rendered surfaces below also use the same RGBA + overlay styling, not
  // merely the same underlying RGB value.
  return colorForDb(db);
}
function finiteDbOrNegInf(v){
  return Number.isFinite(v) ? v : -Infinity;
}
function resetBadgeStyle(el){
  if(el.dataset.levelBucket === 'idle') return;
  el.dataset.levelBucket = 'idle';
  el.style.background = '';
  el.style.backgroundColor = '';
  el.style.backgroundImage = '';
  el.style.borderColor = '';
  el.style.boxShadow = '';
  el.style.color = '';
  el.style.textShadow = '';
}
function applyBadgeLevelStyle(el, db){
  const color = colorForDb(db);
  if(!color){
    resetBadgeStyle(el);
    return;
  }
  // Use the exact same 0.5 dB color bucket and rendered RGBA surface style
  // as the stereo sum meters, so equal displayed dBFS values are visually identical.
  const bucketValue = levelColorBucketDb(db);
  const bucket = bucketValue.toFixed(1);
  if(el.dataset.levelBucket === bucket) return;
  el.dataset.levelBucket = bucket;
  const style = levelColorStyle(colorForDb(bucketValue) || color);
  if(!style){
    resetBadgeStyle(el);
    return;
  }
  el.style.background = '';
  el.style.backgroundColor = style.backgroundColor;
  el.style.backgroundImage = style.backgroundImage;
  el.style.borderColor = style.borderColor;
  el.style.boxShadow = style.boxShadow;
  el.style.color = '#ffffff';
  el.style.textShadow = '0 1px 2px rgba(0,0,0,.55)';
}
function resetInputLevelState(){
  BED_LABELS.forEach(l=>{
    const st = activeBadgeState[l];
    if(st){
      st.rawDb = -Infinity;
      st.shownDb = -Infinity;
      st.holdUntil = 0;
      st.silenceSince = 0;
      st.lastFiniteDb = -Infinity;
      st.lastActiveAt = 0;
      st.lastRenderedBucket = null;
      st.lastRenderedLinkedKey = null;
      st.linkedSumSide = '';
    }
    applySoundWaveLevelStyle(l, -Infinity);
  });
}
function createSumMeter(side){
  const meter = document.createElement('div');
  meter.className = 'summeter ' + (side === 'L' ? 'left' : 'right');
  const header = document.createElement('div');
  header.className = 'sumheader';
  const title = document.createElement('div');
  title.className = 'sumtitle';
  title.textContent = side === 'L' ? 'L sum' : 'R sum';
  const clip = document.createElement('div');
  clip.className = 'meterclip';
  clip.id = 'clip' + side;
  clip.setAttribute('aria-label', side + ' sum clip indicator');
  clip.title = 'Clip indicator';
  header.appendChild(title);
  header.appendChild(clip);
  const track = document.createElement('div');
  track.className = 'metertrack';
  track.id = 'meter' + side + 'track';
  const fill = document.createElement('div');
  fill.className = 'meterfill';
  fill.id = 'meter' + side + 'fill';
  const peak = document.createElement('div');
  peak.className = 'meterpeak';
  peak.id = 'meter' + side + 'peak';
  track.appendChild(fill);
  track.appendChild(peak);
  const scale = document.createElement('div');
  scale.className = 'meterscale';
  scale.innerHTML = Array.from({length: Math.floor((0 - METER_FLOOR_DB) / SUM_METER_TICK_STEP_DB) + 1}, (_, i)=>{
    const db = -i * SUM_METER_TICK_STEP_DB;
    const pos = ((0 - db) / (0 - METER_FLOOR_DB)) * 100;
    const isLabel = (db === 0 || db === METER_FLOOR_DB || Math.abs(db) % SUM_METER_LABEL_STEP_DB === 0);
    const label = isLabel ? (db === 0 ? '0' : String(db).replace('-', '−')) : '';
    const classes = ['scaletick', isLabel ? 'major' : 'minor'];
    if(db === 0) classes.push('top');
    if(db === METER_FLOOR_DB) classes.push('bottom');
    return `<span class="${classes.join(' ')}" style="top:${pos.toFixed(4)}%">${label}</span>`;
  }).join('');
  const body = document.createElement('div');
  body.className = 'meterbody';
  body.appendChild(track);
  body.appendChild(scale);
  meter.appendChild(header);
  meter.appendChild(body);
  return meter;
}
function badges(){
  const g = $('#badges');
  if(!g) return;
  g.innerHTML = '';
  BED_LABELS.forEach(l=>{ speakerElementsByLabel[l] = []; });
  g.appendChild(createSumMeter('L'));
  g.appendChild(createSumMeter('R'));
  const stage = document.createElement('div');
  stage.className = 'layoutstage';
  g.appendChild(stage);
  // The reference-style spacing is kept, but the extra frame/rail/ceiling guide
  // lines are intentionally omitted so the bed visualizer reads as clean floating
  // channel badges rather than a boxed diagram.
  BED_LABELS.forEach(l=>{
    activeBadgeState[l] = {rawDb: -Infinity, shownDb: -Infinity, holdUntil: 0, silenceSince: 0, lastFiniteDb: -Infinity, lastActiveAt: 0, lastRenderedBucket: null, lastRenderedLinkedKey: null, linkedSumSide: ''};
  });
  const listener = document.createElement('div');
  listener.className = 'listenerdot';
  listener.title = 'Listener';
  listener.innerHTML = '<div class="listenerheadtop" aria-hidden="true"><div class="ear left"></div><div class="ear right"></div><div class="skull"></div><div class="nose"></div></div>';
  stage.appendChild(listener);
  SPEAKER_LAYOUT_916.forEach((sp, idx)=>{
    const d = document.createElement('div');
    d.className = 'badge' + (sp.className ? ' ' + sp.className : '');
    d.id = sp.label === 'LFE' ? ('b_LFE_' + idx) : ('b_' + sp.label);
    d.dataset.bed = sp.label;
    d.textContent = sp.display || sp.label;
    d.title = sp.label === 'LFE' ? 'LFE channel, shown separately because it is not a localized bed speaker' : sp.label;
    d.style.left = sp.x + '%';
    d.style.top = sp.y + '%';
    stage.appendChild(d);
    speakerElementsByLabel[sp.label] = speakerElementsByLabel[sp.label] || [];
    speakerElementsByLabel[sp.label].push(d);
  });
}
function setActiveInputs(labels, running=true){
  if(!running){
    setInputLevels({}, false);
    return;
  }
  const fallback = {};
  BED_LABELS.forEach(l=>{ fallback[l] = '-inf'; });
  (labels || []).forEach(l=>{ fallback[l] = String(ACTIVE_BADGE_FALLBACK_DB); });
  setInputLevels(fallback, true);
}
function inputLevelsHaveVisibleSignal(levelMap){
  if(!levelMap) return false;
  return BED_LABELS.some(l=>{
    const value = Object.prototype.hasOwnProperty.call(levelMap, l) ? levelMap[l] : '-inf';
    const db = parseMeterDb(value);
    return Number.isFinite(db) && db > VISUAL_IDLE_SUPPRESS_DB;
  });
}
function activeLabelsHaveVisibleSignal(labels){
  return Array.isArray(labels) && labels.some(l=>BED_LABELS.includes(l));
}
function outputMetersHaveVisibleSignal(j){
  if(!j) return false;
  const l = parseMeterDb(j.meter_left_db || '-inf');
  const r = parseMeterDb(j.meter_right_db || '-inf');
  return (Number.isFinite(l) && l > VISUAL_IDLE_SUPPRESS_DB) ||
         (Number.isFinite(r) && r > VISUAL_IDLE_SUPPRESS_DB);
}
function statusVisualSignalFlags(j){
  if(!j) return {inputActive:false, outputActive:false, anyActive:false};
  const inputLevels = j.input_levels_db || null;
  const inputActive = inputLevels
    ? inputLevelsHaveVisibleSignal(inputLevels)
    : activeLabelsHaveVisibleSignal(j.active_labels || []);
  const outputActive = outputMetersHaveVisibleSignal(j);
  return {
    inputActive,
    outputActive,
    anyActive: inputActive || outputActive
  };
}
function statusHasVisibleSignal(j){
  return statusVisualSignalFlags(j).anyActive;
}
function updateSharedVisualGate(flags){
  const now = Date.now();
  const state = (typeof flags === 'object' && flags)
    ? flags
    : {inputActive:!!flags, outputActive:!!flags, anyActive:!!flags};
  sharedVisualInputGroupActive = !!state.inputActive;
  sharedVisualOutputGroupActive = !!state.outputActive;
  // If only one visual group still reports activity, keep the other group
  // enrolled in the shared clear gate. Do not freeze its dB value here; the
  // animation loop must keep releasing it so transients never get stuck.
  holdInputBadgesWithOutput = sharedVisualOutputGroupActive && !sharedVisualInputGroupActive;
  holdSumMetersWithInputs = sharedVisualInputGroupActive && !sharedVisualOutputGroupActive;
  if(state.anyActive){
    sharedVisualSilenceSince = 0;
    sharedVisualsCleared = false;
    return true;
  }
  holdInputBadgesWithOutput = false;
  holdSumMetersWithInputs = false;
  if(!sharedVisualSilenceSince){
    sharedVisualSilenceSince = now;
  }
  return (now - sharedVisualSilenceSince) < VISUAL_OFF_HOLD_MS;
}
function sharedVisualHoldOn(now=Date.now()){
  return !sharedVisualSilenceSince || (now - sharedVisualSilenceSince) < VISUAL_OFF_HOLD_MS;
}
function clearSharedVisuals(now=Date.now()){
  if(sharedVisualsCleared) return;
  holdInputBadgesWithOutput = false;
  holdSumMetersWithInputs = false;
  sharedVisualInputGroupActive = false;
  sharedVisualOutputGroupActive = false;
  resetInputLevelState();
  renderActiveBadges(now, 0);
  ['L','R'].forEach(side=>{
    resetMeter(side);
    renderMeter(side, 0);
  });
  sharedVisualsCleared = true;
}
function setInputLevels(levelMap, running=true){
  const now = Date.now();
  if(!running){
    resetInputLevelState();
    renderActiveBadges(now, 0);
    return;
  }
  const parsedByLabel = {};
  BED_LABELS.forEach(l=>{
    const value = (levelMap && Object.prototype.hasOwnProperty.call(levelMap, l)) ? levelMap[l] : '-inf';
    const parsedInputDb = parseMeterDb(value);
    parsedByLabel[l] = Number.isFinite(parsedInputDb) ? parsedInputDb : -Infinity;
  });
  let anyActiveInput = false;
  BED_LABELS.forEach(l=>{
    const st = activeBadgeState[l];
    if(!st) return;
    const parsedInputDb = parsedByLabel[l];
    // Bed badges must always represent raw input-channel levels.
    // They intentionally do not borrow the rendered stereo-sum level or color,
    // even for direct L-only/R-only/stereo playback.
    const displayDb = parsedInputDb;
    const activeNow = Number.isFinite(parsedInputDb) && parsedInputDb > VISUAL_IDLE_SUPPRESS_DB;
    st.inputDb = finiteDbOrNegInf(parsedInputDb);
    st.linkedSumSide = '';
    st.rawDb = activeNow ? displayDb : -Infinity;
    if(activeNow){
      anyActiveInput = true;
      st.silenceSince = 0;
      st.lastActiveAt = now;
      // Do not overwrite a held transient with the next lower raw packet.
      // The bed badge must still be sourced from the raw input channel, but
      // it should use the same peak-hold/release envelope as the sum meters.
      if(!Number.isFinite(st.shownDb) || displayDb > st.shownDb){
        st.shownDb = displayDb;
        st.holdUntil = now + INPUT_PEAK_HOLD_MS;
        st.lastFiniteDb = displayDb;
      }
    }else if(Number.isFinite(st.shownDb) || Number.isFinite(st.lastFiniteDb)){
      // Preserve the current rendered value as the release start point only.
      // The animation loop will continue decaying it while the shared visual
      // gate decides when both the bed badges and sum meters clear together.
      if(!Number.isFinite(st.shownDb)) st.shownDb = st.lastFiniteDb;
      st.rawDb = -Infinity;
      if(!st.silenceSince) st.silenceSince = now;
    }else{
      st.shownDb = -Infinity;
      st.lastFiniteDb = -Infinity;
      st.lastActiveAt = 0;
      st.holdUntil = 0;
      st.silenceSince = 0;
    }
  });
  renderActiveBadges(now, 0);
}
function renderActiveBadges(now=Date.now(), dt=0.016){
  BED_LABELS.forEach(l=>{
    const st = activeBadgeState[l] || {rawDb:-Infinity, shownDb:-Infinity, holdUntil:0, linkedSumSide:''};
    if(Number.isFinite(st.rawDb) && (!Number.isFinite(st.shownDb) || st.rawDb > st.shownDb)){
      st.shownDb = st.rawDb;
      st.holdUntil = now + INPUT_PEAK_HOLD_MS;
      st.lastFiniteDb = st.shownDb;
      st.lastActiveAt = now;
    }else if(Number.isFinite(st.shownDb) && now >= (st.holdUntil || 0)){
      const releaseTarget = Number.isFinite(st.rawDb) ? Math.max(st.rawDb, METER_FLOOR_DB) : METER_FLOOR_DB;
      st.shownDb = Math.max(releaseTarget, st.shownDb - INPUT_RELEASE_DB_PER_SEC * Math.max(0, dt || 0));
      st.lastFiniteDb = st.shownDb;
      if(st.shownDb <= METER_FLOOR_DB + 0.05 && !Number.isFinite(st.rawDb) && !sharedVisualHoldOn(now) && !holdInputBadgesWithOutput){
        st.shownDb = -Infinity;
        st.lastFiniteDb = -Infinity;
        st.lastActiveAt = 0;
      }
    }
    const renderDb = st.shownDb;
    const on = Number.isFinite(renderDb) && renderDb > METER_FLOOR_DB;
    const bucket = on ? String(Math.round(renderDb / INPUT_RENDER_BUCKET_DB) * INPUT_RENDER_BUCKET_DB) : 'idle';
    if(st.lastRenderedBucket === bucket) return;
    st.lastRenderedBucket = bucket;
    applySoundWaveLevelStyle(l, on ? renderDb : -Infinity);
    const nodes = speakerElementsByLabel[l] || [];
    nodes.forEach(el=>{
      const base = 'badge' + (el.classList.contains('lfe') ? ' lfe' : '') + (el.classList.contains('top') ? ' top' : '');
      const nextClass = base + (on ? ' on' : '');
      if(el.className !== nextClass) el.className = nextClass;
      applyBadgeLevelStyle(el, renderDb);
      const levelText = on ? `${formatMeterDb(renderDb)} dBFS input` : '-inf dBFS';
      const title = el.dataset.bed === 'LFE'
        ? `LFE channel, shown separately because it is not a localized bed speaker
${levelText}`
        : `${el.dataset.bed}
${levelText}`;
      if(el.title !== title) el.title = title;
    });
  });
}
function updateLfeToggleCopy(){
  const lowpass = $('#lfe_lowpass');
  const label = $('#lfe_mode_label');
  const hint = $('#lfe_mode_hint');
  if(!lowpass || !label || !hint) return;
  if(lowpass.checked){
    label.textContent = 'Butterworth 125 Hz low-pass';
    hint.textContent = '24 dB/oct, fixed 172-sample dry delay';
  }else{
    label.textContent = 'Dry ADC2 direct LFE';
    hint.textContent = 'no low-pass';
  }
}
function fillPresets(){
  const p = $('#preset_display');
  if(p) p.value = '9.1.6 bed (1:1)';
}
function applyPreset(save=true){
  if(save) scheduleSavePrefs();
}
function parseMeterDb(dbText){
  if(dbText === undefined || dbText === null) return -Infinity;
  const text = String(dbText).trim().toLowerCase();
  if(text === '' || text === '-inf' || text === '-infinity') return -Infinity;
  const db = Number(text);
  return Number.isFinite(db) ? db : -Infinity;
}
function formatMeterDb(db){
  if(!Number.isFinite(db) || db <= METER_FLOOR_DB) return '-inf';
  return db.toFixed(1);
}
function formatOutputMeterDb(db){
  if(!Number.isFinite(db)) return '-inf';
  // Treat values below the display floor as silence. This avoids showing
  // "< -120" when the renderer is running but nothing is actually playing.
  if(db < OUTPUT_READOUT_FLOOR_DB) return '-inf';
  return db.toFixed(1);
}
function meterWidthFromDb(db){
  if(!Number.isFinite(db)) return 0;
  if(db >= 0) return 100;
  if(db <= METER_FLOOR_DB) return 0;
  // Linear dB mapping: the configured floor is the bottom and 0 dBFS is the top.
  return ((db - METER_FLOOR_DB) / (0 - METER_FLOOR_DB)) * 100;
}
function meterWidth(dbText){
  return meterWidthFromDb(parseMeterDb(dbText));
}
function updateMeterReadout(side, force=false){
  const clip = $('#clip' + side);
  const m = meterState[side];
  const now = Date.now();
  const on = !!(m && (m.clipOn || now < m.clipUntil));
  if(clip){
    const nextClass = 'meterclip' + (on ? ' on' : '');
    if(force || clip.className !== nextClass) clip.className = nextClass;
  }
}


function renderMeter(side, percent){
  const fill = $('#meter' + side + 'fill');
  const track = $('#meter' + side + 'track');
  const peak = $('#meter' + side + 'peak');
  const m = meterState[side];
  if(!fill || !track || !peak || !m) return;
  const shown = Math.max(0, Math.min(100, percent));
  fill.style.transform = `scaleY(${(shown / 100).toFixed(4)})`;
  fill.style.opacity = shown <= 0.1 ? '0' : '1';
  // Use the exact same color bucket and rendered RGBA surface style as the
  // bed input badges. This avoids the previous mismatch where the sum fill was
  // solid RGB but the badges were translucent RGBA with an overlay.
  const colorBucket = Number.isFinite(m.shownDb) ? levelColorBucketDb(m.shownDb) : -Infinity;
  const color = outputColorForDb(colorBucket);
  const style = levelColorStyle(color);
  const rgb = style ? style.rgb : 'idle';
  if(track.dataset.rgb !== rgb){
    track.dataset.rgb = rgb;
    if(style){
      // Use the same rendered surface treatment as the bed badges so the sum
      // meters look perceptually identical, not just numerically mapped to the
      // same RGB values.
      fill.style.backgroundColor = style.backgroundColor;
      fill.style.backgroundImage = style.backgroundImage;
      fill.style.backgroundBlendMode = 'normal';
      fill.style.boxShadow = style.boxShadow;
      track.style.borderColor = style.softBorderColor;
      track.style.boxShadow = `inset 0 0 0 1px rgba(255,255,255,.025), inset 0 0 18px rgba(0,0,0,.55), 0 0 20px rgba(${style.rgb},0.14)`;
    }else{
      fill.style.backgroundColor = 'transparent';
      fill.style.backgroundImage = '';
      fill.style.boxShadow = 'none';
      track.style.borderColor = '#323640';
      track.style.boxShadow = 'inset 0 0 0 1px rgba(255,255,255,.025), inset 0 0 18px rgba(0,0,0,.55)';
    }
  }
  updateMeterReadout(side);
}
function animateMeters(ts){
  if(document.hidden){
    meterAnimLastTs = 0;
    meterAnimHandle = requestAnimationFrame(animateMeters);
    return;
  }
  if(!meterAnimLastTs) meterAnimLastTs = ts;
  const dt = Math.min(0.05, Math.max(0.001, (ts - meterAnimLastTs) / 1000));
  meterAnimLastTs = ts;
  const now = Date.now();
  if(sharedVisualSilenceSince && !sharedVisualHoldOn(now)){
    clearSharedVisuals(now);
    meterAnimHandle = requestAnimationFrame(animateMeters);
    return;
  }
  renderActiveBadges(now, dt);
  animateWaveEquation(ts, dt);
  for(const side of ['L', 'R']){
    const m = meterState[side];
    const rawDb = m.rawDb;
    if(Number.isFinite(rawDb) && (!Number.isFinite(m.shownDb) || rawDb > m.shownDb)){
      m.shownDb = rawDb;
      m.holdUntil = now + METER_PEAK_HOLD_MS;
    }else if(now >= m.holdUntil){
      const releaseTarget = Number.isFinite(rawDb) ? Math.max(rawDb, METER_FLOOR_DB) : METER_FLOOR_DB;
      if(Number.isFinite(m.shownDb)){
        m.shownDb = Math.max(releaseTarget, m.shownDb - METER_RELEASE_DB_PER_SEC * dt);
        if(m.shownDb <= METER_FLOOR_DB + 0.05 && (!Number.isFinite(rawDb) || rawDb <= METER_FLOOR_DB)){
          m.shownDb = -Infinity;
        }
      }else if(Number.isFinite(rawDb)){
        m.shownDb = rawDb;
      }
    }
    m.target = meterWidthFromDb(m.shownDb);
    m.current = m.target;
    renderMeter(side, m.current);
  }
  meterAnimHandle = requestAnimationFrame(animateMeters);
}
function scheduleNextPoll(){
  if(disconnected) return;
  pollTimer = setTimeout(poll, 0);
}
function setMeter(side, dbText, clipped){
  const m = meterState[side];
  const now = Date.now();
  const parsedRawDb = parseMeterDb(dbText);
  const parsedDb = (Number.isFinite(parsedRawDb) && parsedRawDb > VISUAL_IDLE_SUPPRESS_DB) ? parsedRawDb : -Infinity;
  m.latestRawDb = parsedDb;
  let rawDb = parsedDb;
  if(Number.isFinite(parsedDb)){
    m.silenceSince = 0;
  }else{
    if(!m.silenceSince) m.silenceSince = now;
    // Keep rawDb at -Infinity during silent/shared-hold periods. The previous
    // implementation copied shownDb back into rawDb, which made the release
    // target equal the current value and caused transient fades to freeze.
    rawDb = -Infinity;
  }
  m.rawDb = rawDb;
  if(Number.isFinite(rawDb) && (!Number.isFinite(m.shownDb) || rawDb > m.shownDb)){
    m.shownDb = rawDb;
    m.holdUntil = now + METER_PEAK_HOLD_MS;
    m.target = meterWidthFromDb(m.shownDb);
    m.current = m.target;
  }
  if(document.hidden){
    // requestAnimationFrame can be paused while the renderer tab is hidden.
    // Still paint active status packets into the DOM so returning to the tab
    // shows the current meter state immediately instead of an empty meter that
    // fills only after the first foreground frame/status refresh.
    m.shownDb = (Number.isFinite(rawDb) && rawDb > METER_FLOOR_DB) ? rawDb : -Infinity;
    m.holdUntil = Number.isFinite(m.shownDb) ? now + METER_PEAK_HOLD_MS : 0;
    m.target = meterWidthFromDb(m.shownDb);
    m.current = m.target;
    renderMeter(side, m.current);
  }
  m.clipOn = !!clipped;
  if(clipped) m.clipUntil = now + CLIP_LATCH_MS;
  updateMeterReadout(side);
}
function resetMeter(side){
  const m = meterState[side];
  m.rawDb = -Infinity;
  m.latestRawDb = -Infinity;
  m.shownDb = -Infinity;
  m.displayDb = -Infinity;
  m.holdUntil = 0;
  m.target = 0;
  m.current = 0;
  m.lastReadoutAt = 0;
  m.silenceSince = 0;
  m.lastColorBucket = null;
  m.clipOn = false;
  m.clipUntil = 0;
  renderMeter(side, 0);
  updateMeterReadout(side, true);
  const clip = $('#clip' + side);
  if(clip){
    clip.className = 'meterclip';
  }
}
function snapVisualsToLatestRawState(){
  const now = Date.now();
  BED_LABELS.forEach(l=>{
    const st = activeBadgeState[l];
    if(!st) return;
    st.shownDb = Number.isFinite(st.rawDb) ? st.rawDb : -Infinity;
    st.holdUntil = 0;
    st.silenceSince = 0;
    st.lastFiniteDb = Number.isFinite(st.rawDb) ? st.rawDb : -Infinity;
    st.lastActiveAt = Number.isFinite(st.rawDb) ? now : 0;
    st.linkedSumSide = '';
    st.lastRenderedBucket = null;
    st.lastRenderedLinkedKey = null;
  });
  renderActiveBadges(now, 0);
  for(const side of ['L', 'R']){
    const m = meterState[side];
    if(!m) continue;
    const rawDb = m.rawDb;
    m.latestRawDb = rawDb;
    m.shownDb = (Number.isFinite(rawDb) && rawDb > METER_FLOOR_DB) ? rawDb : -Infinity;
    m.holdUntil = 0;
    m.silenceSince = 0;
    m.target = meterWidthFromDb(m.shownDb);
    m.current = m.target;
    renderMeter(side, m.current);
  }
  meterAnimLastTs = 0;
}
async function refreshStatusAndSnapVisuals(){
  try{
    const r = await fetch('/api/status', {cache:'no-store'});
    if(r.ok) applyStatusPayload(await r.json());
  }catch(e){}
  snapVisualsToLatestRawState();
}
function forceIdleVisualState(){
  sharedVisualSilenceSince = 0;
  sharedVisualsCleared = true;
  sharedVisualInputGroupActive = false;
  sharedVisualOutputGroupActive = false;
  holdInputBadgesWithOutput = false;
  holdSumMetersWithInputs = false;
  setWaveTransientMap({});
  setActiveInputs([], false);
  resetWaveField();
  resetMeter('L');
  resetMeter('R');
}
function isUnavailableDeviceMessage(msg){
  const text = String(msg || '').trim();
  return text === 'Selected output device is unavailable.' ||
         text === 'Selected input device is unavailable or does not expose at least 16 input channels.' ||
         text === 'Select both an input device and an output device.';
}
function normalizeRunPhase(phase, msg){
  const requested = String(phase || 'stopped').trim() || 'stopped';
  if(requested === 'error' && isUnavailableDeviceMessage(msg)) return 'stopped';
  return requested;
}
function setRunState(phase, msg){
  phase = normalizeRunPhase(phase, msg);
  currentPhase = phase || 'stopped';
  if(currentPhase === 'running' || currentPhase === 'error' || currentPhase === 'disconnected' || currentPhase === 'stopped'){
    applyTransitionActive = false;
    applyTransitionIgnoreAllStatuses = false;
    applyTransitionMinRevision = null;
  }
  if(currentPhase !== 'running'){
    forceIdleVisualState();
  }
  const pill = $('#runstate');
  const text = $('#runtext');
  pill.className = 'pill ' + currentPhase;
  const labels = {
    stopped: 'Stopped',
    starting: 'Starting…',
    running: 'Running',
    stopping: 'Stopping…',
    error: 'Error',
    disconnected: 'Disconnected'
  };
  text.textContent = labels[currentPhase] || currentPhase;
  $('#statusmsg').textContent = msg || '';
  // Keep the transport buttons derived from the single currentPhase state.
  // Previously some direct setRunState('stopped', ...) paths updated the pill
  // without recomputing disabled states, so Stop could remain visually enabled
  // after a hot-unplug stop.
  updateStartButtonState();
}
async function waitForPhases(phases, timeoutMs=4000, applyPayload=true){
  const wanted = new Set(phases);
  const start = Date.now();
  while(Date.now() - start < timeoutMs){
    try{
      const r = await fetch('/api/status', {cache:'no-store'});
      if(!r.ok) throw new Error('status fetch failed');
      const j = await r.json();
      if(wanted.has(j.phase)){
        if(applyPayload) applyStatusPayload(j);
        return j;
      }
    }catch(e){}
    await new Promise(resolve => setTimeout(resolve, 80));
  }
  throw new Error('Timed out waiting for renderer state change.');
}
async function applyPresetAndRestart(){
  if(applyBusy){
    pendingAutoApply = true;
    return;
  }
  applyBusy = true;
  try{
    applyPreset(false);
    const validationError = getSelectionValidationError();
    if(validationError){
      markUnavailableFromStatusText(validationError);
      setRunState('stopped', validationError);
      updateStartButtonState();
      return;
    }
    const payload = currentPayload();
    const shouldRestart = currentPhase === 'running' || currentPhase === 'starting' || currentPhase === 'stopping';
    applyTransitionActive = shouldRestart;
    applyTransitionIgnoreAllStatuses = shouldRestart;
    applyTransitionMinRevision = lastStatusRevision;
    setRunState('starting', shouldRestart ? 'Restarting renderer with updated settings…' : 'Starting renderer with applied settings…');
    $('#start').disabled = true;
    $('#stop').disabled = true;
    const r = await fetch('/api/apply', {
      method:'POST',
      headers:{'Content-Type':'application/json'},
      body: JSON.stringify(payload)
    });
    const j = await r.json();
    if(!j.ok){
      applyTransitionActive = false;
      applyTransitionIgnoreAllStatuses = false;
      const message = j.error || 'Could not apply renderer changes.';
      try{
        const statusResp = await fetch('/api/status', {cache:'no-store'});
        if(statusResp.ok){
          const latestStatus = await statusResp.json();
          if(latestStatus && latestStatus.status_text && ['error','stopped'].includes(latestStatus.phase || '')){
            applyStatusPayload(latestStatus);
          }else{
            setRunState(j.phase || 'error', message);
          }
        }else{
          setRunState('error', message);
        }
      }catch(_e){
        setRunState('error', message);
      }
      return;
    }
    await refreshLog();
    try{
      const statusResp = await fetch('/api/status', {cache:'no-store'});
      if(statusResp.ok){
        const finalStatus = await statusResp.json();
        applyTransitionActive = false;
        applyTransitionIgnoreAllStatuses = false;
        applyStatusPayload(finalStatus);
      }else{
        applyTransitionActive = false;
        applyTransitionIgnoreAllStatuses = false;
      }
    }catch(_e){
      applyTransitionActive = false;
      applyTransitionIgnoreAllStatuses = false;
    }
  }catch(e){
    applyTransitionActive = false;
    applyTransitionIgnoreAllStatuses = false;
    const message = e && e.message ? e.message : 'Could not apply preset.';
    setRunState(isUnavailableDeviceMessage(message) ? 'stopped' : 'error', message);
  }finally{
    applyBusy = false;
    if(pendingAutoApply){
      pendingAutoApply = false;
      setTimeout(()=>{ applyPresetAndRestart(); }, 0);
    }
  }
}
function shouldAutoApply(){
  return currentPhase === 'running' || currentPhase === 'starting';
}
function queueAutoApply(delayMs=60){
  if(!shouldAutoApply()) return;
  clearTimeout(autoApplyTimer);
  autoApplyTimer = setTimeout(()=>{
    autoApplyTimer = null;
    if(!shouldAutoApply()) return;
    applyPresetAndRestart();
  }, Math.max(0, delayMs|0));
}
function bindApplyOnCommit(inputEl, options={}){
  if(!inputEl) return;
  const normalizeBeforeCommit = typeof options.normalizeBeforeCommit === 'function' ? options.normalizeBeforeCommit : null;
  const onCommit = typeof options.onCommit === 'function' ? options.onCommit : null;
  const committedValueFor = ()=> inputEl.type === 'checkbox' ? String(!!inputEl.checked) : String(inputEl.value ?? '');
  const syncCommittedValue = ()=>{
    inputEl.__lastCommittedValue = committedValueFor();
  };
  const maybeApply = ()=>{
    if(normalizeBeforeCommit) normalizeBeforeCommit(inputEl);
    const currentValue = committedValueFor();
    const lastCommittedValue = String(inputEl.__lastCommittedValue ?? '');
    if(currentValue === lastCommittedValue) return;
    inputEl.__lastCommittedValue = currentValue;
    if(onCommit) onCommit(inputEl);
    queueAutoApply(0);
  };
  inputEl.__syncCommittedValue = syncCommittedValue;
  syncCommittedValue();
  inputEl.addEventListener('keydown', (ev)=>{
    if(ev.key !== 'Enter') return;
    if(String(inputEl.tagName || '').toLowerCase() === 'textarea') return;
    ev.preventDefault();
    maybeApply();
  });
  inputEl.addEventListener('blur', ()=>{
    maybeApply();
  });
  inputEl.addEventListener('change', ()=>{
    maybeApply();
  });
}
function syncApplyCommitValues(){
  [$('#frames'), $('#input_latency_ms'), $('#output_latency_ms'), $('#preamp'), $('#lfe_lowpass'), $('#swap_outputs'), $('#global_output_peq_text'), $('#speaker_output_peq_text')].forEach((inputEl)=>{
    if(inputEl && typeof inputEl.__syncCommittedValue === 'function'){
      inputEl.__syncCommittedValue();
    }
  });
}
function inputValueIsApplyable(inputEl){
  if(!inputEl) return false;
  const tag = String(inputEl.tagName || '').toLowerCase();
  if(tag === 'textarea') return true;
  if(inputEl.type === 'number'){
    const text = String(inputEl.value ?? '').trim();
    if(text === '') return false;
    if(inputEl.validity && !inputEl.validity.valid) return false;
    return Number.isFinite(Number(text));
  }
  return true;
}
function bindApplyWhileEditing(inputEl, delayMs=250){
  if(!inputEl) return;
  let timer = null;
  inputEl.addEventListener('input', ()=>{
    if(!shouldAutoApply()) return;
    clearTimeout(timer);
    timer = setTimeout(()=>{
      timer = null;
      if(!shouldAutoApply()) return;
      if(!inputValueIsApplyable(inputEl)) return;

      // Keep the commit tracker in sync so the later blur/change event does
      // not launch a duplicate restart for the same value. This also fixes a
      // race where an EQ textarea blur can start an apply, then a preamp edit
      // made during that restart is only saved to preferences and never queued
      // for the live renderer until the user manually stops and starts again.
      if(typeof inputEl.__syncCommittedValue === 'function'){
        inputEl.__syncCommittedValue();
      }
      queueAutoApply(0);
    }, Math.max(0, delayMs|0));
  });
}
function normalizeRoutingPeqProfiles(value){
  const clean = {};
  if(!value || typeof value !== 'object' || Array.isArray(value)) return clean;
  Object.keys(value).sort((a,b)=>a.localeCompare(b)).forEach((name)=>{
    const key = String(name || '').trim();
    const item = value[name];
    if(!key || !item || typeof item !== 'object' || Array.isArray(item)) return;
    clean[key] = {
      swap_outputs: item.swap_outputs === true || String(item.swap_outputs).toLowerCase() === 'true',
      global_output_peq_text: String(item.global_output_peq_text || ''),
      speaker_output_peq_text: String(item.speaker_output_peq_text || '')
    };
  });
  return clean;
}
function routingPeqSnapshot(){
  return {
    swap_outputs: !!$('#swap_outputs').checked,
    global_output_peq_text: $('#global_output_peq_text').value,
    speaker_output_peq_text: $('#speaker_output_peq_text').value
  };
}
function applyRoutingPeqSnapshot(profile){
  if(!profile || typeof profile !== 'object') return false;
  $('#swap_outputs').checked = profile.swap_outputs === true || String(profile.swap_outputs).toLowerCase() === 'true';
  $('#global_output_peq_text').value = String(profile.global_output_peq_text || '');
  $('#speaker_output_peq_text').value = String(profile.speaker_output_peq_text || '');
  syncApplyCommitValues();
  return true;
}
function selectedRoutingPeqProfileName(){
  const selected = ($('#routing_peq_profile_select') && $('#routing_peq_profile_select').value || '').trim();
  const typed = ($('#routing_peq_profile_name') && $('#routing_peq_profile_name').value || '').trim();
  return typed || selected;
}
function renderRoutingPeqProfiles(){
  const select = $('#routing_peq_profile_select');
  const nameInput = $('#routing_peq_profile_name');
  if(!select) return;
  const names = Object.keys(routingPeqProfiles).sort((a,b)=>a.localeCompare(b));
  select.innerHTML = '';
  const empty = document.createElement('option');
  empty.value = '';
  empty.textContent = names.length ? 'Choose a profile...' : 'No saved profiles';
  select.appendChild(empty);
  names.forEach((name)=>{
    const opt = document.createElement('option');
    opt.value = name;
    opt.textContent = name;
    select.appendChild(opt);
  });
  if(activeRoutingPeqProfile && routingPeqProfiles[activeRoutingPeqProfile]){
    select.value = activeRoutingPeqProfile;
  }else{
    activeRoutingPeqProfile = '';
    select.value = '';
  }
  if(nameInput && document.activeElement !== nameInput){
    nameInput.value = activeRoutingPeqProfile || '';
  }
  const hasSelection = !!select.value;
  const loadBtn = $('#load_routing_peq_profile');
  const delBtn = $('#delete_routing_peq_profile');
  if(loadBtn) loadBtn.disabled = !hasSelection;
  if(delBtn) delBtn.disabled = !hasSelection;
}
function saveRoutingPeqProfile(){
  const name = selectedRoutingPeqProfileName();
  if(!name){
    window.alert('Enter a profile name first.');
    return;
  }
  routingPeqProfiles[name] = routingPeqSnapshot();
  activeRoutingPeqProfile = name;
  renderRoutingPeqProfiles();
  savePrefsNow();
}
function loadRoutingPeqProfile(){
  const select = $('#routing_peq_profile_select');
  const name = select ? String(select.value || '').trim() : '';
  if(!name || !routingPeqProfiles[name]) return;
  activeRoutingPeqProfile = name;
  applyRoutingPeqSnapshot(routingPeqProfiles[name]);
  renderRoutingPeqProfiles();
  savePrefsNow();
  queueAutoApply(0);
}
function deleteRoutingPeqProfile(){
  const select = $('#routing_peq_profile_select');
  const name = select ? String(select.value || '').trim() : '';
  if(!name || !routingPeqProfiles[name]) return;
  if(!window.confirm(`Delete profile "${name}"?`)) return;
  delete routingPeqProfiles[name];
  if(activeRoutingPeqProfile === name) activeRoutingPeqProfile = '';
  renderRoutingPeqProfiles();
  savePrefsNow();
}
function markListInteracting(kind, holdMs=900){
  listInteractionUntil[kind] = Date.now() + Math.max(0, holdMs|0);
}
function isListInteracting(kind){
  return Date.now() < (listInteractionUntil[kind] || 0);
}

function preampPayloadValue(){
  const text = String($('#preamp').value ?? '').trim();
  return text === '' ? '0' : text;
}
function normalizePreampEmptyToZero(inputEl=$('#preamp')){
  if(!inputEl) return false;
  const text = String(inputEl.value ?? '').trim();
  if(text !== '') return false;
  inputEl.value = '0';
  return true;
}
function currentPayload(){
  return {
    exe: $('#exe').value.trim(),
    preset: '9.1.6 bed (1:1)',
    frames: $('#frames').value.trim(),
    input_latency_ms: $('#input_latency_ms').value.trim(),
    output_latency_ms: $('#output_latency_ms').value.trim(),
    keep_output_alive: !!$('#keep_output_alive').checked,
    input_channels: '16',
    threshold: '-160',
    preamp_db: preampPayloadValue(),
    lfe_lowpass: !!$('#lfe_lowpass').checked,
    swap_outputs: !!$('#swap_outputs').checked,
    global_output_peq_text: $('#global_output_peq_text').value,
    speaker_output_peq_text: $('#speaker_output_peq_text').value,
    routing_peq_profiles: routingPeqProfiles,
    active_routing_peq_profile: activeRoutingPeqProfile,
    input_device: $('#indev').value,
    output_device: $('#outdev').value,
    input_device_name: $('#indev').dataset.name || '',
    output_device_name: $('#outdev').dataset.name || '',
    input_collapsed: !document.getElementById('indevdetails').open,
    output_collapsed: !document.getElementById('outdevdetails').open,
    settings_collapsed: !document.getElementById('renderersettingsdetails').open,
    routing_peq_collapsed: !document.getElementById('routingpeqdetails').open,
    visualizer_collapsed: !document.getElementById('visualizerdetails').open,
    log_collapsed: !document.getElementById('logdetails').open,
    map: (LAYOUT_PRESETS['9.1.6 bed (1:1)'] || []).map(v => String(v)),
  };
}
function getSelectionValidationError(){
  const inputEl = $('#indev');
  const outputEl = $('#outdev');
  const inputName = (inputEl.dataset.name || '').trim();
  const outputName = (outputEl.dataset.name || '').trim();
  const inputValue = String(inputEl.value || '').trim();
  const outputValue = String(outputEl.value || '').trim();
  if(!inputValue && !inputName) return 'Select an input device.';
  if(!outputValue && !outputName) return 'Select an output device.';
  if(inputEl.dataset.missing === '1' || (inputName && !inputValue)){
    return 'Selected input device is unavailable or does not expose at least 16 input channels.';
  }
  if(outputEl.dataset.missing === '1' || (outputName && !outputValue)){
    return 'Selected output device is unavailable.';
  }
  return '';
}

function selectedDevicesSignature(){
  const inputEl = $('#indev');
  const outputEl = $('#outdev');
  return JSON.stringify({
    input: String(inputEl.value || ''),
    inputName: String(inputEl.dataset.name || ''),
    output: String(outputEl.value || ''),
    outputName: String(outputEl.dataset.name || '')
  });
}
function updateStartButtonState(){
  const startBtn = $('#start');
  const stopBtn = $('#stop');
  if(!startBtn || !stopBtn) return;
  startBtn.textContent = 'Start';
  const busyPhase = rendererRecoveryPending || currentPhase === 'running' || currentPhase === 'starting' || currentPhase === 'stopping' || currentPhase === 'disconnected';
  if(appInitializing || busyPhase){
    startBtn.disabled = true;
  }else{
    // Start should be available whenever the currently selected devices are
    // present in the UI. Do not gate Start behind an artificial post-hotplug
    // settling timer or a stale "readiness" packet. The backend still resolves
    // the selected devices immediately before launch and reports a real error if
    // the output disappears between the click and process start.
    const validationError = getSelectionValidationError();
    startBtn.disabled = !!validationError;
  }
  // Start stays locked during Core Audio recovery, but Stop must remain
  // available so a failed hotplug restart can be cancelled by the user.
  stopBtn.disabled = currentPhase === 'stopped' || currentPhase === 'error' || currentPhase === 'disconnected';
}
function setStartReadinessFromDevicePayload(j){
  // Keep this object only as informational state from the backend. It must not
  // disable Start. The visible device selections are the source of truth for
  // whether the user can try to start the renderer.
  const reason = String((j && j.start_not_ready_reason) || '').trim();
  const backendReady = !!(j && j.start_ready === true);
  const inputEnumerated = !!(j && j.input_enumerated === true);
  startReadiness = {
    ready: backendReady,
    reason: reason,
    lastRefreshAt: Date.now(),
    inputEnumerated
  };
  if(startReadinessTimer){
    clearTimeout(startReadinessTimer);
    startReadinessTimer = null;
  }
  if(currentPhase === 'stopped' || currentPhase === 'error'){
    const msgEl = $('#statusmsg');
    const current = String(msgEl.textContent || '');
    if(current.includes('still settling') || current.includes('current full input/output device scan') || current.includes('Start will be enabled')){
      msgEl.textContent = 'Stereo renderer is idle.';
    }
  }
  updateStartButtonState();
}
function startNotReadyMessage(){
  const validationError = getSelectionValidationError();
  if(validationError) return validationError;
  return startReadiness.reason || 'Selected audio devices are unavailable.';
}

async function savePrefsNow(){
  try{
    await fetch('/api/preferences', {
      method:'POST',
      headers:{'Content-Type':'application/json'},
      body: JSON.stringify(currentPayload()),
      keepalive: true
    });
  }catch(e){}
}
function scheduleSavePrefs(){
  clearTimeout(saveTimer);
  saveTimer = setTimeout(savePrefsNow, 120);
}
function updateInputHint(items){
  const hint = $('#indevhint');
  const panel = $('#indevincompat');
  const summary = $('#indevincompatsummary');
  const list = $('#indevincompatlist');
  if(!hint) return;
  const allItems = items || [];
  const compatible = allItems.filter(it => (it.compatible !== false) && Number(it.inputs || 0) >= 16);
  const incompatible = allItems.filter(it => Number(it.inputs || 0) > 0 && !(it.compatible !== false && Number(it.inputs || 0) >= 16));
  if(panel && list && summary){
    list.innerHTML = '';
    if(incompatible.length){
      incompatible.forEach(it => {
        const row = document.createElement('div');
        row.className = 'incompatitem';
        row.textContent = `${it.name} — ${Number(it.inputs || 0)} in`;
        list.appendChild(row);
      });
      summary.textContent = `Show incompatible devices (${incompatible.length})`;
      panel.hidden = false;
    }else{
      panel.hidden = true;
      panel.open = false;
    }
  }
  if(!allItems.length){
    hint.textContent = 'No input devices found.';
    hint.className = 'small devicehint warn';
    return;
  }
  if(compatible.length){
    hint.textContent = incompatible.length
      ? `Requires a 16-channel input device. ${incompatible.length} incompatible device${incompatible.length === 1 ? '' : 's'} hidden.`
      : 'Requires an input device with at least 16 channels.';
    hint.className = 'small devicehint';
    return;
  }
  hint.textContent = 'No compatible 16-channel input device found.';
  hint.className = 'small devicehint warn';
}
function updateDeviceSummary(hiddenInput){
  const isInput = hiddenInput.id === 'indev';
  const summaryId = isInput ? '#indevsummary' : '#outdevsummary';
  const listId = isInput ? '#indevlist' : '#outdevlist';
  const el = $(summaryId);
  const listEl = $(listId);
  if(!el || !listEl) return;
  const selected = listEl.querySelector('.devicerow.selected');
  let text = selected ? (selected.dataset.label || selected.textContent || '') : (isInput ? 'No input selected' : 'No output selected');
  if(hiddenInput.dataset.missing === '1' && (hiddenInput.dataset.name || '')){
    text = hiddenInput.dataset.name + ' (unavailable)';
  } else if((hiddenInput.dataset.name || '') && !hiddenInput.value){
    text = hiddenInput.dataset.name + ' (unavailable)';
  } else if(isInput && !selected && listEl.children.length){
    text = 'No compatible input device';
  }
  el.textContent = text;
  el.title = text;
}

function parseRemovedDeviceStatus(text){
  const raw = String(text || '').trim();
  const lower = raw.toLowerCase();
  let kind = '';
  if(lower.startsWith('renderer stopped because the selected output device was removed')) kind = 'outdev';
  else if(lower.startsWith('renderer stopped because the selected input device was removed')) kind = 'indev';
  else return null;
  let name = '';
  const colon = raw.indexOf(':');
  if(colon >= 0){
    name = raw.slice(colon + 1).trim().replace(/[.。]+$/g, '').trim();
  }
  return {kind, name};
}
function normalizeDeviceNameForMatch(name){
  return String(name || '')
    .replace(/\s*\(unavailable\)\s*$/i, '')
    .replace(/[.。]+$/g, '')
    .replace(/\s+/g, ' ')
    .trim()
    .toLowerCase();
}
function stripDeviceSampleRateSuffix(name){
  return normalizeDeviceNameForMatch(name)
    .replace(/\s+\d+(?:\.\d+)?\s*k(?:ilo)?hz$/i, '')
    .replace(/\s+\d+(?:\.\d+)?\s*hz$/i, '')
    .trim();
}
function deviceNamesMatch(a, b){
  const aa = normalizeDeviceNameForMatch(a);
  const bb = normalizeDeviceNameForMatch(b);
  if(!aa || !bb) return false;
  if(aa === bb) return true;
  const as = stripDeviceSampleRateSuffix(aa);
  const bs = stripDeviceSampleRateSuffix(bb);
  return !!(as && bs && as.length >= 6 && as === bs);
}
function findDeviceBySavedSelection(items, selectedValue='', selectedName='', isInput=false){
  const selectable = (items || []).filter(it => isInput ? ((it.compatible !== false) && Number(it.inputs || 0) >= 16) : isSelectableOutputDevice(it));
  const value = String(selectedValue || '').trim();
  const name = String(selectedName || '').trim();
  if(name){
    if(value){
      const exactBoth = selectable.find(it => it.name === name && String(it.index) === value);
      if(exactBoth) return {item: exactBoth, matchedByName: true, matchedByValue: true};
    }
    const exactName = selectable.find(it => it.name === name);
    if(exactName) return {item: exactName, matchedByName: true, matchedByValue: String(exactName.index) === value};
    const normalizedName = selectable.find(it => deviceNamesMatch(it.name, name));
    if(normalizedName) return {item: normalizedName, matchedByName: true, matchedByValue: String(normalizedName.index) === value};

    // Core Audio/PortAudio device indexes are not stable after hotplug. If the
    // saved name is gone, an index-only match may be a different physical output
    // that shifted into the old slot. Treat that as missing so the renderer stops
    // instead of silently switching to another DAC/interface.
    return {item: null, matchedByName: false, matchedByValue: false};
  }
  if(value){
    const exactValue = selectable.find(it => String(it.index) === value);
    if(exactValue) return {item: exactValue, matchedByName: false, matchedByValue: true};
  }
  return {item: null, matchedByName: false, matchedByValue: false};
}
function selectedDeviceIsAvailableInUi(kind, displayName=''){
  const hidden = $('#' + kind);
  const listEl = $('#' + kind + 'list');
  if(!hidden || !listEl) return false;
  if(hidden.dataset.missing === '1') return false;
  const selected = listEl.querySelector('.devicerow.selected');
  if(!selected || isMissingDeviceRow(selected)) return false;
  const hiddenValue = String(hidden.value || '').trim();
  if(!hiddenValue) return false;
  const selectedValue = String(selected.dataset.value || '').trim();
  if(selectedValue && selectedValue !== hiddenValue) return false;
  const selectedName = selected.dataset.label || selected.textContent || hidden.dataset.name || '';
  const wantedName = String(displayName || hidden.dataset.name || '').trim();
  return !wantedName || deviceNamesMatch(selectedName, wantedName);
}
function controlledStopUnavailableKey(revision, text){
  const rev = (typeof revision === 'number') ? String(revision) : '';
  return rev + '|' + String(text || '').trim();
}
function controlledStopAppliesToCurrentSelection(removed){
  if(!removed || !removed.kind) return false;
  const hidden = $('#' + removed.kind);
  if(!hidden) return false;
  const currentName = String(hidden.dataset.name || '').replace(/\s*\(unavailable\)\s*$/i, '').trim();
  const currentValue = String(hidden.value || '').trim();
  const removedName = String(removed.name || '').replace(/\s*\(unavailable\)\s*$/i, '').trim();

  // A device-removal status is only relevant while that same removed device is
  // still the current selection. If the user has already clicked another real
  // output while the renderer is stopped, old backend status packets should not
  // re-select the missing device and flicker the message back to the removal
  // text.
  if(!currentName && !currentValue) return false;
  if(removedName && currentName) return deviceNamesMatch(currentName, removedName);
  if(removedName) return hidden.dataset.missing === '1';
  return hidden.dataset.missing === '1';
}
function normalizeMissingSelectionRows(kind, labelBase=''){
  const hidden = $('#' + kind);
  const listEl = $('#' + kind + 'list');
  if(!hidden || !listEl) return null;
  const fallbackName = kind === 'indev' ? 'Selected input device' : 'Selected output device';
  const rawBase = String(labelBase || hidden.dataset.name || hidden.value || fallbackName).trim();
  const cleanBase = rawBase.replace(/\s*\(unavailable\)\s*$/i, '').trim() || fallbackName;
  const label = cleanBase + ' (unavailable)';
  let keeper = null;
  Array.from(listEl.querySelectorAll('.devicerow')).forEach(row=>{
    const rowLabel = String(row.dataset.label || row.textContent || '').trim();
    const rowValue = String(row.dataset.value || '').trim();
    const isMissing = row.dataset.missingSelection === '1' || rowValue.startsWith('__missing__:') || /\(unavailable\)\s*$/i.test(rowLabel);
    if(!isMissing) return;
    if(!keeper){
      keeper = row;
    }else{
      row.remove();
    }
  });
  if(keeper){
    keeper.type = 'button';
    keeper.className = 'devicerow selected';
    keeper.dataset.missingSelection = '1';
    keeper.dataset.value = '__missing__:' + cleanBase;
    keeper.dataset.label = label;
    keeper.textContent = label;
    keeper.disabled = false;
    keeper.setAttribute('role', 'option');
    keeper.setAttribute('aria-selected', 'true');
    keeper.setAttribute('aria-disabled', 'true');
    if(listEl.firstChild !== keeper){
      listEl.insertBefore(keeper, listEl.firstChild);
    }
  }
  return keeper;
}

function clearMissingDeviceSelection(kind, save=true){
  const hidden = $('#' + kind);
  const listEl = $('#' + kind + 'list');
  if(!hidden || !listEl) return false;
  const hadMissing = hidden.dataset.missing === '1' || (!hidden.value && !!(hidden.dataset.name || '').trim());
  if(!hadMissing) return false;
  missingSelectionClearedByUser[kind] = true;
  listEl.querySelectorAll('.devicerow').forEach(row=>{
    const rowLabel = String(row.dataset.label || row.textContent || '').trim();
    const rowValue = String(row.dataset.value || '').trim();
    const isMissingRow = row.dataset.missingSelection === '1' || rowValue.startsWith('__missing__:') || /\(unavailable\)\s*$/i.test(rowLabel);
    if(isMissingRow) row.remove();
    else {
      row.classList.remove('selected');
      row.setAttribute('aria-selected', 'false');
    }
  });
  hidden.value = '';
  hidden.dataset.name = '';
  hidden.dataset.missing = '0';
  if(kind === 'indev') lastInputDeviceSignature = '';
  else lastOutputDeviceSignature = '';
  deviceSelectionRevision += 1;
  updateDeviceSummary(hidden);
  updateStartButtonState();
  if(save && !appInitializing){
    if(currentPhase === 'error' || currentPhase === 'stopped'){
      savePrefsNow();
    }else{
      scheduleSavePrefs();
    }
  }
  return true;
}
function markSelectedDeviceUnavailable(kind, displayName=''){
  const hidden = $('#' + kind);
  const listEl = $('#' + kind + 'list');
  if(!hidden || !listEl) return;
  missingSelectionClearedByUser[kind] = false;
  const fallbackName = kind === 'indev' ? 'Selected input device' : 'Selected output device';
  const existingName = String(hidden.dataset.name || '').trim();
  const existingValue = String(hidden.value || '').trim();
  const name = String(displayName || existingName || '').trim();
  const labelBase = name || existingName || existingValue || fallbackName;
  const label = labelBase.replace(/\s*\(unavailable\)\s*$/i, '').trim() + ' (unavailable)';
  hidden.value = '';
  hidden.dataset.name = name || existingName || labelBase;
  hidden.dataset.name = String(hidden.dataset.name || '').replace(/\s*\(unavailable\)\s*$/i, '').trim();
  hidden.dataset.missing = '1';
  listEl.querySelectorAll('.devicerow').forEach(row=>{
    row.classList.remove('selected');
    row.setAttribute('aria-selected', 'false');
  });
  let row = normalizeMissingSelectionRows(kind, labelBase);
  if(!row){
    row = document.createElement('button');
    row.type = 'button';
    row.className = 'devicerow selected';
    row.dataset.missingSelection = '1';
    row.disabled = false;
    row.setAttribute('role', 'option');
    row.setAttribute('aria-disabled', 'true');
    listEl.insertBefore(row, listEl.firstChild);
  }
  row.classList.add('selected');
  row.dataset.missingSelection = '1';
  row.dataset.value = '__missing__:' + labelBase.replace(/\s*\(unavailable\)\s*$/i, '').trim();
  row.dataset.label = label;
  row.textContent = label;
  row.disabled = false;
  row.setAttribute('aria-selected', 'true');
  row.setAttribute('aria-disabled', 'true');
  normalizeMissingSelectionRows(kind, labelBase);
  updateDeviceSummary(hidden);
  updateStartButtonState();
}
function selectedOutputRemovedStopText(fallbackName=''){
  const outputEl = $('#outdev');
  const rawName = String(fallbackName || (outputEl && outputEl.dataset.name) || '').trim();
  const cleanName = rawName.replace(/\s*\(unavailable\)\s*$/i, '').trim();
  const displayName = cleanName || 'the selected output device';
  return `Renderer stopped because the selected output device was removed: ${displayName}.`;
}
function selectedInputRemovedStopText(fallbackName=''){
  const inputEl = $('#indev');
  const rawName = String(fallbackName || (inputEl && inputEl.dataset.name) || '').trim();
  const cleanName = rawName.replace(/\s*\(unavailable\)\s*$/i, '').trim();
  const displayName = cleanName || 'the selected input device';
  return `Renderer stopped because the selected input device was removed: ${displayName}.`;
}
function normalizeUnavailableStopMessage(msg){
  const text = String(msg || '').trim();
  if(text === 'Selected output device is unavailable.') return selectedOutputRemovedStopText();
  if(text === 'Selected input device is unavailable or does not expose at least 16 input channels.' ||
     text === 'Selected input device is unavailable or changed before startup.' ||
     text === 'Selected input device is unavailable or not ready.') return selectedInputRemovedStopText();
  return text;
}
function markUnavailableFromStatusText(text){
  const msg = String(text || '').trim();
  if(msg === 'Selected output device is unavailable.'){
    markSelectedDeviceUnavailable('outdev');
    return true;
  }
  if(msg === 'Selected input device is unavailable or does not expose at least 16 input channels.' ||
     msg === 'Selected input device is unavailable or changed before startup.' ||
     msg === 'Selected input device is unavailable or not ready.'){
    markSelectedDeviceUnavailable('indev');
    return true;
  }
  return false;
}


function isMissingDeviceRow(row){
  if(!row) return false;
  const rowLabel = String(row.dataset.label || row.textContent || '').trim();
  const rowValue = String(row.dataset.value || '').trim();
  return row.dataset.missingSelection === '1' || rowValue.startsWith('__missing__:') || /\(unavailable\)\s*$/i.test(rowLabel);
}

function installMissingDeviceOutsideClear(kind){
  const hidden = $('#' + kind);
  const listEl = $('#' + kind + 'list');
  if(!hidden || !listEl) return;
  const maybeClear = (target)=>{
    if(appInitializing) return;
    if(hidden.dataset.missing !== '1') return;

    // The previous version returned for any click inside the device list.
    // That was the bug: clicking the empty list area, scrollbar gutter, or even
    // the unavailable placeholder itself counted as "inside the list", so the
    // row stayed visible until the next background refresh rebuilt the list.
    // Clear the placeholder immediately unless the user is actively pressing a
    // real, available device row, in which case selectDevice() will run next.
    const row = target && target.closest ? target.closest('.devicerow') : null;
    const clickedRealRow = row && listEl.contains(row) && !isMissingDeviceRow(row);
    clearMissingDeviceSelection(kind, !clickedRealRow);
  };
  document.addEventListener('pointerdown', (ev)=>maybeClear(ev.target), true);
  document.addEventListener('focusin', (ev)=>maybeClear(ev.target), true);
}

function installTransientScrollbar(scrollEl){
  const wrap = document.getElementById(scrollEl.id.replace('list', 'wrap'));
  const thumb = document.getElementById(scrollEl.id.replace('list', 'thumb'));
  const trackEl = wrap ? wrap.querySelector('.scrollhint') : null;
  if(!wrap || !thumb || !trackEl) return;
  let timer = null;
  const update = ()=>{
    const total = scrollEl.scrollHeight || 0;
    const visible = scrollEl.clientHeight || 0;
    if(total <= visible + 2){
      wrap.classList.add('no-scroll');
      thumb.style.transform = 'translateY(0px)';
      thumb.style.height = '0px';
      return;
    }
    wrap.classList.remove('no-scroll');
    const track = Math.max(0, trackEl.clientHeight - 2);
    const thumbHeight = Math.max(28, Math.round((visible / total) * track));
    const maxTop = Math.max(0, track - thumbHeight);
    const scrollTop = scrollEl.scrollTop || 0;
    const maxScroll = Math.max(1, total - visible);
    const top = Math.round((scrollTop / maxScroll) * maxTop);
    thumb.style.height = thumbHeight + 'px';
    thumb.style.transform = `translateY(${top}px)`;
  };
  const show = ()=>{
    update();
    wrap.classList.add('show-scrollbar');
    clearTimeout(timer);
    timer = setTimeout(()=>wrap.classList.remove('show-scrollbar'), 1500);
  };
  ['scroll','wheel','touchmove','keydown','mousemove','mouseenter','focus','mousedown'].forEach(evt=>{
    scrollEl.addEventListener(evt, show, {passive: evt !== 'keydown' && evt !== 'focus' && evt !== 'mousedown'});
  });
  wrap.addEventListener('mouseenter', show);
  wrap.addEventListener('mousemove', show);
  wrap.addEventListener('mouseleave', ()=>{ clearTimeout(timer); timer = setTimeout(()=>wrap.classList.remove('show-scrollbar'), 350); });
  scrollEl.addEventListener('focus', show);
  scrollEl.addEventListener('blur', ()=>wrap.classList.remove('show-scrollbar'));
  window.addEventListener('resize', update);
  requestAnimationFrame(update);
}
function selectDevice(kind, value, label, save=true){
  const hidden = $('#' + kind);
  const listEl = $('#' + kind + 'list');
  if(!hidden || !listEl) return;
  const nextValue = (value === undefined || value === null) ? '' : String(value);
  const nextLabel = label || '';
  const wasMissing = hidden.dataset.missing === '1';
  if(nextValue || nextLabel) missingSelectionClearedByUser[kind] = false;
  if(kind === 'indev' && save) clearStartupInputRescan();
  const changed = hidden.value !== nextValue || (hidden.dataset.name || '') !== nextLabel || wasMissing;

  // An unavailable row is only a placeholder for the previously selected missing
  // device. As soon as the user selects a real output/input device, remove that
  // placeholder synchronously from the open list instead of waiting for the
  // periodic device refresh.
  if(nextValue && !String(nextValue).startsWith('__missing__:')){
    listEl.querySelectorAll('.devicerow').forEach(row=>{
      const rowLabel = String(row.dataset.label || row.textContent || '').trim();
      const rowValue = String(row.dataset.value || '').trim();
      const isMissingRow = row.dataset.missingSelection === '1' || rowValue.startsWith('__missing__:') || /\(unavailable\)\s*$/i.test(rowLabel);
      if(isMissingRow) row.remove();
    });
  }

  hidden.value = nextValue;
  hidden.dataset.name = nextLabel;
  hidden.dataset.missing = '0';
  if(changed) deviceSelectionRevision += 1;
  listEl.querySelectorAll('.devicerow').forEach(row=>{
    row.classList.toggle('selected', row.dataset.value === String(hidden.value));
    row.setAttribute('aria-selected', row.classList.contains('selected') ? 'true' : 'false');
  });
  updateDeviceSummary(hidden);
  if(changed){
    startReadiness = { ready:true, reason:'', lastRefreshAt:Date.now(), inputEnumerated:false };
    updateStartButtonState();
  }
  listEl.dispatchEvent(new Event('scroll'));
  if(save){
    if(currentPhase === 'error' || currentPhase === 'stopped'){
      savePrefsNow();
    }else{
      scheduleSavePrefs();
    }
  }
  if(changed && save){
    const validationError = getSelectionValidationError();
    if(!validationError && (currentPhase === 'error' || currentPhase === 'stopped')){
      setRunState('stopped', 'Stereo renderer is idle.');
      updateStartButtonState();
    }
  }
  if(save && changed) queueAutoApply(0);
}
function isSelectableOutputDevice(it){
  const outputs = Number((it && it.outputs) || 0);
  return outputs > 0 && outputs <= 2;
}
function renderDeviceRows(kind, items, preferredValue, preferredName){
  const hidden = $('#' + kind);
  const listEl = $('#' + kind + 'list');
  if(!hidden || !listEl) return;
  markListInteracting(kind, 250);
  const isInput = kind === 'indev';
  const prevValue = preferredValue || hidden.value;
  const prevName = preferredName || hidden.dataset.name || '';
  const hadPreviousSelection = !!(prevValue || prevName);
  listEl.innerHTML = '';
  const selectableItems = isInput
    ? items.filter(it => (it.compatible !== false) && Number(it.inputs || 0) >= 16)
    : items.filter(it => isSelectableOutputDevice(it));
  let wanted = '';
  let matchedByName = false;
  let matchedByValue = false;
  if(selectableItems.length){
    const savedMatch = findDeviceBySavedSelection(items, prevValue, prevName, isInput);
    if(savedMatch.item){
      wanted = String(savedMatch.item.index);
      matchedByName = !!savedMatch.matchedByName;
      matchedByValue = !!savedMatch.matchedByValue;
    }
  }
  const suppressAutoSelect = missingSelectionClearedByUser[kind] === true;
  if(selectableItems.length && !wanted && !hadPreviousSelection && !suppressAutoSelect) wanted = String(selectableItems[0].index);
  selectableItems.forEach(it=>{
    const row = document.createElement('button');
    row.type = 'button';
    row.className = 'devicerow';
    row.dataset.value = String(it.index);
    row.dataset.label = it.name;
    row.textContent = it.name;
    row.setAttribute('role', 'option');
    row.setAttribute('aria-selected', 'false');
    const selectNow = ()=>{
      markListInteracting(kind, 1200);
      selectDevice(kind, it.index, it.name, true);
    };
    row.addEventListener('pointerdown', selectNow);
    row.addEventListener('mousedown', selectNow);
    row.addEventListener('touchstart', selectNow, {passive:true});
    row.addEventListener('click', selectNow);
    listEl.appendChild(row);
  });
  if(isInput) updateInputHint(items);
  if(selectableItems.length && wanted){
    const selectedItem = selectableItems.find(it => String(it.index) === String(wanted));
    if(selectedItem){
      selectDevice(kind, selectedItem.index, selectedItem.name, false);
      return;
    }
  }
  const selectionMissing = hadPreviousSelection && !matchedByName && !matchedByValue;
  if(selectionMissing && prevName){
    const row = document.createElement('button');
    row.type = 'button';
    row.className = 'devicerow selected';
    row.dataset.missingSelection = '1';
    row.dataset.value = '__missing__:' + String(prevValue || prevName || '');
    row.dataset.label = prevName.replace(/\s*\(unavailable\)\s*$/i, '').trim() + ' (unavailable)';
    row.textContent = row.dataset.label;
    row.disabled = false;
    row.setAttribute('role', 'option');
    row.setAttribute('aria-selected', 'true');
    row.setAttribute('aria-disabled', 'true');
    listEl.insertBefore(row, listEl.firstChild);
  }
  hidden.value = hadPreviousSelection ? String(prevValue || '') : '';
  hidden.dataset.name = hadPreviousSelection ? String(prevName || '').replace(/\s*\(unavailable\)\s*$/i, '').trim() : '';
  hidden.dataset.missing = selectionMissing && prevName ? '1' : '0';
  if(selectionMissing && prevName) normalizeMissingSelectionRows(kind, prevName);
  updateDeviceSummary(hidden);
  listEl.dispatchEvent(new Event('scroll'));
}
function buildDeviceSignature(items){
  return JSON.stringify((items || []).map(it => ({
    index: String(it.index ?? ''),
    name: String(it.name || ''),
    inputs: Number(it.inputs || 0),
    outputs: Number(it.outputs || 0),
    compatible: it.compatible !== false
  })));
}
function inputSelectionMissingFromPayload(payload, inputValue, inputName){
  const wantedValue = String(inputValue || '').trim();
  const wantedName = String(inputName || '').replace(/\s*\(unavailable\)\s*$/i, '').trim();
  if(!wantedValue && !wantedName) return false;
  const rows = (payload && Array.isArray(payload.inputs)) ? payload.inputs : [];
  return !rows.some(it => {
    if((it.compatible === false) || Number(it.inputs || 0) < 16) return false;
    const rowValue = String(it.index ?? '').trim();
    const rowName = String(it.name || '').trim();
    if(wantedName && rowName === wantedName) return true;
    if(wantedValue && rowValue === wantedValue) return true;
    if(wantedValue && rowName === wantedValue) return true;
    return false;
  });
}
function clearStartupInputRescan(){
  startupInputRescanArmed = false;
  startupInputRescanAttempts = 0;
  if(startupInputRescanTimer){
    clearTimeout(startupInputRescanTimer);
    startupInputRescanTimer = null;
  }
}
function maybeScheduleStartupInputRescan(payload, source){
  if(!startupInputRescanArmed) return;
  if(currentPhase === 'starting' || currentPhase === 'running' || currentPhase === 'stopping' || currentPhase === 'disconnected') return;
  const inputEl = $('#indev');
  const inputValue = inputEl ? inputEl.value : '';
  const inputName = inputEl ? (inputEl.dataset.name || '') : '';
  if(!inputSelectionMissingFromPayload(payload, inputValue, inputName)){
    clearStartupInputRescan();
    const msgEl = $('#statusmsg');
    const msg = String(msgEl.textContent || '');
    if(msg.includes('Waiting for input device to become available after login')){
      setRunState('stopped', 'Stereo renderer is idle.');
    }
    return;
  }
  if(startupInputRescanAttempts >= STARTUP_INPUT_RESCAN_DELAYS_MS.length) return;
  const delay = STARTUP_INPUT_RESCAN_DELAYS_MS[startupInputRescanAttempts];
  startupInputRescanAttempts += 1;
  if(startupInputRescanTimer) clearTimeout(startupInputRescanTimer);
  const msgEl = $('#statusmsg');
  const current = String(msgEl.textContent || '');
  if(currentPhase === 'stopped' && (current === 'Stereo renderer is idle.' || current.includes('Selected input device is unavailable'))){
    msgEl.textContent = 'Waiting for input device to become available after login…';
  }
  startupInputRescanTimer = setTimeout(async ()=>{
    startupInputRescanTimer = null;
    try{
      const nextPayload = await refreshDevicesFull({startupRetry:true});
      maybeScheduleStartupInputRescan(nextPayload, 'startup retry');
    }catch(e){
      $('#log').textContent += 'Startup input rescan error: ' + e + '\n';
      maybeScheduleStartupInputRescan({inputs:[]}, 'startup retry error');
    }
  }, delay);
}
function setDevices(hiddenInput, items, preferredValue, preferredName, forceRender=false){
  const kind = hiddenInput.id;
  const hidden = hiddenInput;
  const nextValue = (preferredValue === undefined || preferredValue === null) ? '' : String(preferredValue || '');
  const nextName = String(preferredName || '');
  const signatureKey = buildDeviceSignature(items) + '|' + JSON.stringify({value: nextValue, name: nextName});
  const lastKey = kind === 'indev' ? lastInputDeviceSignature : lastOutputDeviceSignature;
  if(!forceRender && signatureKey === lastKey){
    hidden.value = nextValue;
    hidden.dataset.name = nextName.replace(/\s*\(unavailable\)\s*$/i, '').trim();
    if(hidden.dataset.missing === '1') normalizeMissingSelectionRows(kind, hidden.dataset.name || nextName || nextValue);
    updateDeviceSummary(hidden);
    return;
  }
  if(kind === 'indev') lastInputDeviceSignature = signatureKey;
  else lastOutputDeviceSignature = signatureKey;
  renderDeviceRows(kind, items, nextValue, nextName);
}
async function loadPrefs(){
  const r = await fetch('/api/preferences', {cache:'no-store'});
  const p = await r.json();
  $('#exe').value = p.exe || '';
  $('#frames').value = p.frames || '64';
  $('#input_latency_ms').value = p.input_latency_ms ?? '10';
  $('#output_latency_ms').value = p.output_latency_ms ?? '10';
  $('#keep_output_alive').checked = p.keep_output_alive !== false && String(p.keep_output_alive).toLowerCase() !== 'false';
  {
    const loadedPreamp = p.preamp_db ?? '-9.5';
    $('#preamp').value = String(loadedPreamp).trim() === '' ? '0' : loadedPreamp;
  }
  $('#lfe_lowpass').checked = p.lfe_lowpass !== false && String(p.lfe_lowpass).toLowerCase() !== 'false';
  $('#swap_outputs').checked = p.swap_outputs === true || String(p.swap_outputs).toLowerCase() === 'true';
  $('#global_output_peq_text').value = p.global_output_peq_text || '';
  $('#speaker_output_peq_text').value = p.speaker_output_peq_text || '';
  routingPeqProfiles = normalizeRoutingPeqProfiles(p.routing_peq_profiles);
  activeRoutingPeqProfile = String(p.active_routing_peq_profile || '').trim();
  renderRoutingPeqProfiles();
  updateLfeToggleCopy();
  $('#indev').value = p.input_device || '';
  $('#outdev').value = p.output_device || '';
  $('#indev').dataset.name = p.input_device_name || '';
  $('#outdev').dataset.name = p.output_device_name || '';
  syncApplyCommitValues();
  document.getElementById('indevdetails').open = !p.input_collapsed;
  document.getElementById('outdevdetails').open = !p.output_collapsed;
  document.getElementById('renderersettingsdetails').open = !p.settings_collapsed;
  document.getElementById('routingpeqdetails').open = !p.routing_peq_collapsed;
  document.getElementById('visualizerdetails').open = !p.visualizer_collapsed;
  document.getElementById('logdetails').open = !p.log_collapsed;
  updateDeviceSummary($('#indev'));
  updateDeviceSummary($('#outdev'));
  if($('#preset_display')) $('#preset_display').value = '9.1.6 bed (1:1)';
  return p;
}
async function refreshDevices(){
  const refreshId = ++deviceRefreshRequestId;
  const preserveInputList = isListInteracting('indev');
  const preserveOutputList = isListInteracting('outdev');
  const startSelectionRevision = deviceSelectionRevision;
  const snapshotInputValue = $('#indev').value;
  const snapshotOutputValue = $('#outdev').value;
  const snapshotInputName = $('#indev').dataset.name || '';
  const snapshotOutputName = $('#outdev').dataset.name || '';
  const inputClearedByUser = missingSelectionClearedByUser.indev === true;
  const outputClearedByUser = missingSelectionClearedByUser.outdev === true;
  const prefs = await fetch('/api/preferences', {cache:'no-store'}).then(r=>r.json()).catch(()=>({}));
  const exe = encodeURIComponent($('#exe').value.trim());
  const query = new URLSearchParams({
    exe: $('#exe').value.trim(),
    auto: '1',
    input_device: inputClearedByUser ? '' : (snapshotInputValue || prefs.input_device || ''),
    input_device_name: inputClearedByUser ? '' : (snapshotInputName || prefs.input_device_name || ''),
    output_device: outputClearedByUser ? '' : (snapshotOutputValue || prefs.output_device || ''),
    output_device_name: outputClearedByUser ? '' : (snapshotOutputName || prefs.output_device_name || '')
  });
  const r = await fetch('/api/devices?' + query.toString(), {cache:'no-store'});
  const j = await r.json();
  if(j.exe && $('#exe').value.trim() !== String(j.exe).trim()){
    $('#exe').value = String(j.exe).trim();
    if(typeof $('#exe').__syncCommittedValue === 'function') $('#exe').__syncCommittedValue();
  }
  if(refreshId !== deviceRefreshRequestId) return;
  const selectionChangedDuringRefresh = deviceSelectionRevision !== startSelectionRevision;
  const liveInputValue = $('#indev').value;
  const liveOutputValue = $('#outdev').value;
  const liveInputName = $('#indev').dataset.name || '';
  const liveOutputName = $('#outdev').dataset.name || '';
  const nextInputValue = inputClearedByUser ? '' : (selectionChangedDuringRefresh ? liveInputValue : (snapshotInputValue || prefs.input_device));
  const nextOutputValue = outputClearedByUser ? '' : (selectionChangedDuringRefresh ? liveOutputValue : (snapshotOutputValue || prefs.output_device));
  const nextInputName = inputClearedByUser ? '' : (selectionChangedDuringRefresh ? liveInputName : (snapshotInputName || prefs.input_device_name));
  const nextOutputName = outputClearedByUser ? '' : (selectionChangedDuringRefresh ? liveOutputName : (snapshotOutputName || prefs.output_device_name));
  if(!preserveInputList){
    setDevices(
      $('#indev'),
      j.inputs || [],
      nextInputValue,
      nextInputName
    );
  } else {
    updateInputHint(j.inputs || []);
    updateDeviceSummary($('#indev'));
  }
  if(!preserveOutputList){
    setDevices(
      $('#outdev'),
      j.outputs || [],
      nextOutputValue,
      nextOutputName
    );
  } else {
    updateDeviceSummary($('#outdev'));
  }
  const inputListAuthoritative = j.input_enumerated === true;
  const inputSelected = findDeviceBySavedSelection(j.inputs || [], nextInputValue, nextInputName, true).item;
  const outputSelected = findDeviceBySavedSelection(j.outputs || [], nextOutputValue, nextOutputName, false).item;
  const inputMissing = inputListAuthoritative && !!(nextInputValue || nextInputName) && !inputSelected;
  const outputMissing = !!(nextOutputValue || nextOutputName) && !outputSelected;
  if((currentPhase === 'running' || currentPhase === 'starting' || currentPhase === 'stopping') && (inputMissing || outputMissing)){
    const reason = inputMissing
      ? `Renderer stopped because the selected input device was removed: ${nextInputName || nextInputValue || 'the selected input device'}.`
      : `Renderer stopped because the selected output device was removed: ${nextOutputName || nextOutputValue || 'the selected output device'}.`;
    // Apply the stopped/unavailable UI before consuming backend readiness. The
    // selected device is already absent from this authoritative refresh, so there
    // is no useful intermediate Starting… / Waiting for audio devices state.
    stopRendererForMissingDevice(reason);
  }else if((currentPhase === 'error' || currentPhase === 'stopped') && !inputMissing && !outputMissing){
    const currentMessage = String($('#statusmsg').textContent || '').trim();
    if(
      currentMessage === 'Selected output device is unavailable.' ||
      currentMessage === 'Selected input device is unavailable or does not expose at least 16 input channels.' ||
      isControlledStopFinalText(currentMessage)
    ){
      setRunState('stopped', 'Stereo renderer is idle.');
      updateStartButtonState();
    }
  }
  setStartReadinessFromDevicePayload(j);
  // Do not save preferences from the 1.5 s automatic device refresh.
  // Saving preferences may need device-name resolution; on macOS, repeatedly
  // touching the input-device path after an output hot-unplug can retrigger
  // the microphone/TCC permission prompt in a tight loop. User edits already
  // save through selectDevice(), toggles, text commits, Start, and Apply.
  if(j.error){
    $('#log').textContent += 'Device refresh error: ' + j.error + '\n';
  }
}
async function refreshDevicesFull(options={}){
  const prefs = await fetch('/api/preferences', {cache:'no-store'}).then(r=>r.json()).catch(()=>({}));
  const query = new URLSearchParams({
    exe: $('#exe').value.trim(),
    auto: '0',
    input_device: missingSelectionClearedByUser.indev ? '' : ($('#indev').value || prefs.input_device || ''),
    input_device_name: missingSelectionClearedByUser.indev ? '' : ($('#indev').dataset.name || prefs.input_device_name || ''),
    output_device: missingSelectionClearedByUser.outdev ? '' : ($('#outdev').value || prefs.output_device || ''),
    output_device_name: missingSelectionClearedByUser.outdev ? '' : ($('#outdev').dataset.name || prefs.output_device_name || '')
  });
  const r = await fetch('/api/devices?' + query.toString(), {cache:'no-store'});
  const j = await r.json();
  if(j.exe && $('#exe').value.trim() !== String(j.exe).trim()){
    $('#exe').value = String(j.exe).trim();
    if(typeof $('#exe').__syncCommittedValue === 'function') $('#exe').__syncCommittedValue();
  }
  const nextInputValue = missingSelectionClearedByUser.indev ? '' : ($('#indev').value || prefs.input_device || '');
  const nextOutputValue = missingSelectionClearedByUser.outdev ? '' : ($('#outdev').value || prefs.output_device || '');
  const nextInputName = missingSelectionClearedByUser.indev ? '' : ($('#indev').dataset.name || prefs.input_device_name || '');
  const nextOutputName = missingSelectionClearedByUser.outdev ? '' : ($('#outdev').dataset.name || prefs.output_device_name || '');
  setDevices($('#indev'), j.inputs || [], nextInputValue, nextInputName, true);
  setDevices($('#outdev'), j.outputs || [], nextOutputValue, nextOutputName, true);
  updateInputHint(j.inputs || []);
  setStartReadinessFromDevicePayload(j);
  if(j.error) $('#log').textContent += 'Device scan error: ' + j.error + '\n';
  return j;
}
async function stopRendererForMissingDevice(reason){
  const normalizedReason = String(reason || '').trim() || 'Renderer stopped because the selected audio device was removed.';
  const stopReason = normalizedReason.toLowerCase().includes('selected input device') ? 'input_removed' : 'output_removed';
  const finalText = normalizedReason;

  // The UI must become idle atomically as soon as the selected device is known
  // to be gone. Do this even if a previous async /api/stop call is still in
  // flight, otherwise a quick start/disconnect race can leave the UI showing
  // Starting… with an unavailable output selector until the backend catches up.
  const removed = parseRemovedDeviceStatus(finalText);
  if(removed) markSelectedDeviceUnavailable(removed.kind, removed.name);
  setRunState('stopped', finalText);
  updateStartButtonState();

  if(missingDeviceStopInFlight && missingDeviceStopReason === normalizedReason) return;
  missingDeviceStopInFlight = true;
  missingDeviceStopReason = normalizedReason;
  try{
    await fetch('/api/stop', {
      method:'POST',
      headers:{'Content-Type':'application/json'},
      body: JSON.stringify({reason: finalText, stop_text: finalText, stop_reason: stopReason, restart_keepalive: false})
    });
  }catch(e){
  }finally{
    setTimeout(()=>{
      missingDeviceStopInFlight = false;
      missingDeviceStopReason = '';
    }, 1500);
  }
}
async function startRenderer(){
  const startBtn = $('#start');
  // Only a real click on an enabled Start button should launch the renderer.
  // Disabled clicks must not be remembered or replayed after initialization or
  // after a settings apply finishes.
  if(startBtn && startBtn.disabled) return;
  if(appInitializing || applyBusy){
    updateStartButtonState();
    return;
  }
  clearTimeout(autoApplyTimer);
  autoApplyTimer = null;
  applyBusy = true;
  try{
    const validationError = getSelectionValidationError();
    if(validationError){
      // A missing or not-yet-reconnected audio device is not a renderer fault.
      // Keep this in the normal idle/stopped state so a stale click during
      // hotplug cannot flash an Error pill.
      markUnavailableFromStatusText(validationError);
      const stopMessage = normalizeUnavailableStopMessage(validationError);
      setRunState('stopped', stopMessage);
      updateStartButtonState();
      return;
    }
    applyTransitionActive = true;
    applyTransitionIgnoreAllStatuses = true;
    applyTransitionMinRevision = lastStatusRevision;
    setRunState('starting', 'Launching stereo renderer…');
    $('#start').disabled = true;
    $('#stop').disabled = true;
    // /api/start saves the exact payload after resolving the devices. Do not
    // pre-save here: the preferences endpoint may spin up the output keep-alive
    // immediately before launch, which can leave the UI stuck at Starting… on
    // some Core Audio devices.
    const r = await fetch('/api/start', {
      method:'POST',
      headers:{'Content-Type':'application/json'},
      body: JSON.stringify(currentPayload())
    });
    const j = await r.json();
    if(!j.ok){
      applyTransitionActive = false;
      applyTransitionIgnoreAllStatuses = false;
      applyTransitionMinRevision = null;
      const message = j.status_text || j.error || 'Could not start renderer.';
      const requestedPhase = normalizeRunPhase(String(j.phase || '').trim(), message);
      if(requestedPhase === 'stopped'){
        markUnavailableFromStatusText(message);
        const stopMessage = normalizeUnavailableStopMessage(message);
        setRunState('stopped', stopMessage);
        updateStartButtonState();
        return;
      }
      try{
        const statusResp = await fetch('/api/status', {cache:'no-store'});
        if(statusResp.ok){
          const latestStatus = await statusResp.json();
          const latestPhase = latestStatus ? String(latestStatus.phase || '') : '';
          if(latestStatus && latestStatus.status_text && (latestPhase === 'error' || latestPhase === 'stopped')){
            applyStatusPayload(latestStatus);
          }else{
            setRunState('error', message);
          }
        }else{
          setRunState('error', message);
        }
      }catch(_e){
        setRunState('error', message);
      }
    }else{
      await refreshLog();
      try{
        const statusResp = await fetch('/api/status', {cache:'no-store'});
        applyTransitionActive = false;
        applyTransitionIgnoreAllStatuses = false;
        applyTransitionMinRevision = null;
        if(statusResp.ok){
          applyStatusPayload(await statusResp.json());
        }
      }catch(_e){
        applyTransitionActive = false;
        applyTransitionIgnoreAllStatuses = false;
        applyTransitionMinRevision = null;
      }
    }
  }catch(e){
    applyTransitionActive = false;
    applyTransitionIgnoreAllStatuses = false;
    applyTransitionMinRevision = null;
    const message = e && e.message ? e.message : 'Could not start renderer.';
    setRunState('error', message);
  } finally {
    applyBusy = false;
    if(pendingAutoApply){
      pendingAutoApply = false;
      setTimeout(()=>{ applyPresetAndRestart(); }, 0);
    }
  }
}
async function stopRenderer(){
  if(applyBusy) return;
  applyBusy = true;
  try{
    setRunState('stopping', 'Stopping renderer…');
    $('#start').disabled = true;
    $('#stop').disabled = true;
    await fetch('/api/stop', {method:'POST'});
  } finally {
    applyBusy = false;
  }
}
function handleDisconnect(){
  if(disconnected) return;
  disconnected = true;
  if(eventSource){
    try{ eventSource.close(); }catch(e){}
    eventSource = null;
  }
  clearTimeout(eventRetryTimer);
  $('#overlay').classList.add('show');
  setRunState('disconnected', 'Launcher script stopped.');
  clearTimeout(pollTimer);
  clearInterval(embeddedFallbackPollTimer);
  embeddedFallbackPollTimer = null;
  clearInterval(heartbeatTimer);
  clearInterval(logTimer);
  clearInterval(deviceRefreshTimer);
  try{ window.close(); }catch(e){}
  setTimeout(()=>{ try{ window.open('', '_self'); window.close(); }catch(e){} }, 120);
  setTimeout(()=>{ try{ location.replace('about:blank'); }catch(e){} }, 500);
}
window.__nativeApplyStatus = function(payload){
  pendingNativeStatus = mergeStatusPeakPayload(pendingNativeStatus, payload || {});
  if(document.hidden){
    const next = pendingNativeStatus;
    pendingNativeStatus = null;
    applyStatusPayload(next || {});
    return;
  }
  if(pendingNativeStatusFrame) return;
  pendingNativeStatusFrame = requestAnimationFrame(()=>{
    pendingNativeStatusFrame = 0;
    const next = pendingNativeStatus;
    pendingNativeStatus = null;
    applyStatusPayload(next || {});
  });
};
window.__nativeApplyLog = function(payload){ applyLogPayload(payload || {}); };
window.__nativeBridgeReady = true;

function isControlledStopFinalText(text){
  const msg = String(text || '').toLowerCase();
  return (
    msg.startsWith('renderer stopped because the selected output device was removed') ||
    msg.startsWith('renderer stopped because the selected input device was removed') ||
    msg.startsWith('renderer stopped because the selected audio device was removed') ||
    msg.startsWith('renderer stopped because the live audio stream ended')
  );
}
function controlledStopInterimText(finalText){
  const msg = String(finalText || '').toLowerCase();
  if(msg.includes('selected input device')) return 'Selected input device was removed. Stopping renderer…';
  if(msg.includes('selected audio device')) return 'Selected audio device was removed. Stopping renderer…';
  if(msg.includes('live audio stream ended')) return 'Live audio stream ended. Stopping renderer…';
  return 'Selected output device was removed. Stopping renderer…';
}
function clearControlledStopHold(){
  if(controlledStopHoldTimer){
    clearTimeout(controlledStopHoldTimer);
    controlledStopHoldTimer = null;
  }
  controlledStopHoldKey = '';
}
function applyStatusPayload(j){
  disconnectFailures = 0;
  const nextRevision = (typeof j.status_revision === 'number') ? j.status_revision : null;
  if(nextRevision !== null){
    if(nextRevision < lastStatusRevision) return;
  }
  rendererRecoveryPending = !!(j && j.renderer_recovery_pending);
  let nextText = j.status_text || 'Stereo renderer is idle.';
  let nextPhase = normalizeRunPhase(j.phase || 'stopped', nextText);
  const unavailableFinal = (nextPhase === 'stopped' || nextPhase === 'error') && markUnavailableFromStatusText(nextText);
  if(unavailableFinal){
    nextPhase = 'stopped';
    nextText = normalizeUnavailableStopMessage(nextText);
  }
  let controlledStopFinal = nextPhase === 'stopped' && isControlledStopFinalText(nextText);
  const controlledStopRemovedDevice = controlledStopFinal ? parseRemovedDeviceStatus(nextText) : null;
  const controlledStopKey = controlledStopFinal ? controlledStopUnavailableKey(nextRevision, nextText) : '';
  if(controlledStopFinal && controlledStopRemovedDevice){
    const staleForCurrentSelection = !controlledStopAppliesToCurrentSelection(controlledStopRemovedDevice);
    const alreadyHandledAndNowAvailable = lastAppliedControlledStopUnavailableKey === controlledStopKey && selectedDeviceIsAvailableInUi(controlledStopRemovedDevice.kind, controlledStopRemovedDevice.name);
    if(staleForCurrentSelection || alreadyHandledAndNowAvailable){
      nextText = 'Stereo renderer is idle.';
      controlledStopFinal = false;
    }
  }
  // Output/input hot-unplug is now shown as a direct final Stopped state.
  // Do not insert an artificial Stopping… hold on the UI side.
  if(controlledStopHoldTimer){
    clearControlledStopHold();
  }
  if(j.__controlled_stop_hold_release){
    controlledStopHoldKey = '';
    controlledStopHoldTimer = null;
  }

  if(applyTransitionActive){
    if(applyTransitionIgnoreAllStatuses){
      return;
    }
    const minRevision = (typeof applyTransitionMinRevision === 'number') ? applyTransitionMinRevision : lastStatusRevision;
    if(nextRevision !== null && nextRevision <= minRevision){
      return;
    }
    if(nextPhase === 'running' || nextPhase === 'error' || nextPhase === 'disconnected'){
      applyTransitionActive = false;
      applyTransitionMinRevision = null;
    }else{
      return;
    }
  }

  if(nextRevision !== null){
    lastStatusRevision = nextRevision;
  }

  if(nextPhase === 'stopped' || nextPhase === 'error' || nextPhase === 'disconnected'){
    missingDeviceStopInFlight = false;
    missingDeviceStopReason = '';
  }
  if(nextPhase === 'running'){
    lastAppliedControlledStopUnavailableKey = '';
    const inputLevelsMap = j.input_levels_db || null;
    const visualFlags = statusVisualSignalFlags(j);
    updateSharedVisualGate(visualFlags);
    if(document.hidden && !visualFlags.anyActive){
      // While hidden, requestAnimationFrame may not run, so a silent status
      // packet must clear the rendered DOM immediately instead of waiting for
      // the window to become visible again.
      forceIdleVisualState();
    }else{
      // Update both raw input-channel badges and folded stereo output meters from
      // the same status packet. Bed badges stay raw and never copy sum-meter color.
      setMeter('L', j.meter_left_db || '-inf', !!j.clip_left);
      setMeter('R', j.meter_right_db || '-inf', !!j.clip_right);
      setWaveTransientMap(j.input_transients_db || {});
      if(inputLevelsMap){
        setInputLevels(inputLevelsMap, true);
      }else{
        setActiveInputs(j.active_labels || [], true);
      }
    }
  }else{
    sharedVisualSilenceSince = 0;
    sharedVisualsCleared = true;
    sharedVisualInputGroupActive = false;
    sharedVisualOutputGroupActive = false;
    holdInputBadgesWithOutput = false;
    holdSumMetersWithInputs = false;
    setWaveTransientMap({});
    setInputLevels({}, false);
    resetWaveField();
    resetMeter('L');
    resetMeter('R');
  }
  if(controlledStopFinal){
    const removed = controlledStopRemovedDevice || parseRemovedDeviceStatus(nextText);
    if(removed){
      const key = controlledStopKey || controlledStopUnavailableKey(nextRevision, nextText);
      if(lastAppliedControlledStopUnavailableKey !== key){
        markSelectedDeviceUnavailable(removed.kind, removed.name);
        lastAppliedControlledStopUnavailableKey = key;
      }
    }
  }
  setRunState(nextPhase, nextText);
  const startBtn = $('#start');
  startBtn.textContent = 'Start';
  updateStartButtonState();
}
function applyLogPayload(j){
  if(typeof j.log_revision === 'number') lastLogRevision = j.log_revision;
  const nextLog = j.log || '';
  if($('#log').textContent !== nextLog){
    $('#log').textContent = nextLog;
    $('#log').scrollTop = $('#log').scrollHeight;
  }
}
async function poll(){
  try{
    const r = await fetch('/api/status', {cache:'no-store'});
    if(!r.ok) throw new Error('status fetch failed');
    const j = await r.json();
    applyStatusPayload(j);
    if(typeof j.log_revision === 'number' && j.log_revision !== lastLogRevision){
      refreshLog();
    }
  }catch(e){
    disconnectFailures += 1;
    if(disconnectFailures >= 8){
      handleDisconnect();
      return;
    }
    pollTimer = setTimeout(poll, 50);
    return;
  }
  scheduleNextPoll();
}
async function embeddedStatusFallbackPoll(){
  if(!EMBEDDED_MODE || disconnected) return;
  try{
    const r = await fetch('/api/status', {cache:'no-store'});
    if(!r.ok) throw new Error('status fetch failed');
    const j = await r.json();
    applyStatusPayload(j);
    if(typeof j.log_revision === 'number' && j.log_revision !== lastLogRevision){
      refreshLog();
    }
    disconnectFailures = 0;
  }catch(e){
    disconnectFailures += 1;
    if(disconnectFailures >= 12) handleDisconnect();
  }
}
function startEmbeddedStatusFallbackPoll(){
  if(!EMBEDDED_MODE || embeddedFallbackPollTimer) return;
  embeddedFallbackPollTimer = setInterval(embeddedStatusFallbackPoll, 750);
}
function connectEventStream(){
  if(disconnected || eventSource) return;
  try{
    eventSource = new EventSource('/api/events');
  }catch(e){
    scheduleNextPoll();
    return;
  }
  eventSource.addEventListener('status', (ev)=>{
    try{ applyStatusPayload(JSON.parse(ev.data)); }catch(e){}
  });
  eventSource.addEventListener('log', (ev)=>{
    try{ applyLogPayload(JSON.parse(ev.data)); }catch(e){}
  });
  eventSource.addEventListener('shutdown', ()=>{
    handleDisconnect();
  });
  eventSource.onopen = ()=>{
    disconnectFailures = 0;
    clearTimeout(pollTimer);
    clearTimeout(eventRetryTimer);
  };
  eventSource.onerror = ()=>{
    if(disconnected) return;
    if(eventSource){
      try{ eventSource.close(); }catch(e){}
      eventSource = null;
    }
    disconnectFailures += 1;
    if(disconnectFailures >= 8){
      handleDisconnect();
      return;
    }
    clearTimeout(eventRetryTimer);
    eventRetryTimer = setTimeout(connectEventStream, 80);
    pollTimer = setTimeout(poll, 0);
  };
}
async function refreshLog(){
  try{
    const r = await fetch('/api/log', {cache:'no-store'});
    if(!r.ok) throw new Error('log fetch failed');
    const j = await r.json();
    lastLogRevision = (typeof j.log_revision === 'number') ? j.log_revision : lastLogRevision;
    const nextLog = j.log || '';
    if($('#log').textContent !== nextLog){
      $('#log').textContent = nextLog;
      $('#log').scrollTop = $('#log').scrollHeight;
    }
  }catch(e){}
}
async function heartbeat(){
  try{
    await fetch('/api/client_ping', {
      method:'POST',
      headers:{'Content-Type':'application/json'},
      body: JSON.stringify({client_id: CLIENT_ID}),
      keepalive: true
    });
  }catch(e){
    // Let status polling decide when the launcher is truly gone.
  }
}
function notifyClose(){
  if(EMBEDDED_MODE) return;
  const data = JSON.stringify({client_id: CLIENT_ID});
  try{
    navigator.sendBeacon('/api/client_close', new Blob([data], {type:'application/json'}));
  }catch(e){
    try{
      fetch('/api/client_close', {
        method:'POST',
        headers:{'Content-Type':'application/json'},
        body: data,
        keepalive: true
      });
    }catch(_e){}
  }
}

badges();
fillPresets();

document.querySelectorAll('input:not([type=file]),select,textarea').forEach(el => {
  el.addEventListener('change', scheduleSavePrefs);
  // Do not save the preamp field on every keystroke. It is committed
  // deliberately on Enter/blur/change so partial edits like "-" or blank
  // never become the live or saved preamp value while the user is typing.
  if(el.id !== 'preamp') el.addEventListener('input', scheduleSavePrefs);
});
function installTextFileLoader(fileSelector, textSelectors, clearSelectors){
  const fileEl = $(fileSelector);
  if(!fileEl) return;
  fileEl.addEventListener('change', async ()=>{
    const file = fileEl.files && fileEl.files[0];
    if(!file) return;
    try{
      const text = await file.text();
      (clearSelectors || []).forEach(sel=>{
        const target = $(sel);
        if(target){
          target.value = '';
          if(typeof target.__syncCommittedValue === 'function') target.__syncCommittedValue();
        }
      });
      (textSelectors || []).forEach(sel=>{
        const target = $(sel);
        if(target){
          target.value = text;
          if(typeof target.__syncCommittedValue === 'function') target.__syncCommittedValue();
        }
      });
      scheduleSavePrefs();
      queueAutoApply(0);
    }catch(e){
      setRunState('error', 'Could not read PEQ file: ' + e);
    }finally{
      fileEl.value = '';
    }
  });
}
function installClearButton(buttonSelector, textSelector){
  const button = $(buttonSelector);
  const target = $(textSelector);
  if(!button || !target) return;
  button.addEventListener('click', ()=>{
    target.value = '';
    if(typeof target.__syncCommittedValue === 'function') target.__syncCommittedValue();
    scheduleSavePrefs();
    queueAutoApply(0);
  });
}
bindApplyOnCommit($('#frames'));
bindApplyOnCommit($('#input_latency_ms'));
bindApplyOnCommit($('#output_latency_ms'));
bindApplyOnCommit($('#preamp'), {normalizeBeforeCommit: normalizePreampEmptyToZero, onCommit: scheduleSavePrefs});
bindApplyOnCommit($('#lfe_lowpass'));
bindApplyOnCommit($('#swap_outputs'));
bindApplyOnCommit($('#global_output_peq_text'));
bindApplyOnCommit($('#speaker_output_peq_text'));

// Preamp edits are intentionally not auto-applied while typing. Press Enter,
// tab/click out, or use the number-field spinner to commit the value.
$('#lfe_lowpass').addEventListener('change', updateLfeToggleCopy);
installTextFileLoader('#global_peq_file', ['#global_output_peq_text']);
installTextFileLoader('#speaker_peq_file', ['#speaker_output_peq_text']);
installClearButton('#clear_global_peq', '#global_output_peq_text');
installClearButton('#clear_speaker_peq', '#speaker_output_peq_text');
$('#routing_peq_profile_select').addEventListener('change', ()=>{
  activeRoutingPeqProfile = $('#routing_peq_profile_select').value || '';
  const nameInput = $('#routing_peq_profile_name');
  if(nameInput) nameInput.value = activeRoutingPeqProfile;
  savePrefsNow();
  renderRoutingPeqProfiles();
});
$('#save_routing_peq_profile').onclick = saveRoutingPeqProfile;
$('#load_routing_peq_profile').onclick = loadRoutingPeqProfile;
$('#delete_routing_peq_profile').onclick = deleteRoutingPeqProfile;
$('#start').onclick = startRenderer;
$('#stop').onclick = stopRenderer;
document.getElementById('indevdetails').addEventListener('toggle', (ev)=>{
  if(!appInitializing && !ev.currentTarget.open) clearMissingDeviceSelection('indev', true);
  updateDeviceSummary($('#indev'));
  if(!appInitializing) savePrefsNow();
});
document.getElementById('outdevdetails').addEventListener('toggle', (ev)=>{
  if(!appInitializing && !ev.currentTarget.open) clearMissingDeviceSelection('outdev', true);
  updateDeviceSummary($('#outdev'));
  if(!appInitializing) savePrefsNow();
});
['renderersettingsdetails','routingpeqdetails','visualizerdetails','logdetails'].forEach((id)=>{
  const el = document.getElementById(id);
  if(el) el.addEventListener('toggle', ()=>{ savePrefsNow(); });
});
installMacMinimizeShortcut();
installTransientScrollbar($('#indevlist'));
installTransientScrollbar($('#outdevlist'));
['indevlist','outdevlist'].forEach((id)=>{
  const el = document.getElementById(id);
  const kind = id.replace('list','');
  if(!el) return;
  ['pointerdown','mousedown','touchstart','focus','mouseenter','keydown'].forEach((evt)=>{
    el.addEventListener(evt, ()=>markListInteracting(kind, 1200), {passive: evt === 'touchstart'});
  });
});

if(!EMBEDDED_MODE){
  window.addEventListener('pagehide', notifyClose);
  window.addEventListener('beforeunload', notifyClose);
}

function refreshAfterWindowReturn(){
  const wasSuspended = visualsWereSuspended;
  visualsWereSuspended = false;
  clearTimeout(focusDeviceRefreshTimer);
  if(wasSuspended){
    // Keep the last known live meter frame visible on return. The explicit
    // status refresh below will correct stale values, but it should not create
    // a visible empty-meter flash while music is still playing.
    snapVisualsToLatestRawState();
  }
  focusDeviceRefreshTimer = setTimeout(()=>{
    refreshStatusAndSnapVisuals();
    refreshDevices().catch(()=>{});
  }, 0);
}
document.addEventListener('visibilitychange', ()=>{
  if(document.hidden){
    visualsWereSuspended = true;
    meterAnimLastTs = 0;
    // Keep the last rendered meter frame. Active/silent hidden status packets
    // still update or clear the visuals, and focus return refreshes status.
  }else{
    refreshAfterWindowReturn();
  }
});
window.addEventListener('focus', refreshAfterWindowReturn);
window.addEventListener('pageshow', refreshAfterWindowReturn);

(async function init(){
  const prefs = await loadPrefs();
  await fetch('/api/client_open', {
    method:'POST',
    headers:{'Content-Type':'application/json'},
    body: JSON.stringify({client_id: CLIENT_ID})
  }).catch(()=>{});
  const refreshInputButton = $('#refresh_input_devices');
  if(refreshInputButton){
    refreshInputButton.addEventListener('click', ()=>{ refreshDevicesFull().catch(e=>{ $('#log').textContent += 'Device scan error: ' + e + '\n'; }); });
  }
  // The first scan after opening the app is an intentional foreground scan, not
  // a background hotplug refresh. It must populate input devices even when the
  // previously selected output device is currently disconnected. Later timer
  // refreshes stay output-safe and avoid touching the input side during/after
  // hot-unplug events.
  //
  // After a reboot/login reopen, CoreAudio can briefly report an incomplete
  // input inventory while the multichannel device is still coming back. The
  // normal 1.5 s refresh is output-only by design, so do a bounded set of
  // startup-only full rescans until the saved input reappears.
  let initialDevicePayload = null;
  try{
    initialDevicePayload = await refreshDevicesFull({startupInitial:true});
  }catch(e){
    $('#log').textContent += 'Initial device scan error: ' + e + '\n';
    await refreshDevices();
    initialDevicePayload = {inputs:[]};
  }
  maybeScheduleStartupInputRescan(initialDevicePayload, 'initial open');
  deviceRefreshTimer = setInterval(()=>{ refreshDevices().catch(()=>{}); }, 1500);
  heartbeatTimer = setInterval(heartbeat, 2000);
  renderMeter('L', 0);
  renderMeter('R', 0);
  meterAnimHandle = requestAnimationFrame(animateMeters);
  refreshLog();
  appInitializing = false;
  updateStartButtonState();
  if(EMBEDDED_MODE){
    try{
      const r = await fetch('/api/status', {cache:'no-store'});
      if(r.ok) applyStatusPayload(await r.json());
    }catch(e){}
    startEmbeddedStatusFallbackPoll();
  }else{
    poll();
    connectEventStream();
  }
})();
