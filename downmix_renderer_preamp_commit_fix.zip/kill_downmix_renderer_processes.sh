#!/bin/zsh
# One-time recovery helper for old builds that left the launcher or renderer alive.
# It targets this app's webview launcher, local server, renderer helper, and silent keep-alive helper.

osascript -e 'tell application id "com.peqdb.downmixrenderer" to quit' 2>/dev/null || true
sleep 0.5

pkill -TERM -f 'bed_renderer_916_low_latency' 2>/dev/null || true
pkill -TERM -f 'bed_renderer_web_launcher.py' 2>/dev/null || true
pkill -TERM -f 'downmix_renderer_webview_app.py' 2>/dev/null || true
pkill -TERM -f 'Downmix Renderer.app' 2>/dev/null || true
sleep 0.5

pkill -KILL -f 'bed_renderer_916_low_latency' 2>/dev/null || true
pkill -KILL -f 'bed_renderer_web_launcher.py' 2>/dev/null || true
pkill -KILL -f 'downmix_renderer_webview_app.py' 2>/dev/null || true
pkill -KILL -f 'Downmix Renderer.app' 2>/dev/null || true

echo 'Stopped leftover Downmix Renderer processes, if any were running.'
