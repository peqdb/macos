Downmix Renderer webview build

This version fixes the common blank-white-window startup issue by opening a native loading page first, waiting for the local HTTP control server to become reachable, and only then loading the main UI.

Build steps on macOS:

1. Open Terminal
2. cd into this folder
3. Run:
   chmod +x build_downmix_renderer_webview_app.sh
   ./build_downmix_renderer_webview_app.sh

When the build finishes, open:

  dist/Downmix Renderer.app

Share this file with another Apple Silicon Mac user:

  Downmix Renderer.zip

If the app still shows a startup error page, delete the launcher preferences file and relaunch:

  ~/.bed_renderer_web_launcher.json


Stability update in v3:
This build adds a short grace period before shutting the launcher down when the page reloads or briefly disconnects during startup. That prevents the first-launch 'Launcher disconnected' race seen in earlier webview builds.


v4 updates:
- Replaces the native <select> device pickers with a custom styled device list so the input/output chooser looks the same inside the embedded webview.
- Disables page-close shutdown in embedded mode and relies on the native app-window close event instead, which avoids the startup race behind the lingering 'Launcher disconnected' issue.
- Makes disconnect detection less trigger-happy by requiring several failed status polls before declaring the launcher gone.
