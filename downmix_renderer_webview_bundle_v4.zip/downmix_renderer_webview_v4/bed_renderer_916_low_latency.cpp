#include <portaudio.h>
#ifdef __APPLE__
#include <pa_mac_core.h>
#endif

#include <algorithm>
#include <array>
#include <atomic>
#include <cmath>
#include <complex>
#include <chrono>
#include <csignal>
#include <cstdint>
#include <cstdlib>
#include <cstring>
#include <exception>
#include <fstream>
#include <iomanip>
#include <iostream>
#include <limits>
#include <numeric>
#include <sstream>
#include <stdexcept>
#include <string>
#include <string_view>
#include <vector>
#include <thread>

namespace {

constexpr double kSampleRate = 48000.0;
constexpr int kStereoOutChannels = 2;
constexpr int kBedChannels916 = 16;
constexpr double kCenterGain = 0.70710678;
constexpr const char* kBedOrder916 = "L,R,C,LFE,Ls,Rs,Lrs,Rrs,Lw,Rw,Ltf,Rtf,Ltm,Rtm,Ltr,Rtr";
constexpr const char* kDefaultLfeFirCsv = "lfe_extracted_fir_taps.csv";
constexpr double kTiny = 1e-300;
constexpr double kDefaultActiveThresholdDb = -60.0;
constexpr int kDefaultStatusUpdateIntervalMs = 8;
constexpr std::array<const char*, kBedChannels916> kBedLabels916 = {
    "L", "R", "C", "LFE", "Ls", "Rs", "Lrs", "Rrs",
    "Lw", "Rw", "Ltf", "Rtf", "Ltm", "Rtm", "Ltr", "Rtr"
};

std::atomic<bool> g_shouldStop{false};

enum class LfeMode {
    Exact,
    MinPhaseDelay,
};

enum class StereoMatrixMode {
    Standard,
    Adc2Direct,
};

struct StereoFrame {
    double left = 0.0;
    double right = 0.0;
};

struct Config {
    PaDeviceIndex inputDevice = paNoDevice;
    PaDeviceIndex outputDevice = paNoDevice;
    double sampleRate = kSampleRate;
    unsigned long framesPerBuffer = 64;
    int inputChannels = kBedChannels916;
    std::array<int, kBedChannels916> inputMap{};
    double masterGain = 1.0;
    double lfeGain = 1.0;
    std::string exactLfeFirCsv = kDefaultLfeFirCsv;
    LfeMode lfeMode = LfeMode::Exact;
    StereoMatrixMode stereoMatrixMode = StereoMatrixMode::Standard;
    double phaseFitFminHz = 20.0;
    double phaseFitFmaxHz = 200.0;
    int delaySearchMaxSamples = 512;
    int delayOverrideSamples = -1;
    bool swapOutputs = false;
    bool clipOutput = false;
    bool listDevices = false;
    bool showActiveInputs = false;
    bool showOutputMeter = false;
    double activeThresholdLinear = 0.001;
    int statusUpdateIntervalMs = kDefaultStatusUpdateIntervalMs;
#ifdef __APPLE__
    bool macProMode = true;
    bool macAllowDeviceParameterChanges = true;
#endif
};

struct CallbackState {
    std::array<int, kBedChannels916> map{};
    double masterGain = 1.0;
    double lfeGain = 1.0;
    bool swapOutputs = false;
    bool clipOutput = false;
    StereoMatrixMode stereoMatrixMode = StereoMatrixMode::Standard;
    std::vector<double> lfeFir;
    std::vector<double> lfeHistory;
    size_t lfeHistoryPos = 0;
    std::vector<StereoFrame> dryDelayBuffer;
    size_t dryDelayPos = 0;
    size_t delaySamples = 0;
    std::atomic<uint32_t> recentActiveMask{0};
    std::atomic<double> recentOutputPeakLeft{0.0};
    std::atomic<double> recentOutputPeakRight{0.0};
    std::atomic<uint32_t> recentClipFlags{0};
    double activeThresholdLinear = 0.001;
    std::atomic<uint64_t> callbackCount{0};
    std::atomic<uint64_t> inputUnderflows{0};
    std::atomic<uint64_t> inputOverflows{0};
    std::atomic<uint64_t> outputUnderflows{0};
    std::atomic<uint64_t> outputOverflows{0};
};

struct DesignedFilters {
    std::vector<double> exactFir;
    std::vector<double> activeFir;
    size_t delaySamples = 0;
    double exactPassbandDb = 0.0;
    double activePassbandDb = 0.0;
};

[[noreturn]] void die(const std::string& msg) {
    throw std::runtime_error(msg);
}

bool isIntegerString(const std::string& s) {
    if (s.empty()) return false;
    size_t i = 0;
    if (s[0] == '+' || s[0] == '-') i = 1;
    if (i >= s.size()) return false;
    for (; i < s.size(); ++i) {
        if (!std::isdigit(static_cast<unsigned char>(s[i]))) return false;
    }
    return true;
}

std::string toLower(std::string s) {
    std::transform(s.begin(), s.end(), s.begin(), [](unsigned char c) {
        return static_cast<char>(std::tolower(c));
    });
    return s;
}

double dbToGain(double db) {
    return std::pow(10.0, db / 20.0);
}

std::vector<std::string> split(const std::string& s, char delim) {
    std::vector<std::string> out;
    std::stringstream ss(s);
    std::string item;
    while (std::getline(ss, item, delim)) {
        size_t start = 0;
        while (start < item.size() && std::isspace(static_cast<unsigned char>(item[start]))) ++start;
        size_t end = item.size();
        while (end > start && std::isspace(static_cast<unsigned char>(item[end - 1]))) --end;
        if (end > start) out.emplace_back(item.substr(start, end - start));
    }
    return out;
}

std::string activeInputsToString(uint32_t mask, const std::array<int, kBedChannels916>& inputMap) {
    std::ostringstream oss;
    bool first = true;
    for (int i = 0; i < kBedChannels916; ++i) {
        if ((mask & (uint32_t(1) << i)) == 0) continue;
        if (!first) oss << ", ";
        first = false;
        if (inputMap[i] < 0) oss << '0';
        else oss << (inputMap[i] + 1);
        oss << "(" << kBedLabels916[i] << ")";
    }
    if (first) oss << "(none)";
    return oss.str();
}

void atomicMax(std::atomic<double>& target, double value) {
    double current = target.load(std::memory_order_relaxed);
    while (value > current &&
           !target.compare_exchange_weak(current, value,
                                         std::memory_order_relaxed,
                                         std::memory_order_relaxed)) {
    }
}

std::string dbfsString(double linear) {
    if (linear <= 0.0) return "-inf";
    std::ostringstream oss;
    oss << std::fixed << std::setprecision(1) << (20.0 * std::log10(linear));
    return oss.str();
}

std::string inputMapToString(const std::array<int, kBedChannels916>& inputMap) {
    std::ostringstream oss;
    for (int i = 0; i < kBedChannels916; ++i) {
        if (i) oss << ',';
        if (inputMap[i] < 0) oss << '0';
        else oss << (inputMap[i] + 1);
    }
    return oss.str();
}

std::string executableDir(const char* exe) {
    if (!exe || !*exe) return ".";
    std::string path(exe);
    const auto pos = path.find_last_of("/\\");
    if (pos == std::string::npos) return ".";
    if (pos == 0) return "/";
    return path.substr(0, pos);
}

size_t nextPow2(size_t n) {
    size_t p = 1;
    while (p < n) p <<= 1;
    return p;
}

void fft(std::vector<std::complex<double>>& a, bool inverse) {
    const size_t n = a.size();
    for (size_t i = 1, j = 0; i < n; ++i) {
        size_t bit = n >> 1;
        for (; j & bit; bit >>= 1) j ^= bit;
        j ^= bit;
        if (i < j) std::swap(a[i], a[j]);
    }

    for (size_t len = 2; len <= n; len <<= 1) {
        const double ang = 2.0 * M_PI / static_cast<double>(len) * (inverse ? 1.0 : -1.0);
        const std::complex<double> wlen(std::cos(ang), std::sin(ang));
        for (size_t i = 0; i < n; i += len) {
            std::complex<double> w(1.0, 0.0);
            for (size_t j = 0; j < len / 2; ++j) {
                const std::complex<double> u = a[i + j];
                const std::complex<double> v = a[i + j + len / 2] * w;
                a[i + j] = u + v;
                a[i + j + len / 2] = u - v;
                w *= wlen;
            }
        }
    }

    if (inverse) {
        const double invN = 1.0 / static_cast<double>(n);
        for (auto& x : a) x *= invN;
    }
}

std::vector<double> loadFirCsv(const std::string& csvPath) {
    std::ifstream in(csvPath);
    if (!in) die("Could not open FIR CSV: " + csvPath);

    std::string headerLine;
    if (!std::getline(in, headerLine)) die("FIR CSV is empty: " + csvPath);

    auto headers = split(headerLine, ',');
    int tapColumn = -1;
    for (size_t i = 0; i < headers.size(); ++i) {
        if (headers[i] == "tap_value") {
            tapColumn = static_cast<int>(i);
            break;
        }
    }
    if (tapColumn < 0) die("FIR CSV must contain a tap_value column: " + csvPath);

    std::vector<double> taps;
    std::string line;
    while (std::getline(in, line)) {
        auto cols = split(line, ',');
        if (cols.empty()) continue;
        if (tapColumn >= static_cast<int>(cols.size())) continue;
        taps.push_back(std::stod(cols[tapColumn]));
    }
    if (taps.size() < 2) die("Invalid FIR coefficient array in: " + csvPath);
    return taps;
}

std::vector<double> minimumPhaseSameLength(const std::vector<double>& h) {
    const size_t n = h.size();
    size_t nFft = 1;
    while (nFft < 8 * n) nFft <<= 1;

    std::vector<std::complex<double>> H(nFft);
    for (size_t i = 0; i < n; ++i) H[i] = std::complex<double>(h[i], 0.0);
    fft(H, false);

    std::vector<std::complex<double>> logMag(nFft);
    for (size_t i = 0; i < nFft; ++i) {
        logMag[i] = std::complex<double>(std::log(std::abs(H[i]) + kTiny), 0.0);
    }
    fft(logMag, true);

    std::vector<double> ceps(nFft, 0.0);
    for (size_t i = 0; i < nFft; ++i) ceps[i] = logMag[i].real();

    std::vector<double> cepsMin(nFft, 0.0);
    cepsMin[0] = ceps[0];
    if ((nFft % 2) == 0) {
        for (size_t i = 1; i < nFft / 2; ++i) cepsMin[i] = 2.0 * ceps[i];
        cepsMin[nFft / 2] = ceps[nFft / 2];
    } else {
        for (size_t i = 1; i < (nFft + 1) / 2; ++i) cepsMin[i] = 2.0 * ceps[i];
    }

    std::vector<std::complex<double>> C(nFft);
    for (size_t i = 0; i < nFft; ++i) C[i] = std::complex<double>(cepsMin[i], 0.0);
    fft(C, false);
    for (size_t i = 0; i < nFft; ++i) C[i] = std::exp(C[i]);
    fft(C, true);

    std::vector<double> hMin(n, 0.0);
    for (size_t i = 0; i < n; ++i) hMin[i] = C[i].real();

    const double dcIn = std::accumulate(h.begin(), h.end(), 0.0);
    const double dcOut = std::accumulate(hMin.begin(), hMin.end(), 0.0);
    if (std::abs(dcOut) > kTiny) {
        const double scale = dcIn / dcOut;
        for (double& v : hMin) v *= scale;
    }
    return hMin;
}

void firFreqResponse(const std::vector<double>& h,
                     double sampleRate,
                     std::vector<double>& freqs,
                     std::vector<std::complex<double>>& Hout) {
    const size_t worN = 16384;
    const size_t nFft = worN * 2;
    std::vector<std::complex<double>> x(nFft);
    for (size_t i = 0; i < h.size() && i < nFft; ++i) x[i] = std::complex<double>(h[i], 0.0);
    fft(x, false);

    freqs.resize(worN);
    Hout.resize(worN);
    for (size_t k = 0; k < worN; ++k) {
        freqs[k] = static_cast<double>(k) * sampleRate / static_cast<double>(nFft);
        Hout[k] = x[k];
    }
}

double medianDbInBand(const std::vector<double>& freqs,
                      const std::vector<std::complex<double>>& H,
                      double fmin,
                      double fmax) {
    std::vector<double> vals;
    for (size_t i = 0; i < freqs.size(); ++i) {
        if (freqs[i] >= fmin && freqs[i] <= fmax) {
            vals.push_back(20.0 * std::log10(std::abs(H[i]) + kTiny));
        }
    }
    if (vals.empty()) return 0.0;
    const size_t mid = vals.size() / 2;
    std::nth_element(vals.begin(), vals.begin() + mid, vals.end());
    if (vals.size() % 2 == 1) return vals[mid];
    const double a = vals[mid];
    std::nth_element(vals.begin(), vals.begin() + mid - 1, vals.end());
    const double b = vals[mid - 1];
    return 0.5 * (a + b);
}

DesignedFilters designFiltersFromPythonLogic(const Config& cfg, const std::string& csvPath) {
    DesignedFilters out;
    out.exactFir = loadFirCsv(csvPath);

    if (cfg.lfeMode == LfeMode::Exact) {
        out.activeFir = out.exactFir;
        out.delaySamples = (out.activeFir.size() - 1) / 2;
        std::vector<double> freqs;
        std::vector<std::complex<double>> H;
        firFreqResponse(out.activeFir, cfg.sampleRate, freqs, H);
        out.exactPassbandDb = medianDbInBand(freqs, H, 20.0, 60.0);
        out.activePassbandDb = out.exactPassbandDb;
        return out;
    }

    out.activeFir = minimumPhaseSameLength(out.exactFir);

    std::vector<double> freqs;
    std::vector<std::complex<double>> HExact;
    std::vector<std::complex<double>> HMin;
    firFreqResponse(out.exactFir, cfg.sampleRate, freqs, HExact);
    firFreqResponse(out.activeFir, cfg.sampleRate, freqs, HMin);

    out.exactPassbandDb = medianDbInBand(freqs, HExact, 20.0, 60.0);
    out.activePassbandDb = medianDbInBand(freqs, HMin, 20.0, 60.0);
    const double pbScale = dbToGain(out.exactPassbandDb - out.activePassbandDb);
    for (double& v : out.activeFir) v *= pbScale;

    firFreqResponse(out.activeFir, cfg.sampleRate, freqs, HMin);
    out.activePassbandDb = medianDbInBand(freqs, HMin, 20.0, 60.0);

    if (cfg.delayOverrideSamples >= 0) {
        out.delaySamples = static_cast<size_t>(cfg.delayOverrideSamples);
        return out;
    }

    double bestErr = std::numeric_limits<double>::infinity();
    int bestDelay = 0;
    for (int d = 0; d <= cfg.delaySearchMaxSamples; ++d) {
        double accum = 0.0;
        size_t count = 0;
        for (size_t i = 0; i < freqs.size(); ++i) {
            const double f = freqs[i];
            if (f < cfg.phaseFitFminHz || f > cfg.phaseFitFmaxHz) continue;
            const double mag = std::abs(HMin[i]);
            const std::complex<double> unitPhase = HMin[i] / (mag + kTiny);
            const double omega = 2.0 * M_PI * f / cfg.sampleRate;
            const std::complex<double> dryAllpass = std::exp(std::complex<double>(0.0, -omega * static_cast<double>(d)));
            const double weight = mag * mag;
            const double diff = std::abs(dryAllpass - unitPhase);
            accum += weight * diff * diff;
            ++count;
        }
        if (count == 0) break;
        const double err = std::sqrt(accum / static_cast<double>(count));
        if (err < bestErr) {
            bestErr = err;
            bestDelay = d;
        }
    }

    out.delaySamples = static_cast<size_t>(bestDelay);
    return out;
}

PaDeviceIndex resolveDevice(const std::string& token, bool forInput) {
    if (token.empty()) {
        return forInput ? Pa_GetDefaultInputDevice() : Pa_GetDefaultOutputDevice();
    }
    if (isIntegerString(token)) {
        int idx = std::stoi(token);
        if (idx < 0 || idx >= Pa_GetDeviceCount()) {
            die("Device index out of range: " + token);
        }
        const PaDeviceInfo* d = Pa_GetDeviceInfo(idx);
        if (!d) die("Could not resolve device index: " + token);
        if (forInput && d->maxInputChannels <= 0) die("Selected input device has no input channels");
        if (!forInput && d->maxOutputChannels <= 0) die("Selected output device has no output channels");
        return idx;
    }

    const std::string needle = toLower(token);
    const int count = Pa_GetDeviceCount();
    PaDeviceIndex best = paNoDevice;
    for (int i = 0; i < count; ++i) {
        const PaDeviceInfo* d = Pa_GetDeviceInfo(i);
        if (!d || !d->name) continue;
        if (forInput && d->maxInputChannels <= 0) continue;
        if (!forInput && d->maxOutputChannels <= 0) continue;
        if (toLower(d->name).find(needle) != std::string::npos) {
            best = i;
            break;
        }
    }
    if (best == paNoDevice) {
        die(std::string("Could not find ") + (forInput ? "input" : "output") + " device matching: " + token);
    }
    return best;
}

std::array<int, kBedChannels916> parseInputMap(const std::string& text, int inputChannels) {
    auto parts = split(text, ',');
    if (parts.size() != kBedChannels916) {
        die("--input-map must contain exactly 16 comma-separated channel numbers for 9.1.6");
    }
    std::array<int, kBedChannels916> map{};
    for (size_t i = 0; i < parts.size(); ++i) {
        const std::string token = toLower(parts[i]);
        if (token == "0" || token == "x" || token == "mute" || token == "none") {
            map[i] = -1;
            continue;
        }
        if (!isIntegerString(parts[i])) {
            die("Invalid channel number in --input-map: " + parts[i]);
        }
        int oneBased = std::stoi(parts[i]);
        if (oneBased < 1 || oneBased > inputChannels) {
            die("--input-map entry out of range for --input-channels: " + std::to_string(oneBased));
        }
        map[i] = oneBased - 1;
    }
    return map;
}

void listDevices() {
    const int count = Pa_GetDeviceCount();
    if (count < 0) {
        die(std::string("Pa_GetDeviceCount failed: ") + Pa_GetErrorText(count));
    }
    std::cout << "PortAudio devices:\n";
    for (int i = 0; i < count; ++i) {
        const PaDeviceInfo* d = Pa_GetDeviceInfo(i);
        if (!d) continue;
        std::cout << '[' << i << ']';
        if (i == Pa_GetDefaultInputDevice()) std::cout << " [default-in]";
        if (i == Pa_GetDefaultOutputDevice()) std::cout << " [default-out]";
        std::cout << ' ' << (d->name ? d->name : "(unnamed)")
                  << " | in: " << d->maxInputChannels
                  << " | out: " << d->maxOutputChannels
                  << " | default SR: " << d->defaultSampleRate
                  << " | low in lat: " << std::fixed << std::setprecision(4) << d->defaultLowInputLatency
                  << " | low out lat: " << std::fixed << std::setprecision(4) << d->defaultLowOutputLatency
                  << "\n";
    }
}

void printUsage(const char* exe) {
    std::cout
        << "Usage:\n"
        << "  " << exe << " --list-devices\n"
        << "  " << exe << " --input-device 3 --output-device 2 [options]\n\n"
        << "Fixed renderer: 9.1.6 bed -> stereo with switchable LFE path\n"
        << "Bed order: " << kBedOrder916 << "\n\n"
        << "Options:\n"
        << "  --list-devices                 Print devices and exit\n"
        << "  --input-device <name|index>   Input device name substring or index\n"
        << "  --output-device <name|index>  Output device name substring or index\n"
        << "  --samplerate 48000            Sample rate. This renderer is intended for 48 kHz\n"
        << "  --frames-per-buffer <n>       Callback size in frames. Default 64\n"
        << "  --input-channels <n>          Channels to open on input device. Default 16\n"
        << "  --input-map a,b,c,...         1-based map for L,R,C,LFE,Ls,Rs,Lrs,Rrs,Lw,Rw,Ltf,Rtf,Ltm,Rtm,Ltr,Rtr. Use 0/x/mute for unmapped bed channels\n"
        << "  --master-gain-db <dB>         Master gain in dB\n"
        << "  --lfe-gain-db <dB>            LFE gain in dB before FIR processing\n"
        << "  --lfe-mode <exact|minphase>   exact FIR+delay or Python-style min-phase+best delay\n"
        << "  --exact-lfe-fir-csv <path>    CSV containing extracted exact LFE FIR taps in tap_value column\n"
        << "  --phase-fit-fmin-hz <Hz>      Lower bound for dry delay fit in minphase mode\n"
        << "  --phase-fit-fmax-hz <Hz>      Upper bound for dry delay fit in minphase mode\n"
        << "  --delay-search-max-samples <n> Maximum pure-delay samples to search in minphase mode\n"
        << "  --delay-override-samples <n>  Override auto-fit dry delay in minphase mode\n"
        << "  --stereo-matrix-mode <standard|adc2-direct>  Standard FIR/minphase path or fixed ADC2 direct matrix\n"
        << "  --swap-outputs                Swap final left and right outputs\n"
        << "  --clip-output                 Hard clip output to [-1, 1]\n"
        << "  --show-active-inputs          Print active input channels while running\n"
        << "  --show-output-meter           Print output peak meter status while running\n"
        << "  --active-threshold-db <dB>    Activity threshold in dBFS, default -60\n"
        << "  --status-interval-ms <n>      Status publish interval for launcher/UI telemetry. Default 8 ms\n"
#ifdef __APPLE__
        << "  --no-mac-pro-mode             Disable paMacCorePro stream tuning\n"
        << "  --no-mac-device-changes       Do not allow Core Audio device parameter changes\n"
#endif
        << "\nExamples:\n"
        << "  " << exe << " --input-device \"BlackHole 16ch\" --output-device \"BlackHole 2ch\" --frames-per-buffer 32 --stereo-matrix-mode standard --lfe-mode exact\n"
        << "  " << exe << " --input-device \"BlackHole 16ch\" --output-device \"BlackHole 2ch\" --frames-per-buffer 32 --stereo-matrix-mode standard --lfe-mode minphase\n"
        << "  " << exe << " --input-device \"BlackHole 16ch\" --output-device \"BlackHole 2ch\" --frames-per-buffer 32 --stereo-matrix-mode adc2-direct\n";
}

Config parseArgs(int argc, char** argv) {
    Config cfg;
    for (int i = 0; i < kBedChannels916; ++i) cfg.inputMap[i] = i;

    auto requireValue = [&](int& idx, const char* flag) -> std::string {
        if (idx + 1 >= argc) die(std::string("Missing value for ") + flag);
        return argv[++idx];
    };

    std::string inputDeviceToken;
    std::string outputDeviceToken;
    std::string inputMapText;
    bool inputMapProvided = false;

    for (int i = 1; i < argc; ++i) {
        std::string arg = argv[i];
        if (arg == "--help" || arg == "-h") {
            printUsage(argv[0]);
            std::exit(0);
        } else if (arg == "--list-devices") {
            cfg.listDevices = true;
        } else if (arg == "--input-device") {
            inputDeviceToken = requireValue(i, "--input-device");
        } else if (arg == "--output-device") {
            outputDeviceToken = requireValue(i, "--output-device");
        } else if (arg == "--samplerate") {
            cfg.sampleRate = std::stod(requireValue(i, "--samplerate"));
        } else if (arg == "--frames-per-buffer") {
            cfg.framesPerBuffer = static_cast<unsigned long>(std::stoul(requireValue(i, "--frames-per-buffer")));
        } else if (arg == "--input-channels") {
            cfg.inputChannels = std::stoi(requireValue(i, "--input-channels"));
        } else if (arg == "--input-map") {
            inputMapText = requireValue(i, "--input-map");
            inputMapProvided = true;
        } else if (arg == "--master-gain-db") {
            cfg.masterGain = dbToGain(std::stod(requireValue(i, "--master-gain-db")));
        } else if (arg == "--lfe-gain-db") {
            cfg.lfeGain = dbToGain(std::stod(requireValue(i, "--lfe-gain-db")));
        } else if (arg == "--exact-lfe-fir-csv") {
            cfg.exactLfeFirCsv = requireValue(i, "--exact-lfe-fir-csv");
        } else if (arg == "--lfe-mode") {
            const std::string mode = toLower(requireValue(i, "--lfe-mode"));
            if (mode == "exact") cfg.lfeMode = LfeMode::Exact;
            else if (mode == "minphase") cfg.lfeMode = LfeMode::MinPhaseDelay;
            else die("Unsupported --lfe-mode: " + mode);
        } else if (arg == "--stereo-matrix-mode") {
            const std::string mode = toLower(requireValue(i, "--stereo-matrix-mode"));
            if (mode == "standard") cfg.stereoMatrixMode = StereoMatrixMode::Standard;
            else if (mode == "adc2-direct") cfg.stereoMatrixMode = StereoMatrixMode::Adc2Direct;
            else die("Unsupported --stereo-matrix-mode: " + mode);
        } else if (arg == "--phase-fit-fmin-hz") {
            cfg.phaseFitFminHz = std::stod(requireValue(i, "--phase-fit-fmin-hz"));
        } else if (arg == "--phase-fit-fmax-hz") {
            cfg.phaseFitFmaxHz = std::stod(requireValue(i, "--phase-fit-fmax-hz"));
        } else if (arg == "--delay-search-max-samples") {
            cfg.delaySearchMaxSamples = std::stoi(requireValue(i, "--delay-search-max-samples"));
        } else if (arg == "--delay-override-samples") {
            cfg.delayOverrideSamples = std::stoi(requireValue(i, "--delay-override-samples"));
        } else if (arg == "--swap-outputs") {
            cfg.swapOutputs = true;
        } else if (arg == "--clip-output") {
            cfg.clipOutput = true;
        } else if (arg == "--show-active-inputs") {
            cfg.showActiveInputs = true;
        } else if (arg == "--no-show-active-inputs") {
            cfg.showActiveInputs = false;
        } else if (arg == "--show-output-meter") {
            cfg.showOutputMeter = true;
        } else if (arg == "--active-threshold-db") {
            cfg.activeThresholdLinear = dbToGain(std::stod(requireValue(i, "--active-threshold-db")));
        } else if (arg == "--status-interval-ms") {
            cfg.statusUpdateIntervalMs = std::stoi(requireValue(i, "--status-interval-ms"));
            if (cfg.statusUpdateIntervalMs < 1) cfg.statusUpdateIntervalMs = 1;
#ifdef __APPLE__
        } else if (arg == "--no-mac-pro-mode") {
            cfg.macProMode = false;
        } else if (arg == "--no-mac-device-changes") {
            cfg.macAllowDeviceParameterChanges = false;
#endif
        } else {
            die("Unknown argument: " + arg);
        }
    }

    if (cfg.listDevices) return cfg;
    if (cfg.sampleRate != kSampleRate) die("This renderer is defined for 48 kHz only. Use --samplerate 48000.");
    if (cfg.inputChannels < kBedChannels916) die("--input-channels must be at least 16 for 9.1.6.");
    if (inputMapProvided) cfg.inputMap = parseInputMap(inputMapText, cfg.inputChannels);
    cfg.inputDevice = resolveDevice(inputDeviceToken, true);
    cfg.outputDevice = resolveDevice(outputDeviceToken, false);

    const PaDeviceInfo* inInfo = Pa_GetDeviceInfo(cfg.inputDevice);
    const PaDeviceInfo* outInfo = Pa_GetDeviceInfo(cfg.outputDevice);
    if (!inInfo || !outInfo) die("Could not query selected device info.");
    if (inInfo->maxInputChannels < cfg.inputChannels) die("Selected input device does not expose enough input channels.");
    if (outInfo->maxOutputChannels < kStereoOutChannels) die("Selected output device does not expose at least 2 output channels.");
    return cfg;
}

struct CallbackBundle {
    CallbackState state;
    int inputStride = kBedChannels916;
};

double processFirSample(CallbackState& st, double x) {
    if (st.lfeFir.empty()) return x;
    st.lfeHistory[st.lfeHistoryPos] = x;
    double y = 0.0;
    size_t hist = st.lfeHistoryPos;
    for (size_t k = 0; k < st.lfeFir.size(); ++k) {
        y += st.lfeFir[k] * st.lfeHistory[hist];
        hist = (hist == 0) ? (st.lfeHistory.size() - 1) : (hist - 1);
    }
    st.lfeHistoryPos = (st.lfeHistoryPos + 1) % st.lfeHistory.size();
    return y;
}

StereoFrame processDryDelaySample(CallbackState& st, double left, double right) {
    if (st.delaySamples == 0 || st.dryDelayBuffer.empty()) return {left, right};
    StereoFrame delayed = st.dryDelayBuffer[st.dryDelayPos];
    st.dryDelayBuffer[st.dryDelayPos] = {left, right};
    st.dryDelayPos = (st.dryDelayPos + 1) % st.dryDelayBuffer.size();
    return delayed;
}

int audioCallbackStride(const void* input,
                        void* output,
                        unsigned long frameCount,
                        const PaStreamCallbackTimeInfo*,
                        PaStreamCallbackFlags statusFlags,
                        void* userData) {
    auto* bundle = static_cast<CallbackBundle*>(userData);
    auto& st = bundle->state;
    st.callbackCount.fetch_add(1, std::memory_order_relaxed);

    if (statusFlags & paInputUnderflow) st.inputUnderflows.fetch_add(1, std::memory_order_relaxed);
    if (statusFlags & paInputOverflow) st.inputOverflows.fetch_add(1, std::memory_order_relaxed);
    if (statusFlags & paOutputUnderflow) st.outputUnderflows.fetch_add(1, std::memory_order_relaxed);
    if (statusFlags & paOutputOverflow) st.outputOverflows.fetch_add(1, std::memory_order_relaxed);

    const float* in = static_cast<const float*>(input);
    float* out = static_cast<float*>(output);
    if (!out) return paContinue;
    if (!in) {
        std::fill(out, out + frameCount * kStereoOutChannels, 0.0f);
        return paContinue;
    }

    const int stride = bundle->inputStride;
    const auto& m = st.map;
    const double master = st.masterGain;
    const double lfeGain = st.lfeGain;
    const bool swap = st.swapOutputs;
    const bool clip = st.clipOutput;
    const double activeThreshold = st.activeThresholdLinear;
    uint32_t localActiveMask = 0;
    double localPeakLeft = 0.0;
    double localPeakRight = 0.0;
    uint32_t localClipFlags = 0;

    for (unsigned long n = 0; n < frameCount; ++n) {
        const float* s = in + static_cast<size_t>(n) * stride;

        const auto sampleForBed = [&](int bedIndex) -> double {
            const int sourceIndex = m[bedIndex];
            if (sourceIndex < 0 || sourceIndex >= stride) return 0.0;
            return static_cast<double>(s[sourceIndex]);
        };

        const double L   = sampleForBed(0);
        const double R   = sampleForBed(1);
        const double C   = sampleForBed(2);
        const double LFE = sampleForBed(3) * lfeGain;
        const double Ls  = sampleForBed(4);
        const double Rs  = sampleForBed(5);
        const double Lrs = sampleForBed(6);
        const double Rrs = sampleForBed(7);
        const double Lw  = sampleForBed(8);
        const double Rw  = sampleForBed(9);
        const double Ltf = sampleForBed(10);
        const double Rtf = sampleForBed(11);
        const double Ltm = sampleForBed(12);
        const double Rtm = sampleForBed(13);
        const double Ltr = sampleForBed(14);
        const double Rtr = sampleForBed(15);

        for (int ch = 0; ch < kBedChannels916; ++ch) {
            const int sourceIndex = m[ch];
            if (sourceIndex < 0 || sourceIndex >= stride) continue;
            if (std::fabs(s[sourceIndex]) >= activeThreshold) localActiveMask |= (uint32_t(1) << ch);
        }

        double left = 0.0;
        double right = 0.0;

        if (st.stereoMatrixMode == StereoMatrixMode::Adc2Direct) {
            left =
                (1.00000000 * L) +
                (0.70710678 * C) +
                (2.26464431 * LFE) +
                (1.00000000 * Ls) +
                (1.00000000 * Lrs) +
                (1.00000000 * Lw) +
                (1.00000000 * Ltf) +
                (1.00000000 * Ltm) +
                (1.00000000 * Ltr);

            right =
                (1.00000000 * R) +
                (0.70710678 * C) +
                (2.26464431 * LFE) +
                (1.00000000 * Rs) +
                (1.00000000 * Rrs) +
                (1.00000000 * Rw) +
                (1.00000000 * Rtf) +
                (1.00000000 * Rtm) +
                (1.00000000 * Rtr);

            left *= master;
            right *= master;
        } else {
            const double dryLeft = L + kCenterGain * C + Ls + Lrs + Lw + Ltf + Ltm + Ltr;
            const double dryRight = R + kCenterGain * C + Rs + Rrs + Rw + Rtf + Rtm + Rtr;
            const StereoFrame delayedDry = processDryDelaySample(st, dryLeft, dryRight);
            const double lfeFiltered = processFirSample(st, LFE);

            left = (delayedDry.left + lfeFiltered) * master;
            right = (delayedDry.right + lfeFiltered) * master;
        }

        if (swap) std::swap(left, right);

        localPeakLeft = std::max(localPeakLeft, std::abs(left));
        localPeakRight = std::max(localPeakRight, std::abs(right));
        if (std::abs(left) > 1.0) localClipFlags |= 0x1u;
        if (std::abs(right) > 1.0) localClipFlags |= 0x2u;

        if (clip) {
            left = std::max(-1.0, std::min(1.0, left));
            right = std::max(-1.0, std::min(1.0, right));
        }

        out[2 * n + 0] = static_cast<float>(left);
        out[2 * n + 1] = static_cast<float>(right);
    }
    if (localActiveMask != 0) {
        st.recentActiveMask.fetch_or(localActiveMask, std::memory_order_relaxed);
    }
    if (localPeakLeft > 0.0) atomicMax(st.recentOutputPeakLeft, localPeakLeft);
    if (localPeakRight > 0.0) atomicMax(st.recentOutputPeakRight, localPeakRight);
    if (localClipFlags != 0) st.recentClipFlags.fetch_or(localClipFlags, std::memory_order_relaxed);
    return paContinue;
}

void handleSignal(int) {
    g_shouldStop.store(true, std::memory_order_relaxed);
}

}  // namespace

int main(int argc, char** argv) {
    try {
        PaError err = Pa_Initialize();
        if (err != paNoError) {
            std::cerr << "Pa_Initialize failed: " << Pa_GetErrorText(err) << '\n';
            return 1;
        }

        try {
            Config cfg = parseArgs(argc, argv);
            if (cfg.listDevices) {
                listDevices();
                Pa_Terminate();
                return 0;
            }

            std::string exactFirPath = cfg.exactLfeFirCsv;
            if (!exactFirPath.empty() && exactFirPath.find('/') == std::string::npos) {
                exactFirPath = executableDir(argv[0]) + "/" + exactFirPath;
            }

            DesignedFilters designed;
            if (cfg.stereoMatrixMode == StereoMatrixMode::Standard) {
                designed = designFiltersFromPythonLogic(cfg, exactFirPath);
            } else {
                designed.delaySamples = 0;
            }

            const PaDeviceInfo* inInfo = Pa_GetDeviceInfo(cfg.inputDevice);
            const PaDeviceInfo* outInfo = Pa_GetDeviceInfo(cfg.outputDevice);
            if (!inInfo || !outInfo) die("Could not query device info after argument parsing.");

            PaStreamParameters inParams{};
            inParams.device = cfg.inputDevice;
            inParams.channelCount = cfg.inputChannels;
            inParams.sampleFormat = paFloat32;
            inParams.suggestedLatency = inInfo->defaultLowInputLatency;
            inParams.hostApiSpecificStreamInfo = nullptr;

            PaStreamParameters outParams{};
            outParams.device = cfg.outputDevice;
            outParams.channelCount = kStereoOutChannels;
            outParams.sampleFormat = paFloat32;
            outParams.suggestedLatency = outInfo->defaultLowOutputLatency;
            outParams.hostApiSpecificStreamInfo = nullptr;

#ifdef __APPLE__
            PaMacCoreStreamInfo macStreamInfo{};
            unsigned long macFlags = 0;
            if (cfg.macProMode) macFlags |= paMacCorePro;
            if (cfg.macAllowDeviceParameterChanges) macFlags |= paMacCoreChangeDeviceParameters;
            PaMacCore_SetupStreamInfo(&macStreamInfo, macFlags);
            inParams.hostApiSpecificStreamInfo = &macStreamInfo;
            outParams.hostApiSpecificStreamInfo = &macStreamInfo;
#endif

            err = Pa_IsFormatSupported(&inParams, &outParams, cfg.sampleRate);
            if (err != paFormatIsSupported) {
                die(std::string("Requested stream format is not supported: ") + Pa_GetErrorText(err));
            }

            CallbackBundle bundle;
            bundle.inputStride = cfg.inputChannels;
            bundle.state.map = cfg.inputMap;
            bundle.state.masterGain = cfg.masterGain;
            bundle.state.lfeGain = cfg.lfeGain;
            bundle.state.swapOutputs = cfg.swapOutputs;
            bundle.state.clipOutput = cfg.clipOutput;
            bundle.state.stereoMatrixMode = cfg.stereoMatrixMode;
            bundle.state.activeThresholdLinear = cfg.activeThresholdLinear;
            if (cfg.stereoMatrixMode == StereoMatrixMode::Standard) {
                bundle.state.lfeFir = designed.activeFir;
                bundle.state.lfeHistory.assign(designed.activeFir.size(), 0.0);
                bundle.state.lfeHistoryPos = 0;
                bundle.state.delaySamples = designed.delaySamples;
                bundle.state.dryDelayBuffer.assign(designed.delaySamples, {});
                bundle.state.dryDelayPos = 0;
            } else {
                bundle.state.lfeFir.clear();
                bundle.state.lfeHistory.clear();
                bundle.state.lfeHistoryPos = 0;
                bundle.state.delaySamples = 0;
                bundle.state.dryDelayBuffer.clear();
                bundle.state.dryDelayPos = 0;
            }

            PaStream* stream = nullptr;
            const PaStreamFlags flags = paClipOff | paDitherOff | paPrimeOutputBuffersUsingStreamCallback;

            err = Pa_OpenStream(&stream,
                                &inParams,
                                &outParams,
                                cfg.sampleRate,
                                cfg.framesPerBuffer,
                                flags,
                                audioCallbackStride,
                                &bundle);
            if (err != paNoError) {
                die(std::string("Pa_OpenStream failed: ") + Pa_GetErrorText(err));
            }

            err = Pa_StartStream(stream);
            if (err != paNoError) {
                Pa_CloseStream(stream);
                die(std::string("Pa_StartStream failed: ") + Pa_GetErrorText(err));
            }

            const PaStreamInfo* streamInfo = Pa_GetStreamInfo(stream);
            std::signal(SIGINT, handleSignal);
            std::signal(SIGTERM, handleSignal);

            std::cout << "Starting low-latency 9.1.6 renderer\n";
            std::cout << "Input device:  [" << cfg.inputDevice << "] " << inInfo->name << '\n';
            std::cout << "Output device: [" << cfg.outputDevice << "] " << outInfo->name << '\n';
            std::cout << "Bed order:     " << kBedOrder916 << '\n';
            std::cout << "Sample rate:   " << cfg.sampleRate << '\n';
            std::cout << "Frames/buffer: " << cfg.framesPerBuffer << '\n';
            std::cout << "Input channels opened: " << cfg.inputChannels << '\n';
            std::cout << "Input map (1-based): " << inputMapToString(cfg.inputMap) << '\n';
            std::cout << "Master gain:   " << 20.0 * std::log10(std::max(cfg.masterGain, 1e-20)) << " dB\n";
            std::cout << "LFE gain:      " << 20.0 * std::log10(std::max(cfg.lfeGain, 1e-20)) << " dB\n";
            std::cout << "Stereo matrix mode: "
                      << (cfg.stereoMatrixMode == StereoMatrixMode::Adc2Direct ? "adc2-direct" : "standard") << '\n';
            if (cfg.stereoMatrixMode == StereoMatrixMode::Standard) {
                std::cout << "LFE mode:      " << (cfg.lfeMode == LfeMode::Exact ? "exact" : "minphase") << '\n';
            }
            std::cout << "Swap outputs:  " << (cfg.swapOutputs ? "true" : "false") << '\n';
            std::cout << "Clip output:   " << (cfg.clipOutput ? "true" : "false") << '\n';
            if (cfg.showActiveInputs) {
                std::cout << "Active threshold: "
                          << 20.0 * std::log10(std::max(cfg.activeThresholdLinear, 1e-20)) << " dBFS\n";
            }
            std::cout << "Show output meter: " << (cfg.showOutputMeter ? "true" : "false") << '\n';
            if (cfg.showActiveInputs || cfg.showOutputMeter) {
                std::cout << "Status update interval: " << cfg.statusUpdateIntervalMs << " ms\n";
            }
            if (streamInfo) {
                std::cout << "Reported input latency:  " << streamInfo->inputLatency * 1000.0 << " ms\n";
                std::cout << "Reported output latency: " << streamInfo->outputLatency * 1000.0 << " ms\n";
            }
#ifdef __APPLE__
            std::cout << "macOS pro mode: " << (cfg.macProMode ? "true" : "false") << '\n';
            std::cout << "Allow device parameter changes: " << (cfg.macAllowDeviceParameterChanges ? "true" : "false") << '\n';
#endif
            if (cfg.stereoMatrixMode == StereoMatrixMode::Adc2Direct) {
                std::cout << "ADC2 direct matrix:\n";
                std::cout << "  FL  -> [1.00000000, 0.00000000]\n";
                std::cout << "  FR  -> [0.00000000, 1.00000000]\n";
                std::cout << "  FC  -> [0.70710678, 0.70710678]\n";
                std::cout << "  LFE -> [2.26464431, 2.26464431]\n";
                std::cout << "  BL/BLC/SL/TFL/TSL/TBL -> [1.00000000, 0.00000000]\n";
                std::cout << "  BR/BRC/SR/TFR/TSR/TBR -> [0.00000000, 1.00000000]\n";
                std::cout << "LFE path: fixed ADC2 direct stereo matrix coefficient\n";
            } else {
                std::cout << "Exact FIR path: " << exactFirPath << '\n';
                std::cout << "Exact FIR taps: " << designed.exactFir.size() << '\n';
                if (cfg.lfeMode == LfeMode::Exact) {
                    std::cout << "Active FIR taps: " << designed.activeFir.size() << '\n';
                    std::cout << "Matched dry delay: " << designed.delaySamples << " samples ("
                              << (static_cast<double>(designed.delaySamples) / cfg.sampleRate * 1000.0) << " ms)\n";
                    std::cout << "LFE path: exact FIR on LFE, dry stereo path delayed to FIR group delay\n";
                } else {
                    std::cout << "Min-phase FIR taps: " << designed.activeFir.size() << '\n';
                    std::cout << "Exact passband median (20-60 Hz): " << designed.exactPassbandDb << " dB\n";
                    std::cout << "Min-phase passband median (20-60 Hz): " << designed.activePassbandDb << " dB\n";
                    std::cout << "Dry all-pass: pure delay of " << designed.delaySamples << " samples ("
                              << (static_cast<double>(designed.delaySamples) / cfg.sampleRate * 1000.0) << " ms)\n";
                    std::cout << "Phase-fit band: " << cfg.phaseFitFminHz << " Hz to " << cfg.phaseFitFmaxHz << " Hz\n";
                    std::cout << "LFE path: Python-style same-length min-phase FIR on LFE, dry stereo path aligned by best pure delay\n";
                }
            }
            std::cout << "Press Ctrl+C to stop.\n";

            const bool emitStatus = cfg.showActiveInputs || cfg.showOutputMeter;
            auto nextStatusTick = std::chrono::steady_clock::now();
            while (!g_shouldStop.load(std::memory_order_relaxed)) {
                if (emitStatus) {
                    const uint32_t mask = bundle.state.recentActiveMask.exchange(0, std::memory_order_relaxed);
                    const double peakLeft = bundle.state.recentOutputPeakLeft.exchange(0.0, std::memory_order_relaxed);
                    const double peakRight = bundle.state.recentOutputPeakRight.exchange(0.0, std::memory_order_relaxed);
                    const uint32_t clipFlags = bundle.state.recentClipFlags.exchange(0, std::memory_order_relaxed);

                    std::ostringstream status;
                    status << "\rStatus: active=" << activeInputsToString(mask, cfg.inputMap);
                    if (cfg.showOutputMeter) {
                        status << " | meterL=" << dbfsString(peakLeft) << " dBFS";
                        status << " | meterR=" << dbfsString(peakRight) << " dBFS";
                        status << " | clipL=" << (((clipFlags & 0x1u) != 0) ? 1 : 0);
                        status << " | clipR=" << (((clipFlags & 0x2u) != 0) ? 1 : 0);
                    }
                    status << "          ";
                    std::cout << status.str() << std::flush;
                    nextStatusTick += std::chrono::milliseconds(cfg.statusUpdateIntervalMs);
                    std::this_thread::sleep_until(nextStatusTick);
                } else {
                    Pa_Sleep(20);
                }
            }
            if (cfg.showActiveInputs || cfg.showOutputMeter) std::cout << "\n";

            err = Pa_StopStream(stream);
            if (err != paNoError) std::cerr << "Pa_StopStream warning: " << Pa_GetErrorText(err) << '\n';
            err = Pa_CloseStream(stream);
            if (err != paNoError) std::cerr << "Pa_CloseStream warning: " << Pa_GetErrorText(err) << '\n';

            std::cout << "\nCallbacks:         " << bundle.state.callbackCount.load() << '\n';
            std::cout << "Input underflows:  " << bundle.state.inputUnderflows.load() << '\n';
            std::cout << "Input overflows:   " << bundle.state.inputOverflows.load() << '\n';
            std::cout << "Output underflows: " << bundle.state.outputUnderflows.load() << '\n';
            std::cout << "Output overflows:  " << bundle.state.outputOverflows.load() << '\n';

            Pa_Terminate();
            return 0;
        } catch (...) {
            Pa_Terminate();
            throw;
        }
    } catch (const std::exception& e) {
        std::cerr << "Error: " << e.what() << '\n';
        return 1;
    }
}
