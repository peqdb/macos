#!/usr/bin/env python3
import json
import os
import re
import sys
import signal
import socket
import subprocess
import threading
import time
import uuid
import webbrowser
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from urllib.parse import parse_qs, urlparse

BED_LABELS = [
    "L", "R", "C", "LFE", "Ls", "Rs", "Lrs", "Rrs",
    "Lw", "Rw", "Ltf", "Rtf", "Ltm", "Rtm", "Ltr", "Rtr"
]

LAYOUT_PRESETS = {
    "9.1.6 bed (1:1)": [1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16],
    "7.1.4":           [1, 2, 3, 4, 5, 6, 7, 8, 0, 0, 9, 10, 11, 12, 0, 0],
    "7.1.2":           [1, 2, 3, 4, 5, 6, 7, 8, 0, 0, 9, 10, 0, 0, 0, 0],
    "7.1":             [1, 2, 3, 4, 5, 6, 7, 8, 0, 0, 0, 0, 0, 0, 0, 0],
    "5.1.4":           [1, 2, 3, 4, 5, 6, 0, 0, 0, 0, 7, 8, 9, 10, 0, 0],
    "5.1.2":           [1, 2, 3, 4, 5, 6, 0, 0, 0, 0, 7, 8, 0, 0, 0, 0],
    "5.1":             [1, 2, 3, 4, 5, 6, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0],
    "3.1":             [1, 2, 3, 4, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0],
    "3.0":             [1, 2, 3, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0],
    "2.1":             [1, 2, 0, 3, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0],
    "2.0 stereo":      [1, 2, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0],
}

DEVICE_RE = re.compile(r"^\[(\d+)\]\s*(?:\[default-in\]\s*)?(?:\[default-out\]\s*)?(.*?)\s*\|\s*in:\s*(\d+)\s*\|\s*out:\s*(\d+)")
STATUS_RE = re.compile(
    r"Status:\s*active=(.*?)\s*\|\s*meterL=([^\s]+)\s+dBFS\s*\|\s*meterR=([^\s]+)\s+dBFS\s*\|\s*clipL=(\d+)\s*\|\s*clipR=(\d+)"
)
ACTIVE_ITEM_RE = re.compile(r"\d+\(([^)]+)\)")
PREFS_PATH = Path.home() / ".bed_renderer_web_launcher.json"

def bundled_path(name: str) -> str:
    candidates = []

    meipass = getattr(sys, "_MEIPASS", None)
    if meipass:
        candidates.append(Path(meipass) / name)

    script_dir = Path(__file__).resolve().parent
    exe_dir = Path(sys.executable).resolve().parent

    candidates.extend([
        script_dir / name,
        exe_dir / name,
        exe_dir.parent / "Resources" / name,
        Path.cwd() / name,
    ])

    for candidate in candidates:
        if candidate.exists():
            return str(candidate)

    return str(script_dir / name)

DEFAULT_PREFS = {
    "exe": bundled_path("bed_renderer_916_low_latency"),
    "preset": "9.1.6 bed (1:1)",
    "frames": "64",
    "input_channels": "16",
    "threshold": "-60",
    "swap": False,
    "clip": False,
    "input_device": "",
    "output_device": "",
    "input_collapsed": False,
    "output_collapsed": False,
    "map": [str(x) for x in LAYOUT_PRESETS["9.1.6 bed (1:1)"]],
}

HTML = r'''<!doctype html>
<html>
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>Downmix Renderer</title>
<style>
:root{
  --bg:#101114; --panel:#181a1f; --panel2:#111318; --line:#333742; --text:#f0f3f8; --muted:#b5bcc9;
  --accent:#62a8ff; --good:#58d26d; --warn:#ffd166; --bad:#ff5d73; --stop:#7f8794;
}
*{box-sizing:border-box}
body{margin:0;background:linear-gradient(180deg,#0f1013,#151821);color:var(--text);font:16px -apple-system,BlinkMacSystemFont,Segoe UI,Roboto,sans-serif}
.wrap{max-width:1380px;margin:0 auto;padding:18px}
.card{background:linear-gradient(180deg,var(--panel),var(--panel2));border:1px solid var(--line);border-radius:16px;padding:16px 18px;margin-bottom:14px;box-shadow:0 12px 30px rgba(0,0,0,.18)}
.row{display:grid;gap:12px}
.r2{grid-template-columns:1fr 1fr}
.r3{grid-template-columns:repeat(3,1fr)}
.r4{grid-template-columns:repeat(4,1fr)}
.r5{grid-template-columns:2fr 1fr 1fr 1fr 1fr}
label{display:block;font-weight:700;margin-bottom:6px}
input,select,button{width:100%;font:inherit}
input,select{background:#07080b;color:var(--text);border:1px solid #3a3d46;border-radius:12px;padding:12px 14px}
input:focus,select:focus{outline:none;border-color:var(--accent);box-shadow:0 0 0 3px rgba(98,168,255,.16)}
button{background:#f4f6fa;color:#0d1016;border:0;border-radius:14px;padding:14px 16px;font-weight:800;cursor:pointer;transition:.12s transform,.12s opacity}
button:hover{transform:translateY(-1px)} button:active{transform:translateY(0)}
button.secondary{background:#2a2d35;color:var(--text);border:1px solid #454955}
button.stop{background:#2b2b2e;color:#fff;border:1px solid #44484f}
button:disabled{opacity:.45;cursor:not-allowed;transform:none}
.listwrap{display:grid;grid-template-columns:minmax(0,1fr) 16px;gap:10px;align-items:stretch}
.devicelist{
  height:230px; overflow:auto; padding:6px; border-radius:16px; border:1px solid #3a3d46;
  background:#050608; outline:none; scrollbar-width:none; -ms-overflow-style:none;
  transition:border-color .12s ease,box-shadow .12s ease;
}
.devicelist::-webkit-scrollbar{width:0;height:0;background:transparent}
.devicelist:hover,.devicelist:focus{border-color:var(--accent);box-shadow:0 0 0 3px rgba(98,168,255,.10)}
.devicerow{
  display:block; width:100%; padding:10px 12px; margin:0 0 2px 0; border-radius:12px;
  border:1px solid transparent; background:transparent; color:var(--text);
  cursor:pointer; font:inherit; text-align:left; white-space:nowrap; overflow:hidden; text-overflow:ellipsis;
  transition:background-color .08s ease,color .08s ease,border-color .08s ease,box-shadow .08s ease;
}
.devicerow:hover{background:rgba(98,168,255,.14);color:#f7fbff}
.devicerow.selected{background:rgba(98,168,255,.24);color:#ffffff;border-color:rgba(98,168,255,.55);box-shadow:inset 0 0 0 1px rgba(98,168,255,.22)}
.devicerow:focus-visible{outline:none;background:rgba(98,168,255,.18);border-color:rgba(98,168,255,.45)}
.scrollhint{position:relative;align-self:stretch;margin:8px 0;border-radius:999px;background:rgba(255,255,255,.08);border:1px solid rgba(255,255,255,.18);box-shadow:inset 0 0 0 1px rgba(0,0,0,.15);opacity:0;pointer-events:none;transition:opacity .12s ease,transform .12s ease;transform:translateX(2px)}
.scrollhintthumb{position:absolute;left:2px;right:2px;top:0;height:40px;border-radius:999px;background:linear-gradient(180deg, rgba(146,195,255,.98), rgba(91,156,255,.98));box-shadow:0 0 0 1px rgba(255,255,255,.22), 0 4px 10px rgba(0,0,0,.28)}
.listwrap:hover .scrollhint,.listwrap:focus-within .scrollhint,.listwrap.show-scrollbar .scrollhint{opacity:.98;transform:translateX(0)}
.listwrap.no-scroll .scrollhint{display:none}
.grid16{display:grid;grid-template-columns:repeat(4,1fr);gap:10px}
.pair{display:grid;grid-template-columns:56px 1fr;gap:8px;align-items:center}
.toolbar{display:flex;gap:10px;flex-wrap:wrap}
.toolbar button{width:auto;min-width:150px}
.collapsegrid{display:grid;grid-template-columns:1fr 1fr;gap:12px}
.collapse{background:transparent;border:0;margin:0;padding:0}
.collapse > summary{list-style:none;display:grid;grid-template-columns:minmax(0,1fr) auto auto;align-items:center;gap:12px;font-weight:800;font-size:22px;cursor:pointer;padding:6px 4px 12px 4px;user-select:none}
.collapse > summary::-webkit-details-marker{display:none}
.collapse > summary .summaryvalue{min-width:0;max-width:100%;font-size:15px;font-weight:650;color:var(--muted);white-space:nowrap;overflow:hidden;text-overflow:ellipsis;justify-self:end}
.collapse > summary::after{content:'▾';font-size:18px;color:var(--muted);transition:transform .14s ease,color .14s ease}
.collapse[open] > summary::after{transform:rotate(0deg);color:var(--text)}
.collapse:not([open]) > summary::after{transform:rotate(-90deg)}
.collapsebody{padding-top:0}
.statusline{display:flex;gap:14px;align-items:center;flex-wrap:wrap}
.pill{display:inline-flex;align-items:center;gap:10px;padding:12px 16px;border-radius:999px;font-weight:800;border:1px solid #434852;background:#262a33}
.pill .dot{width:10px;height:10px;border-radius:999px;background:#9096a3}
.pill.running{border-color:rgba(88,210,109,.55);background:rgba(88,210,109,.12);color:#e8fff0}
.pill.running .dot{background:var(--good)}
.pill.starting,.pill.stopping{border-color:rgba(255,209,102,.55);background:rgba(255,209,102,.12);color:#fff6d6}
.pill.starting .dot,.pill.stopping .dot{background:var(--warn)}
.pill.error,.pill.disconnected{border-color:rgba(255,93,115,.55);background:rgba(255,93,115,.12);color:#ffe9ed}
.pill.error .dot,.pill.disconnected .dot{background:var(--bad)}
.pill.stopped .dot{background:var(--stop)}
.hint{color:var(--muted)}
.badges{display:grid;grid-template-columns:repeat(8,1fr);gap:8px}
.badge{padding:11px;border-radius:12px;border:1px solid #444;background:#23262e;text-align:center;font-weight:800;color:#d8dce6}
.badge.on{background:rgba(88,210,109,.18);border-color:rgba(88,210,109,.55);color:#f3fff4}
pre{margin:0;height:250px;overflow:auto;background:#07080b;border:1px solid #3a3d46;border-radius:12px;padding:12px;white-space:pre-wrap;word-break:break-word;color:#d5dbe7}
.meters{display:grid;grid-template-columns:1fr 1fr;gap:12px}
.meter{background:#111318;border:1px solid var(--line);border-radius:14px;padding:12px}
.meterhead{display:flex;justify-content:space-between;align-items:center;margin-bottom:8px;gap:8px;flex-wrap:wrap}
.metername{font-weight:800}
.dbreadout{font-variant-numeric:tabular-nums;font-weight:800}
.clip{padding:6px 10px;border-radius:999px;border:1px solid #4a4f59;background:#23262e;color:#cfd5df;font-size:13px;font-weight:800}
.clip.on{background:rgba(255,93,115,.15);border-color:rgba(255,93,115,.55);color:#ffe8ec}
.track{height:22px;border-radius:999px;background:#08090b;border:1px solid #2c3037;overflow:hidden;position:relative}
.track::before{content:"";position:absolute;inset:0;background:linear-gradient(90deg,#4a7cff 0%,#67d5ff 38%,#6fe26c 60%,#c7ef66 72%,#ffd166 80%,#ff9f5a 88%,#ff6b63 94%,#ff5d73 100%)}
.fill{position:absolute;right:0;top:0;bottom:0;width:100%;background:rgba(8,9,11,.94);border-left:1px solid rgba(255,255,255,.12);box-shadow:inset 8px 0 18px rgba(0,0,0,.36);will-change:width,opacity;pointer-events:none}
.small{font-size:14px;color:var(--muted)}
.overlay{position:fixed;inset:0;background:rgba(10,10,10,.92);display:none;align-items:center;justify-content:center;z-index:1000;padding:24px}
.overlay.show{display:flex}
.overlay .box{max-width:560px;background:#1a1a1a;border:1px solid #444;border-radius:16px;padding:24px;text-align:center}
@media (max-width:1000px){.r5,.r4,.r3,.r2,.grid16,.badges,.meters,.collapsegrid{grid-template-columns:1fr 1fr}}
@media (max-width:720px){.r5,.r4,.r3,.r2,.grid16,.badges,.meters,.collapsegrid{grid-template-columns:1fr}}
</style>
</head>
<body>
<div id="overlay" class="overlay">
  <div class="box">
    <h2>Launcher disconnected</h2>
    <p id="overlaymsg">The launcher script stopped. This page will close or blank itself.</p>
  </div>
</div>
<div class="wrap">
  <div class="card">
    <div class="row r4">
      <div><label>Renderer executable</label><input id="exe"></div>
      <div><label>Layout preset</label><select id="preset"></select></div>
      <div><label>Frames/buffer</label><input id="frames"></div>
      <div><label>Input channels</label><input id="inch"></div>
    </div>
    <div class="small" style="margin-top:10px">Stereo fold-down mode is built into this launcher.</div>
    <div class="row r4" style="margin-top:12px">
      <div><label>Active threshold dBFS</label><input id="thr"></div>
      <div style="display:flex;align-items:end"><label><input type="checkbox" id="swap" style="width:auto;margin-right:8px">Swap outputs</label></div>
      <div style="display:flex;align-items:end"><label><input type="checkbox" id="clip" style="width:auto;margin-right:8px">Clip output</label></div>
      <div class="toolbar" style="align-items:end"><button id="refresh" class="secondary">Refresh devices</button></div>
    </div>
  </div>

  <div class="card">
    <div class="collapsegrid">
      <details class="collapse" id="indevdetails" open>
        <summary><span>Input device</span><span id="indevsummary" class="summaryvalue">No input selected</span></summary>
        <div class="collapsebody">
          <div class="listwrap" id="indevwrap">
            <div id="indevlist" class="devicelist" role="listbox" tabindex="0" aria-label="Input device"></div>
            <div class="scrollhint" aria-hidden="true"><div class="scrollhintthumb" id="indevthumb"></div></div>
          </div>
          <input id="indev" type="hidden">
        </div>
      </details>
      <details class="collapse" id="outdevdetails" open>
        <summary><span>Output device</span><span id="outdevsummary" class="summaryvalue">No output selected</span></summary>
        <div class="collapsebody">
          <div class="listwrap" id="outdevwrap">
            <div id="outdevlist" class="devicelist" role="listbox" tabindex="0" aria-label="Output device"></div>
            <div class="scrollhint" aria-hidden="true"><div class="scrollhintthumb" id="outdevthumb"></div></div>
          </div>
          <input id="outdev" type="hidden">
        </div>
      </details>
    </div>
  </div>

  <div class="card">
    <label>Bed-channel input map (1-based source channel, 0 = mute)</label>
    <div id="mapgrid" class="grid16"></div>
    <div class="toolbar" style="margin-top:14px">
      <button id="apply">Apply preset</button>
      <button id="start">Start</button>
      <button id="stop" class="stop">Stop</button>
    </div>
    <div class="statusline" style="margin-top:14px">
      <div id="runstate" class="pill stopped"><span class="dot"></span><span id="runtext">Stopped</span></div>
      <div id="statusmsg" class="hint">Stereo renderer is idle.</div>
    </div>
  </div>

  <div class="card">
    <div class="row r2">
      <div>
        <label>Active bed inputs</label>
        <div id="badges" class="badges"></div>
      </div>
      <div>
        <label>Stereo sum output meter</label>
        <div class="meters">
          <div class="meter">
            <div class="meterhead">
              <div class="metername">Left sum</div>
              <div class="dbreadout" id="meterLdb">-inf dBFS</div>
              <div class="clip" id="clipL">No clip</div>
            </div>
            <div class="track"><div class="fill" id="meterLfill"></div></div>
          </div>
          <div class="meter">
            <div class="meterhead">
              <div class="metername">Right sum</div>
              <div class="dbreadout" id="meterRdb">-inf dBFS</div>
              <div class="clip" id="clipR">No clip</div>
            </div>
            <div class="track"><div class="fill" id="meterRfill"></div></div>
          </div>
        </div>
        <div class="small" style="margin-top:12px">Meters show recent sample-peak level of the stereo output channels. Clip indicators latch briefly when output exceeds 0 dBFS before optional hard clipping.</div>
      </div>
    </div>
  </div>

  <div class="card">
    <label>Renderer log (read-only)</label>
    <pre id="log"></pre>
  </div>
</div>
<script>
const BED_LABELS = %BED_LABELS%;
const LAYOUT_PRESETS = %LAYOUT_PRESETS%;
const CLIENT_ID = %CLIENT_ID%;
const EMBEDDED_MODE = %EMBEDDED_MODE%;
let disconnected = false;
let disconnectFailures = 0;
let heartbeatTimer = null;
let pollTimer = null;
let saveTimer = null;
let clipHoldUntilL = 0;
let clipHoldUntilR = 0;
let currentPhase = 'stopped';
let applyBusy = false;
let logTimer = null;
let meterAnimHandle = null;
let meterAnimLastTs = 0;
const meterState = {
  L: {target: 0, current: 0, dbText: '-inf'},
  R: {target: 0, current: 0, dbText: '-inf'}
};

const $ = s => document.querySelector(s);

function mapGrid(){
  const g = $('#mapgrid');
  g.innerHTML = '';
  BED_LABELS.forEach((lab,i)=>{
    const d = document.createElement('div');
    d.className = 'pair';
    d.innerHTML = `<div>${lab}</div><input id="m${i}" inputmode="numeric">`;
    g.appendChild(d);
  });
}
function badges(){
  const g = $('#badges');
  BED_LABELS.forEach(l=>{
    const d = document.createElement('div');
    d.className = 'badge';
    d.id = 'b_' + l;
    d.textContent = l;
    g.appendChild(d);
  });
}
function fillPresets(){
  const p = $('#preset');
  p.innerHTML = '';
  Object.keys(LAYOUT_PRESETS).forEach(k=>{
    const o = document.createElement('option');
    o.value = k;
    o.textContent = k;
    p.appendChild(o);
  });
}
function applyPreset(save=true){
  const arr = LAYOUT_PRESETS[$('#preset').value] || LAYOUT_PRESETS['9.1.6 bed (1:1)'];
  arr.forEach((v,i)=>$('#m'+i).value = String(v));
  if(save) scheduleSavePrefs();
}
function meterWidth(dbText){
  if(dbText === '-inf') return 0;
  const db = Number(dbText);
  if(!Number.isFinite(db)) return 0;
  if(db >= 0) return 100;
  if(db <= -60) return 0;
  if(db <= -30) return ((db + 60) / 30) * 40;
  if(db <= -18) return 40 + ((db + 30) / 12) * 24;
  if(db <= -9) return 64 + ((db + 18) / 9) * 18;
  if(db <= -3) return 82 + ((db + 9) / 6) * 12;
  return 94 + ((db + 3) / 3) * 6;
}
function meterCoverWidth(percent){
  return Math.max(0, Math.min(100, 100 - percent));
}
function renderMeter(side, percent){
  const fill = $('#meter' + side + 'fill');
  const cover = meterCoverWidth(percent);
  fill.style.width = `${cover.toFixed(2)}%`;
  const hidden = cover <= 0.05;
  fill.style.opacity = hidden ? '0' : '1';
  fill.style.borderLeftWidth = hidden ? '0px' : '1px';
  fill.style.boxShadow = hidden ? 'none' : 'inset 8px 0 18px rgba(0,0,0,.36)';
}
function animateMeters(ts){
  if(!meterAnimLastTs) meterAnimLastTs = ts;
  const dt = Math.min(0.05, Math.max(0.001, (ts - meterAnimLastTs) / 1000));
  meterAnimLastTs = ts;
  for(const side of ['L', 'R']){
    const m = meterState[side];
    if(m.target > m.current){
      const attackRate = 55.0;
      const alpha = 1 - Math.exp(-attackRate * dt);
      m.current += (m.target - m.current) * alpha;
      const floor = Math.max(0, m.target - 2.5);
      if(m.current < floor) m.current = floor;
      if(m.target - m.current < 0.15 || m.target >= 99.9) m.current = m.target;
    }else if(m.target < m.current){
      const releaseRate = 10.0;
      const alpha = 1 - Math.exp(-releaseRate * dt);
      m.current += (m.target - m.current) * alpha;
      if(m.current - m.target < 0.03) m.current = m.target;
    }
    renderMeter(side, m.current);
  }
  meterAnimHandle = requestAnimationFrame(animateMeters);
}
function setMeter(side, dbText, clipped){
  const dbEl = $('#meter' + side + 'db');
  const clip = $('#clip' + side);
  const m = meterState[side];
  m.dbText = dbText;
  m.target = meterWidth(dbText);
  if(m.target >= 99.9) m.current = m.target;
  dbEl.textContent = `${dbText} dBFS`;
  if(clipped){
    if(side === 'L') clipHoldUntilL = Date.now() + 1200;
    else clipHoldUntilR = Date.now() + 1200;
  }
  const hold = side === 'L' ? clipHoldUntilL : clipHoldUntilR;
  const on = Date.now() < hold;
  clip.className = 'clip' + (on ? ' on' : '');
  clip.textContent = on ? 'CLIP' : 'No clip';
}
function setRunState(phase, msg){
  currentPhase = phase || 'stopped';
  const pill = $('#runstate');
  const text = $('#runtext');
  pill.className = 'pill ' + phase;
  const labels = {
    stopped: 'Stopped',
    starting: 'Starting…',
    running: 'Running',
    stopping: 'Stopping…',
    error: 'Error',
    disconnected: 'Disconnected'
  };
  text.textContent = labels[phase] || phase;
  $('#statusmsg').textContent = msg || '';
}
async function waitForPhases(phases, timeoutMs=4000){
  const wanted = new Set(phases);
  const start = Date.now();
  while(Date.now() - start < timeoutMs){
    try{
      const r = await fetch('/api/status', {cache:'no-store'});
      if(!r.ok) throw new Error('status fetch failed');
      const j = await r.json();
      if(wanted.has(j.phase)) return j;
    }catch(e){}
    await new Promise(resolve => setTimeout(resolve, 80));
  }
  throw new Error('Timed out waiting for renderer state change.');
}
async function applyPresetAndRestart(){
  if(applyBusy) return;
  applyBusy = true;
  try{
    applyPreset(false);
    await savePrefsNow();
    const shouldRestart = currentPhase === 'running' || currentPhase === 'starting' || currentPhase === 'stopping';
    if(shouldRestart){
      setRunState('stopping', 'Applying preset and restarting renderer…');
      await fetch('/api/stop', {method:'POST'});
      await waitForPhases(['stopped','error'], 5000);
    }
    setRunState('starting', shouldRestart ? 'Restarting renderer with updated settings…' : 'Starting renderer with applied settings…');
    const r = await fetch('/api/start', {
      method:'POST',
      headers:{'Content-Type':'application/json'},
      body: JSON.stringify(currentPayload())
    });
    const j = await r.json();
    if(!j.ok){
      setRunState('error', j.error || 'Could not start renderer.');
      alert(j.error || 'Could not start renderer.');
      return;
    }
    await waitForPhases(['running','error'], 5000).catch(()=>{});
  }catch(e){
    setRunState('error', e && e.message ? e.message : 'Could not apply preset.');
    alert(e && e.message ? e.message : 'Could not apply preset.');
  }finally{
    applyBusy = false;
  }
}

function currentPayload(){
  return {
    exe: $('#exe').value.trim(),
    preset: $('#preset').value,
    frames: $('#frames').value.trim(),
    input_channels: $('#inch').value.trim(),
    threshold: $('#thr').value.trim(),
    swap: $('#swap').checked,
    clip: $('#clip').checked,
    input_device: $('#indev').value,
    output_device: $('#outdev').value,
    input_collapsed: !document.getElementById('indevdetails').open,
    output_collapsed: !document.getElementById('outdevdetails').open,
    map: BED_LABELS.map((_,i)=>( $('#m'+i).value.trim() || '0' )),
  };
}
async function savePrefsNow(){
  try{
    await fetch('/api/preferences', {
      method:'POST',
      headers:{'Content-Type':'application/json'},
      body: JSON.stringify(currentPayload()),
      keepalive: true
    });
  }catch(e){}
}
function scheduleSavePrefs(){
  clearTimeout(saveTimer);
  saveTimer = setTimeout(savePrefsNow, 120);
}
function updateDeviceSummary(hiddenInput){
  const summaryId = hiddenInput.id === 'indev' ? '#indevsummary' : '#outdevsummary';
  const listId = hiddenInput.id === 'indev' ? '#indevlist' : '#outdevlist';
  const el = $(summaryId);
  const listEl = $(listId);
  if(!el || !listEl) return;
  const selected = listEl.querySelector('.devicerow.selected');
  const text = selected ? (selected.dataset.label || selected.textContent || '') : (hiddenInput.id === 'indev' ? 'No input selected' : 'No output selected');
  el.textContent = text;
  el.title = text;
}
function installTransientScrollbar(scrollEl){
  const wrap = document.getElementById(scrollEl.id.replace('list', 'wrap'));
  const thumb = document.getElementById(scrollEl.id.replace('list', 'thumb'));
  const trackEl = wrap ? wrap.querySelector('.scrollhint') : null;
  if(!wrap || !thumb || !trackEl) return;
  let timer = null;
  const update = ()=>{
    const total = scrollEl.scrollHeight || 0;
    const visible = scrollEl.clientHeight || 0;
    if(total <= visible + 2){
      wrap.classList.add('no-scroll');
      thumb.style.transform = 'translateY(0px)';
      thumb.style.height = '0px';
      return;
    }
    wrap.classList.remove('no-scroll');
    const track = Math.max(0, trackEl.clientHeight - 2);
    const thumbHeight = Math.max(28, Math.round((visible / total) * track));
    const maxTop = Math.max(0, track - thumbHeight);
    const scrollTop = scrollEl.scrollTop || 0;
    const maxScroll = Math.max(1, total - visible);
    const top = Math.round((scrollTop / maxScroll) * maxTop);
    thumb.style.height = thumbHeight + 'px';
    thumb.style.transform = `translateY(${top}px)`;
  };
  const show = ()=>{
    update();
    wrap.classList.add('show-scrollbar');
    clearTimeout(timer);
    timer = setTimeout(()=>wrap.classList.remove('show-scrollbar'), 1500);
  };
  ['scroll','wheel','touchmove','keydown','mousemove','mouseenter','focus','mousedown'].forEach(evt=>{
    scrollEl.addEventListener(evt, show, {passive: evt !== 'keydown' && evt !== 'focus' && evt !== 'mousedown'});
  });
  wrap.addEventListener('mouseenter', show);
  wrap.addEventListener('mousemove', show);
  wrap.addEventListener('mouseleave', ()=>{ clearTimeout(timer); timer = setTimeout(()=>wrap.classList.remove('show-scrollbar'), 350); });
  scrollEl.addEventListener('focus', show);
  scrollEl.addEventListener('blur', ()=>wrap.classList.remove('show-scrollbar'));
  window.addEventListener('resize', update);
  requestAnimationFrame(update);
}
function selectDevice(kind, value, label, save=true){
  const hidden = $('#' + kind);
  const listEl = $('#' + kind + 'list');
  if(!hidden || !listEl) return;
  hidden.value = String(value || '');
  hidden.dataset.name = label || '';
  listEl.querySelectorAll('.devicerow').forEach(row=>{
    row.classList.toggle('selected', row.dataset.value === String(hidden.value));
    row.setAttribute('aria-selected', row.classList.contains('selected') ? 'true' : 'false');
  });
  updateDeviceSummary(hidden);
  listEl.dispatchEvent(new Event('scroll'));
  if(save) scheduleSavePrefs();
}
function renderDeviceRows(kind, items, preferredValue, preferredName){
  const hidden = $('#' + kind);
  const listEl = $('#' + kind + 'list');
  if(!hidden || !listEl) return;
  const prevValue = preferredValue || hidden.value;
  const prevName = preferredName || hidden.dataset.name || '';
  listEl.innerHTML = '';
  let wanted = '';
  if(items.length){
    if(prevValue && items.some(it => String(it.index) === String(prevValue))) {
      wanted = String(prevValue);
    } else if(prevName) {
      const match = items.find(it => it.name === prevName);
      if(match) wanted = String(match.index);
    }
    if(!wanted) wanted = String(items[0].index);
  }
  items.forEach(it=>{
    const row = document.createElement('button');
    row.type = 'button';
    row.className = 'devicerow';
    row.dataset.value = String(it.index);
    row.dataset.label = `[${it.index}] ${it.name}`;
    row.textContent = row.dataset.label;
    row.setAttribute('role', 'option');
    row.setAttribute('aria-selected', 'false');
    row.addEventListener('click', ()=>selectDevice(kind, it.index, it.name, true));
    listEl.appendChild(row);
  });
  if(items.length){
    const selectedItem = items.find(it => String(it.index) === String(wanted)) || items[0];
    selectDevice(kind, selectedItem.index, selectedItem.name, false);
  }else{
    hidden.value = '';
    hidden.dataset.name = '';
    updateDeviceSummary(hidden);
    listEl.dispatchEvent(new Event('scroll'));
  }
}
function setDevices(hiddenInput, items, preferredValue, preferredName){
  const kind = hiddenInput.id;
  renderDeviceRows(kind, items, preferredValue, preferredName);
}
async function loadPrefs(){
  const r = await fetch('/api/preferences', {cache:'no-store'});
  const p = await r.json();
  $('#exe').value = p.exe || '';
  $('#frames').value = p.frames || '64';
  $('#inch').value = p.input_channels || '16';
  $('#thr').value = p.threshold || '-60';
  $('#swap').checked = !!p.swap;
  $('#clip').checked = !!p.clip;
  document.getElementById('indevdetails').open = !p.input_collapsed;
  document.getElementById('outdevdetails').open = !p.output_collapsed;
  $('#preset').value = p.preset && LAYOUT_PRESETS[p.preset] ? p.preset : '9.1.6 bed (1:1)';
  const arr = Array.isArray(p.map) && p.map.length === BED_LABELS.length ? p.map : LAYOUT_PRESETS[$('#preset').value];
  arr.forEach((v,i)=>$('#m'+i).value = String(v));
  return p;
}
async function refreshDevices(){
  const prefs = await fetch('/api/preferences', {cache:'no-store'}).then(r=>r.json()).catch(()=>({}));
  const exe = encodeURIComponent($('#exe').value.trim());
  const r = await fetch('/api/devices?exe=' + exe, {cache:'no-store'});
  const j = await r.json();
  setDevices($('#indev'), j.inputs || [], prefs.input_device, prefs.input_device_name);
  setDevices($('#outdev'), j.outputs || [], prefs.output_device, prefs.output_device_name);
  scheduleSavePrefs();
  if(j.error){
    $('#log').textContent += 'Device refresh error: ' + j.error + '\n';
  }
}
async function startRenderer(){
  setRunState('starting', 'Launching stereo renderer…');
  await savePrefsNow();
  const r = await fetch('/api/start', {
    method:'POST',
    headers:{'Content-Type':'application/json'},
    body: JSON.stringify(currentPayload())
  });
  const j = await r.json();
  if(!j.ok){
    setRunState('error', j.error || 'Could not start renderer.');
    alert(j.error || 'Could not start renderer.');
  }
}
async function stopRenderer(){
  setRunState('stopping', 'Stopping renderer…');
  await fetch('/api/stop', {method:'POST'});
}
function handleDisconnect(){
  if(disconnected) return;
  disconnected = true;
  $('#overlay').classList.add('show');
  setRunState('disconnected', 'Launcher script stopped.');
  clearTimeout(pollTimer);
  clearInterval(heartbeatTimer);
  clearInterval(logTimer);
  try{ window.close(); }catch(e){}
  setTimeout(()=>{ try{ window.open('', '_self'); window.close(); }catch(e){} }, 120);
  setTimeout(()=>{ try{ location.replace('about:blank'); }catch(e){} }, 500);
}
async function poll(){
  try{
    const r = await fetch('/api/status', {cache:'no-store'});
    if(!r.ok) throw new Error('status fetch failed');
    const j = await r.json();
    disconnectFailures = 0;
    const active = new Set(j.active_labels || []);
    BED_LABELS.forEach(l => $('#b_'+l).className = 'badge' + (active.has(l) ? ' on' : ''));
    setMeter('L', j.meter_left_db || '-inf', !!j.clip_left);
    setMeter('R', j.meter_right_db || '-inf', !!j.clip_right);
    if(typeof j.log_revision === 'number' && j.log_revision !== lastLogRevision){
      lastLogRevision = j.log_revision;
      refreshLog();
    }
    setRunState(j.phase || 'stopped', j.status_text || 'Stereo renderer is idle.');
    $('#start').disabled = (j.phase === 'running' || j.phase === 'starting');
    $('#stop').disabled = (j.phase === 'stopped' || j.phase === 'error' || j.phase === 'disconnected');
  }catch(e){
    disconnectFailures += 1;
    if(disconnectFailures >= 8){
      handleDisconnect();
      return;
    }
    pollTimer = setTimeout(poll, 250);
    return;
  }
  pollTimer = setTimeout(poll, 1000 / 30);
}
async function refreshLog(){
  try{
    const r = await fetch('/api/log', {cache:'no-store'});
    if(!r.ok) throw new Error('log fetch failed');
    const j = await r.json();
    lastLogRevision = (typeof j.log_revision === 'number') ? j.log_revision : lastLogRevision;
    const nextLog = j.log || '';
    if($('#log').textContent !== nextLog){
      $('#log').textContent = nextLog;
      $('#log').scrollTop = $('#log').scrollHeight;
    }
  }catch(e){}
}
async function heartbeat(){
  try{
    await fetch('/api/client_ping', {
      method:'POST',
      headers:{'Content-Type':'application/json'},
      body: JSON.stringify({client_id: CLIENT_ID}),
      keepalive: true
    });
  }catch(e){
    // Let status polling decide when the launcher is truly gone.
  }
}
function notifyClose(){
  if(EMBEDDED_MODE) return;
  const data = JSON.stringify({client_id: CLIENT_ID});
  try{
    navigator.sendBeacon('/api/client_close', new Blob([data], {type:'application/json'}));
  }catch(e){
    try{
      fetch('/api/client_close', {
        method:'POST',
        headers:{'Content-Type':'application/json'},
        body: data,
        keepalive: true
      });
    }catch(_e){}
  }
}

mapGrid();
badges();
fillPresets();

document.querySelectorAll('input,select').forEach(el => {
  el.addEventListener('change', scheduleSavePrefs);
  el.addEventListener('input', scheduleSavePrefs);
});
$('#apply').onclick = applyPresetAndRestart;
$('#refresh').onclick = refreshDevices;
$('#start').onclick = startRenderer;
$('#stop').onclick = stopRenderer;
$('#preset').addEventListener('change', ()=>applyPreset(true));
document.getElementById('indevdetails').addEventListener('toggle', ()=>{ updateDeviceSummary($('#indev')); savePrefsNow(); });
document.getElementById('outdevdetails').addEventListener('toggle', ()=>{ updateDeviceSummary($('#outdev')); savePrefsNow(); });
installTransientScrollbar($('#indevlist'));
installTransientScrollbar($('#outdevlist'));

if(!EMBEDDED_MODE){
  window.addEventListener('pagehide', notifyClose);
  window.addEventListener('beforeunload', notifyClose);
}

(async function init(){
  const prefs = await loadPrefs();
  await fetch('/api/client_open', {
    method:'POST',
    headers:{'Content-Type':'application/json'},
    body: JSON.stringify({client_id: CLIENT_ID})
  }).catch(()=>{});
  await refreshDevices();
  if(prefs.input_device) $('#indev').value = String(prefs.input_device);
  if(prefs.output_device) $('#outdev').value = String(prefs.output_device);
  updateDeviceSummary($('#indev'));
  updateDeviceSummary($('#outdev'));
  heartbeatTimer = setInterval(heartbeat, 2000);
  logTimer = setInterval(refreshLog, 250);
  renderMeter('L', 0);
  renderMeter('R', 0);
  meterAnimHandle = requestAnimationFrame(animateMeters);
  refreshLog();
  poll();
})();
</script>
</body>
</html>'''

def load_preferences():
    prefs = dict(DEFAULT_PREFS)
    try:
        if PREFS_PATH.exists():
            raw = json.loads(PREFS_PATH.read_text())
            if isinstance(raw, dict):
                prefs.update({k: v for k, v in raw.items() if k in prefs or k.endswith("_name")})
    except Exception:
        pass
    if not isinstance(prefs.get("map"), list) or len(prefs["map"]) != len(BED_LABELS):
        prefs["map"] = list(DEFAULT_PREFS["map"])
    prefs["exe"] = prefs.get("exe") or DEFAULT_PREFS["exe"]
    if not os.path.exists(str(prefs["exe"])):
        prefs["exe"] = DEFAULT_PREFS["exe"]
    return prefs

def save_preferences(prefs):
    clean = dict(DEFAULT_PREFS)
    clean.update(prefs or {})
    if not isinstance(clean.get("map"), list) or len(clean["map"]) != len(BED_LABELS):
        clean["map"] = list(DEFAULT_PREFS["map"])
    try:
        PREFS_PATH.write_text(json.dumps(clean, indent=2))
    except Exception:
        pass
    return clean

class RendererState:
    def __init__(self):
        self.lock = threading.Lock()
        self.proc = None
        self.server = None
        self.shutdown_requested = False
        self.renderer_stop_requested = False
        self.clients = {}
        self.ever_had_client = False
        self.active_labels = []
        self.last_active = "(none)"
        self.meter_left_db = "-inf"
        self.meter_right_db = "-inf"
        self.clip_left = False
        self.clip_right = False
        self.phase = "stopped"
        self.status_text = "Stereo renderer is idle."
        self.last_exit_code = None
        self.log_lines = []
        self.max_log_lines = 2000
        self.log_revision = 0
        self.log_cache = ""
        self.preferences = load_preferences()
        self.client_shutdown_timer = None

    def append_log(self, line):
        line = line.rstrip("\n")
        if not line:
            return
        with self.lock:
            self.log_lines.append(line)
            if len(self.log_lines) > self.max_log_lines:
                self.log_lines = self.log_lines[-self.max_log_lines:]
            self.log_cache = "\n".join(self.log_lines[-1200:])
            self.log_revision += 1

    def status(self):
        with self.lock:
            return {
                "phase": self.phase,
                "status_text": self.status_text,
                "active_labels": list(self.active_labels),
                "last_active": self.last_active,
                "meter_left_db": self.meter_left_db,
                "meter_right_db": self.meter_right_db,
                "clip_left": self.clip_left,
                "clip_right": self.clip_right,
                "log_revision": self.log_revision,
            }

    def log_payload(self):
        with self.lock:
            return {
                "log_revision": self.log_revision,
                "log": self.log_cache,
            }

    def register_client(self, client_id):
        with self.lock:
            self.clients[client_id] = time.time()
            self.ever_had_client = True
            timer = self.client_shutdown_timer
            self.client_shutdown_timer = None
        if timer is not None:
            try:
                timer.cancel()
            except Exception:
                pass

    def unregister_client(self, client_id):
        with self.lock:
            self.clients.pop(client_id, None)

    def touch_client(self, client_id):
        with self.lock:
            self.clients[client_id] = time.time()
            timer = self.client_shutdown_timer
            self.client_shutdown_timer = None
        if timer is not None:
            try:
                timer.cancel()
            except Exception:
                pass

    def live_client_count(self, stale_after=6.0):
        now = time.time()
        with self.lock:
            stale = [cid for cid, ts in self.clients.items() if now - ts > stale_after]
            for cid in stale:
                self.clients.pop(cid, None)
            return len(self.clients)

STATE = RendererState()


def cancel_pending_client_shutdown():
    with STATE.lock:
        timer = STATE.client_shutdown_timer
        STATE.client_shutdown_timer = None
    if timer is not None:
        try:
            timer.cancel()
        except Exception:
            pass

def schedule_shutdown_if_no_clients(delay=2.5, reason="Launcher page closed. Shutting down launcher."):
    cancel_pending_client_shutdown()

    def _maybe_shutdown():
        with STATE.lock:
            if STATE.shutdown_requested:
                return
        if STATE.live_client_count() == 0:
            request_shutdown(reason)

    timer = threading.Timer(delay, _maybe_shutdown)
    timer.daemon = True
    with STATE.lock:
        if STATE.shutdown_requested:
            return
        STATE.client_shutdown_timer = timer
    timer.start()


def terminate_renderer():
    with STATE.lock:
        proc = STATE.proc
    if proc is not None and proc.poll() is None:
        try:
            proc.send_signal(signal.SIGINT)
            proc.wait(timeout=1.0)
        except Exception:
            try:
                proc.terminate()
                proc.wait(timeout=1.0)
            except Exception:
                try:
                    proc.kill()
                except Exception:
                    pass
    with STATE.lock:
        STATE.proc = None
        STATE.active_labels = []
        STATE.last_active = "(none)"
        STATE.meter_left_db = "-inf"
        STATE.meter_right_db = "-inf"
        STATE.clip_left = False
        STATE.clip_right = False

def request_shutdown(reason=""):
    cancel_pending_client_shutdown()
    with STATE.lock:
        if STATE.shutdown_requested:
            return
        STATE.shutdown_requested = True
        STATE.phase = "disconnected"
        STATE.status_text = "Launcher is shutting down."
    if reason:
        STATE.append_log(reason)
    terminate_renderer()
    server = STATE.server
    if server is not None:
        threading.Thread(target=server.shutdown, daemon=True).start()

def client_watchdog():
    # Intentionally disabled. The earlier heartbeat-based auto-shutdown could
    # incorrectly terminate the launcher when the browser throttled timers,
    # the tab went into the background, or the machine briefly slept.
    # Explicit page-close notifications still shut the launcher down.
    while True:
        time.sleep(1.0)
        with STATE.lock:
            if STATE.shutdown_requested:
                return

def list_devices(exe_path):
    proc = subprocess.run([exe_path, "--list-devices"], capture_output=True, text=True, check=True)
    inputs, outputs = [], []
    for line in proc.stdout.splitlines():
        m = DEVICE_RE.match(line.strip())
        if not m:
            continue
        idx, name, ins, outs = m.groups()
        item = {"index": int(idx), "name": name.strip(), "inputs": int(ins), "outputs": int(outs)}
        if item["inputs"] > 0:
            inputs.append(item)
        if item["outputs"] > 0:
            outputs.append(item)
    return inputs, outputs

def update_runtime_status_from_line(line):
    m = STATUS_RE.search(line)
    if not m:
        return False
    active_text, meter_l, meter_r, clip_l, clip_r = m.groups()
    active_labels = ACTIVE_ITEM_RE.findall(active_text) if active_text and active_text != "(none)" else []
    with STATE.lock:
        STATE.active_labels = active_labels
        STATE.last_active = active_text.strip() or "(none)"
        STATE.meter_left_db = meter_l
        STATE.meter_right_db = meter_r
        STATE.clip_left = (clip_l == "1")
        STATE.clip_right = (clip_r == "1")
    return True

def reader_worker(proc):
    stream = proc.stdout
    if stream is None:
        return
    buffer = ""
    try:
        while True:
            chunk = os.read(stream.fileno(), 4096)
            if not chunk:
                break
            buffer += chunk.decode("utf-8", errors="replace")
            parts = re.split(r"\r|\n", buffer)
            buffer = parts.pop() if parts else ""
            for line in parts:
                if update_runtime_status_from_line(line):
                    continue
                STATE.append_log(line)
    except Exception as exc:
        STATE.append_log(f"Reader error: {exc}")
    rc = proc.wait()
    with STATE.lock:
        STATE.proc = None
        stop_requested = STATE.renderer_stop_requested
        STATE.renderer_stop_requested = False
        if STATE.shutdown_requested:
            STATE.phase = "disconnected"
            STATE.status_text = "Launcher is shutting down."
        elif stop_requested or rc == 0:
            STATE.phase = "stopped"
            STATE.status_text = "Renderer stopped."
        else:
            STATE.phase = "error"
            STATE.status_text = f"Renderer exited with code {rc}."
        STATE.last_exit_code = rc
        STATE.active_labels = []
        STATE.last_active = "(none)"
        STATE.meter_left_db = "-inf"
        STATE.meter_right_db = "-inf"
        STATE.clip_left = False
        STATE.clip_right = False
    STATE.append_log(f"Renderer exited with code {rc}.")

class Handler(BaseHTTPRequestHandler):
    def _send(self, code, body, content_type="application/json; charset=utf-8"):
        data = body if isinstance(body, (bytes, bytearray)) else body.encode("utf-8")
        self.send_response(code)
        self.send_header("Content-Type", content_type)
        self.send_header("Content-Length", str(len(data)))
        self.send_header("Cache-Control", "no-store")
        self.end_headers()
        self.wfile.write(data)

    def _json_body(self):
        length = int(self.headers.get("Content-Length", "0") or "0")
        raw = self.rfile.read(length) if length else b"{}"
        return json.loads(raw.decode("utf-8"))

    def do_GET(self):
        parsed = urlparse(self.path)
        if parsed.path == "/":
            page = (HTML
                .replace("%BED_LABELS%", json.dumps(BED_LABELS))
                .replace("%LAYOUT_PRESETS%", json.dumps(LAYOUT_PRESETS))
                .replace("%CLIENT_ID%", json.dumps(str(uuid.uuid4())))
                .replace("%EMBEDDED_MODE%", json.dumps(parse_qs(parsed.query).get("embedded", ["0"])[0] == "1")))
            return self._send(200, page, "text/html; charset=utf-8")
        if parsed.path == "/api/status":
            return self._send(200, json.dumps(STATE.status()))
        if parsed.path == "/api/log":
            return self._send(200, json.dumps(STATE.log_payload()))
        if parsed.path == "/api/preferences":
            with STATE.lock:
                prefs = dict(STATE.preferences)
            return self._send(200, json.dumps(prefs))
        if parsed.path == "/api/devices":
            exe = parse_qs(parsed.query).get("exe", [STATE.preferences.get("exe", DEFAULT_PREFS["exe"])])[0]
            try:
                inputs, outputs = list_devices(exe)
                with STATE.lock:
                    STATE.preferences["exe"] = exe
                    STATE.preferences = save_preferences(STATE.preferences)
                return self._send(200, json.dumps({"inputs": inputs, "outputs": outputs}))
            except Exception as exc:
                return self._send(200, json.dumps({"inputs": [], "outputs": [], "error": str(exc)}))
        return self._send(404, json.dumps({"ok": False, "error": "Not found"}))

    def _save_preferences(self, data):
        indev_name = ""
        outdev_name = ""
        exe = data.get("exe", STATE.preferences.get("exe", DEFAULT_PREFS["exe"]))
        try:
            inputs, outputs = list_devices(exe)
            indev = str(data.get("input_device", "")).strip()
            outdev = str(data.get("output_device", "")).strip()
            for item in inputs:
                if str(item["index"]) == indev:
                    indev_name = item["name"]
            for item in outputs:
                if str(item["index"]) == outdev:
                    outdev_name = item["name"]
        except Exception:
            pass
        with STATE.lock:
            prefs = dict(STATE.preferences)
            prefs.update(data)
            if indev_name:
                prefs["input_device_name"] = indev_name
            if outdev_name:
                prefs["output_device_name"] = outdev_name
            STATE.preferences = save_preferences(prefs)
            return dict(STATE.preferences)

    def do_POST(self):
        if self.path == "/api/preferences":
            try:
                data = self._json_body()
                prefs = self._save_preferences(data)
                return self._send(200, json.dumps({"ok": True, "preferences": prefs}))
            except Exception as exc:
                return self._send(200, json.dumps({"ok": False, "error": str(exc)}))

        if self.path == "/api/start":
            try:
                data = self._json_body()
                exe = str(data["exe"]).strip()
                if not exe or not os.path.exists(exe):
                    raise ValueError(f"Renderer executable not found: {exe}")
                input_device = str(data["input_device"]).strip()
                output_device = str(data["output_device"]).strip()
                if not input_device or not output_device:
                    raise ValueError("Select both an input device and an output device.")
                cmd = [
                    exe,
                    "--input-device", input_device,
                    "--output-device", output_device,
                    "--frames-per-buffer", str(int(data["frames"])),
                    "--input-channels", str(int(data["input_channels"])),
                    "--stereo-matrix-mode", "adc2-direct",
                    "--show-active-inputs",
                    "--show-output-meter",
                    "--active-threshold-db", str(float(data["threshold"])),
                    "--input-map", ",".join(str(x).strip() or "0" for x in data["map"]),
                ]
                if data.get("swap"):
                    cmd.append("--swap-outputs")
                if data.get("clip"):
                    cmd.append("--clip-output")
                with STATE.lock:
                    if STATE.proc is not None and STATE.proc.poll() is None:
                        raise ValueError("Renderer is already running.")
                    STATE.phase = "starting"
                    STATE.status_text = "Launching stereo renderer…"
                    STATE.renderer_stop_requested = False
                    STATE.active_labels = []
                    STATE.last_active = "(none)"
                    STATE.meter_left_db = "-inf"
                    STATE.meter_right_db = "-inf"
                    STATE.clip_left = False
                    STATE.clip_right = False
                    STATE.log_lines.clear()
                    STATE.log_cache = ""
                    STATE.log_revision += 1
                self._save_preferences(data)
                proc = subprocess.Popen(cmd, stdout=subprocess.PIPE, stderr=subprocess.STDOUT, bufsize=0)
                with STATE.lock:
                    STATE.proc = proc
                    STATE.phase = "running"
                    STATE.status_text = "Stereo renderer is running."
                STATE.append_log("Launching:")
                STATE.append_log(" ".join(cmd))
                threading.Thread(target=reader_worker, args=(proc,), daemon=True).start()
                return self._send(200, json.dumps({"ok": True}))
            except Exception as exc:
                with STATE.lock:
                    STATE.phase = "error"
                    STATE.status_text = str(exc)
                return self._send(200, json.dumps({"ok": False, "error": str(exc)}))

        if self.path == "/api/stop":
            with STATE.lock:
                STATE.phase = "stopping"
                STATE.status_text = "Stopping renderer…"
                STATE.renderer_stop_requested = True
            terminate_renderer()
            STATE.append_log("Stop requested.")
            with STATE.lock:
                if STATE.proc is None:
                    STATE.phase = "stopped"
                    STATE.status_text = "Renderer stopped."
            return self._send(200, json.dumps({"ok": True}))

        if self.path == "/api/client_open":
            data = self._json_body()
            client_id = str(data.get("client_id", "")).strip()
            if client_id:
                STATE.register_client(client_id)
            return self._send(200, json.dumps({"ok": True}))

        if self.path == "/api/client_ping":
            data = self._json_body()
            client_id = str(data.get("client_id", "")).strip()
            if client_id:
                STATE.touch_client(client_id)
            return self._send(200, json.dumps({"ok": True}))

        if self.path == "/api/client_close":
            data = self._json_body()
            client_id = str(data.get("client_id", "")).strip()
            if client_id:
                STATE.unregister_client(client_id)
            if STATE.live_client_count() == 0:
                schedule_shutdown_if_no_clients(2.5, "Launcher page closed. Shutting down launcher.")
            return self._send(200, json.dumps({"ok": True}))

        return self._send(404, json.dumps({"ok": False, "error": "Not found"}))

    def log_message(self, format, *args):
        return

def find_port(start=8765):
    for port in range(start, start + 50):
        with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
            try:
                s.bind(("127.0.0.1", port))
                return port
            except OSError:
                continue
    raise RuntimeError("Could not find a free localhost port")

def main():
    port = find_port()
    server = ThreadingHTTPServer(("127.0.0.1", port), Handler)
    STATE.server = server
    url = f"http://127.0.0.1:{port}/"
    print(f"Bed Renderer web launcher running at {url}")
    print(f"Preferences file: {PREFS_PATH}")
    print("Close the launcher page to request launcher shutdown.")
    print("Press Control-C to stop the launcher server.")

    def stop_from_signal(signum, frame):
        request_shutdown(f"Launcher received signal {signum}. Shutting down.")

    for sig in (signal.SIGINT, signal.SIGTERM):
        try:
            signal.signal(sig, stop_from_signal)
        except Exception:
            pass

    threading.Timer(0.4, lambda: webbrowser.open(url)).start()
    threading.Thread(target=client_watchdog, daemon=True).start()

    try:
        server.serve_forever()
    finally:
        terminate_renderer()
        server.server_close()
    return 0

if __name__ == "__main__":
    raise SystemExit(main())
