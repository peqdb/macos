#!/bin/bash
set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "$0")" && pwd)"
cd "$SCRIPT_DIR"

APP_NAME="Downmix Renderer"
PY_FILE="downmix_renderer_webview_app.py"
CORE_FILE="bed_renderer_web_launcher.py"
BIN_FILE="bed_renderer_916_low_latency"
BUNDLE_ID="com.peqdb.downmixrenderer"
VENV_DIR="$SCRIPT_DIR/.pyinstaller-venv-webview"
DIST_DIR="$SCRIPT_DIR/dist"
BUILD_DIR="$SCRIPT_DIR/build"
ZIP_PATH="$SCRIPT_DIR/${APP_NAME}.zip"
ICON_PATH="$SCRIPT_DIR/DownmixRenderer.icns"
APP_PATH="$DIST_DIR/$APP_NAME.app"
PLIST_PATH="$APP_PATH/Contents/Info.plist"

for f in "$PY_FILE" "$CORE_FILE" "$BIN_FILE"; do
  if [[ ! -f "$f" ]]; then
    echo "Missing $f"
    exit 1
  fi
done

if ! command -v python3 >/dev/null 2>&1; then
  echo "python3 is required but was not found."
  exit 1
fi

chmod +x "$BIN_FILE" || true

python3 -m venv "$VENV_DIR"
source "$VENV_DIR/bin/activate"
python -m pip install --upgrade pip
python -m pip install pyinstaller pywebview

rm -rf "$DIST_DIR" "$BUILD_DIR"

if [[ -f "$ICON_PATH" ]]; then
  pyinstaller \
    --noconfirm \
    --clean \
    --windowed \
    --onedir \
    --name "$APP_NAME" \
    --add-binary "$SCRIPT_DIR/$BIN_FILE:." \
    --osx-bundle-identifier "$BUNDLE_ID" \
    --collect-all webview \
    --icon "$ICON_PATH" \
    "$SCRIPT_DIR/$PY_FILE"
else
  pyinstaller \
    --noconfirm \
    --clean \
    --windowed \
    --onedir \
    --name "$APP_NAME" \
    --add-binary "$SCRIPT_DIR/$BIN_FILE:." \
    --osx-bundle-identifier "$BUNDLE_ID" \
    --collect-all webview \
    "$SCRIPT_DIR/$PY_FILE"
fi

if [[ ! -d "$APP_PATH" ]]; then
  echo "Build did not produce $APP_PATH"
  exit 1
fi

/usr/libexec/PlistBuddy -c "Add :NSMicrophoneUsageDescription string Downmix Renderer needs microphone access to open the selected input audio device for real-time downmixing." "$PLIST_PATH" 2>/dev/null || \
/usr/libexec/PlistBuddy -c "Set :NSMicrophoneUsageDescription Downmix Renderer needs microphone access to open the selected input audio device for real-time downmixing." "$PLIST_PATH"

/usr/libexec/PlistBuddy -c "Add :LSApplicationCategoryType string public.app-category.music" "$PLIST_PATH" 2>/dev/null || true

codesign --force --deep --sign - "$APP_PATH"

rm -f "$ZIP_PATH"
ditto -c -k --keepParent "$APP_PATH" "$ZIP_PATH"

echo
echo "Built webview app: $APP_PATH"
echo "Shareable zip: $ZIP_PATH"
echo
echo "Launch the app by double-clicking it."
echo "This build waits for the local UI server before loading the main page, so it should no longer show a blank white window after the splash screen."
