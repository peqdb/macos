#!/usr/bin/env python3
import html
import signal
import socket
import threading
import time
import urllib.request
from http.server import ThreadingHTTPServer

try:
    import webview
except Exception as exc:
    raise SystemExit(
        "pywebview is not installed. Run the build script or install it with "
        "`python3 -m pip install pywebview`."
    ) from exc

import bed_renderer_web_launcher as core

LOADING_HTML = """<!doctype html>
<html>
<head>
<meta charset=\"utf-8\">
<meta name=\"viewport\" content=\"width=device-width, initial-scale=1\">
<title>Downmix Renderer</title>
<style>
  :root { color-scheme: dark; }
  body {
    margin: 0;
    min-height: 100vh;
    display: grid;
    place-items: center;
    background: linear-gradient(180deg, #0f1013, #151821);
    color: #f0f3f8;
    font: 16px -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif;
  }
  .card {
    width: min(560px, calc(100vw - 48px));
    border-radius: 18px;
    border: 1px solid #333742;
    background: linear-gradient(180deg, #181a1f, #111318);
    box-shadow: 0 12px 30px rgba(0, 0, 0, .20);
    padding: 26px 28px;
  }
  h1 { margin: 0 0 12px 0; font-size: 24px; }
  p { margin: 0; color: #b5bcc9; line-height: 1.5; }
  .sub { margin-top: 10px; font-size: 14px; }
  .spinner {
    width: 32px; height: 32px; border-radius: 999px;
    border: 3px solid rgba(255,255,255,.18);
    border-top-color: #62a8ff;
    animation: spin .8s linear infinite;
    margin-bottom: 16px;
  }
  @keyframes spin { to { transform: rotate(360deg); } }
  code {
    display: inline-block;
    margin-top: 8px;
    padding: 6px 8px;
    border-radius: 10px;
    background: rgba(255,255,255,.06);
    color: #dbe7ff;
  }
</style>
</head>
<body>
  <div class=\"card\">
    <div class=\"spinner\"></div>
    <h1>Opening Downmix Renderer</h1>
    <p>The app window is waiting for the local control page to start.</p>
    <p class=\"sub\">If this takes more than a few seconds, the app will show a diagnostic message instead of a blank page.</p>
  </div>
</body>
</html>"""

ERROR_HTML_TEMPLATE = """<!doctype html>
<html>
<head>
<meta charset=\"utf-8\">
<meta name=\"viewport\" content=\"width=device-width, initial-scale=1\">
<title>Downmix Renderer</title>
<style>
  :root { color-scheme: dark; }
  body {
    margin: 0;
    min-height: 100vh;
    display: grid;
    place-items: center;
    background: linear-gradient(180deg, #0f1013, #151821);
    color: #f0f3f8;
    font: 16px -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif;
  }
  .card {
    width: min(760px, calc(100vw - 48px));
    border-radius: 18px;
    border: 1px solid #5a2830;
    background: linear-gradient(180deg, #211519, #151016);
    box-shadow: 0 12px 30px rgba(0, 0, 0, .20);
    padding: 26px 28px;
  }
  h1 { margin: 0 0 12px 0; font-size: 24px; color: #ffd7de; }
  p { margin: 0 0 12px 0; color: #efc8cf; line-height: 1.5; }
  ul { color: #efc8cf; }
  code, pre {
    display: block;
    white-space: pre-wrap;
    word-break: break-word;
    margin-top: 10px;
    padding: 10px 12px;
    border-radius: 10px;
    background: rgba(255,255,255,.06);
    color: #fff1f4;
  }
</style>
</head>
<body>
  <div class=\"card\">
    <h1>Downmix Renderer could not load its UI</h1>
    <p>The native app window opened, but the local control page did not become ready in time.</p>
    <p>Try closing the app, then opening it again. If it keeps happening, delete the launcher preferences file and relaunch:</p>
    <code>{prefs_path}</code>
    <p>Last startup error:</p>
    <pre>{error_text}</pre>
  </div>
</body>
</html>"""


def _serve(server):
    try:
        server.serve_forever()
    finally:
        core.terminate_renderer()
        server.server_close()


def _wait_for_server(url: str, timeout: float = 12.0):
    deadline = time.time() + timeout
    probe_url = url.rstrip("/") + "/api/status"
    last_error = None

    while time.time() < deadline:
        try:
            with urllib.request.urlopen(probe_url, timeout=0.75) as response:
                if 200 <= response.status < 300:
                    return True, None
        except Exception as exc:  # pragma: no cover - best effort diagnostics
            last_error = exc
            time.sleep(0.12)

    return False, last_error


def main():
    port = core.find_port()
    server = ThreadingHTTPServer(("127.0.0.1", port), core.Handler)
    core.STATE.server = server
    core.STATE.shutdown_requested = False
    url = f"http://127.0.0.1:{port}/"
    app_url = url + "?embedded=1"

    print(f"Downmix Renderer window launching at {url}")
    print(f"Preferences file: {core.PREFS_PATH}")

    def stop_from_signal(signum, frame):
        core.request_shutdown(f"Launcher received signal {signum}. Shutting down.")

    for sig in (signal.SIGINT, signal.SIGTERM):
        try:
            signal.signal(sig, stop_from_signal)
        except Exception:
            pass

    server_thread = threading.Thread(target=_serve, args=(server,), daemon=True)
    server_thread.start()
    threading.Thread(target=core.client_watchdog, daemon=True).start()

    window = webview.create_window(
        "Downmix Renderer",
        html=LOADING_HTML,
        width=1380,
        height=960,
        min_size=(1000, 720),
        resizable=True,
        background_color="#101114",
        text_select=True,
    )

    def _on_closed():
        core.request_shutdown("Main window closed. Shutting down launcher.")

    window.events.closed += _on_closed

    def _bootstrap(window_ref):
        ok, err = _wait_for_server(url)
        if ok:
            try:
                window_ref.load_url(app_url)
                return
            except Exception as exc:
                err = exc
        error_text = html.escape(repr(err) if err else "Unknown startup error")
        prefs_path = html.escape(str(core.PREFS_PATH))
        window_ref.load_html(ERROR_HTML_TEMPLATE.format(
            prefs_path=prefs_path,
            error_text=error_text,
        ))

    try:
        webview.start(_bootstrap, window, debug=False)
    finally:
        core.request_shutdown("Application window closed. Shutting down launcher.")
        server_thread.join(timeout=3.0)

    return 0


if __name__ == "__main__":
    raise SystemExit(main())
